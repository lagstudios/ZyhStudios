// ZYH Web — interfaz. ZYH Studios.
"use strict";

const state = { user: null, config: null, apps: [] };
const $ = (sel, root = document) => root.querySelector(sel);
const el = (tag, props = {}, ...kids) => {
  const n = Object.assign(document.createElement(tag), props);
  for (const k of kids.flat()) n.append(k?.nodeType ? k : document.createTextNode(String(k)));
  return n;
};
const view = () => $("#view");

function toast(msg, ms = 3200) {
  const t = $("#toast");
  t.textContent = msg; t.classList.add("show");
  clearTimeout(toast._t); toast._t = setTimeout(() => t.classList.remove("show"), ms);
}

async function api(path, { method = "GET", body, raw } = {}) {
  const opt = { method, headers: {}, credentials: "same-origin" };
  if (raw) { opt.body = raw; }
  else if (body !== undefined) { opt.headers["content-type"] = "application/json"; opt.body = JSON.stringify(body); }
  const r = await fetch("/api/" + path, opt);
  const data = r.headers.get("content-type")?.includes("json") ? await r.json().catch(() => ({})) : {};
  if (!r.ok) { const e = new Error(data.error || `Error ${r.status}`); e.data = data; e.status = r.status; throw e; }
  return data;
}

// La contraseña nunca viaja tal cual: se deriva en el navegador (PBKDF2) y se envía solo el resultado.
async function derive(username, password) {
  const enc = new TextEncoder();
  const key = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits(
    { name: "PBKDF2", salt: enc.encode("zyh-account:" + username.toLowerCase()), iterations: 200000, hash: "SHA-256" }, key, 256);
  return [...new Uint8Array(bits)].map((b) => b.toString(16).padStart(2, "0")).join("");
}

const fmtDate = (ts) => ts ? new Date(ts * 1000).toLocaleDateString("es-CO", { year: "numeric", month: "short", day: "numeric" }) : "—";
const fmtSize = (n) => !n ? "" : n < 1048576 ? `${Math.round(n / 1024)} KB` : `${(n / 1048576).toFixed(1)} MB`;
const PLATFORM_NAMES = { linux: "Linux", windows: "Windows", zyht32: "ZYHT32", otro: "Otro" };
const STATUS = { publicado: ["ok", "Publicado"], pendiente: ["warn", "Esperando aprobación"], rechazado: ["bad", "Rechazado"] };

// ------------------------------------------------------------------ navegación
function appsMenu() {
  const lastV = (p) => p.versiones[p.versiones.length - 1].version;
  const box = el("div", { className: "dd" }, el("button", { type: "button", className: "dd-b", textContent: "Apps ▾", "aria-haspopup": "true" }));
  const list = el("div", { className: "dd-l", role: "menu" });
  if (state.apps.length) list.append(...state.apps.map((p) => el("a", { href: `/productos/${p.slug}/${lastV(p)}/`, role: "menuitem" },
    el("img", { src: p.logo, alt: "", width: 28, height: 28 }), el("span", {}, p.nombre))),
    el("a", { href: "/productos/", className: "dd-all", textContent: "Ver todas las apps" }));
  else list.append(el("span", { className: "dd-empty", textContent: "Muy pronto: las apps llegan aquí." }));
  box.append(list);
  box.firstChild.onclick = (e) => { e.stopPropagation(); box.classList.toggle("open"); };
  return box;
}
document.addEventListener("click", () => document.querySelectorAll(".dd.open").forEach((d) => d.classList.remove("open")));
function renderNav() {
  const nav = $("#nav"), u = state.user, hash = location.hash || "#/";
  const pre = [["#/", "Inicio"]], post = [["#/zyphora", "Zyphora"], ["#/tienda", "Tienda ZYHT32"], ["#/paquetes", "Paquetes"]];
  if (u) post.push(["#/cuenta", "Mi cuenta"]);
  if (u?.perms?.length) post.push(["#/admin", "Administrar"]);
  const a = ([href, text]) => el("a", { href, textContent: text, className: hash.startsWith(href) && (href !== "#/" || hash === "#/") ? "on" : "" });
  nav.replaceChildren(...pre.map(a), appsMenu(), ...post.map(a),
    u ? el("a", { href: "#/cuenta", className: "cta", textContent: u.username })
      : el("a", { href: "#/entrar", className: "cta", textContent: "Entrar" }));
  nav.classList.remove("open");
}

const routes = {};
async function render() {
  const [path, arg] = (location.hash.replace(/^#\/?/, "") || "").split("/");
  const fn = routes[path] || routes[""];
  renderNav();
  view().replaceChildren(el("p", { className: "muted", textContent: "Cargando…" }));
  try {
    const node = state.user?.must_change && path !== "terminos" ? forcedPassword() : await fn(arg);
    view().replaceChildren(node);
  } catch (e) {
    view().replaceChildren(el("div", { className: "box" }, el("h2", {}, "Algo salió mal"), el("p", { className: "err", textContent: e.message })));
  }
  view().focus({ preventScroll: true });
  if (!location.hash.includes("#/paquete/")) scrollTo(0, 0);
}

// ------------------------------------------------------------------ contraseña temporal: hay que cambiarla antes de seguir
function forcedPassword() {
  const f = el("form", { className: "box", style: "max-width:460px;margin:30px auto" });
  const tmp = el("input", { type: "password", required: true, autocomplete: "current-password", maxLength: 72 });
  const n1 = el("input", { type: "password", required: true, autocomplete: "new-password", minLength: 8, maxLength: 72 });
  const n2 = el("input", { type: "password", required: true, autocomplete: "new-password", minLength: 8, maxLength: 72 });
  const err = el("p", { className: "err" }), btn = el("button", { className: "btn", type: "submit", textContent: "Guardar contraseña nueva" });
  f.append(el("h1", { style: "margin-top:0" }, "Pon una contraseña nueva"),
    el("p", { className: "muted" }, "Entraste con una contraseña temporal. Para proteger tu cuenta, cámbiala ahora."),
    el("label", {}, "Contraseña temporal"), tmp, el("label", {}, "Contraseña nueva"), n1, el("label", {}, "Repite la contraseña nueva"), n2,
    el("p", { className: "hint" }, "Mínimo 8 caracteres."), el("div", { style: "margin-top:14px" }, btn), err);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    if (n1.value.length < 8) { err.textContent = "Mínimo 8 caracteres."; return; }
    if (n1.value !== n2.value) { err.textContent = "Las contraseñas nuevas no coinciden."; return; }
    if (n1.value === tmp.value) { err.textContent = "Usa una contraseña distinta a la temporal."; return; }
    btn.disabled = true;
    try {
      await api("password", { method: "POST", body: { old_dk: await derive(state.user.username, tmp.value), new_dk: await derive(state.user.username, n1.value) } });
      state.user.must_change = false; toast("Contraseña guardada."); render();
    } catch (e2) { err.textContent = e2.message; btn.disabled = false; }
  };
  return f;
}

// ------------------------------------------------------------------ inicio
routes[""] = async () => {
  const frag = document.createDocumentFragment();
  frag.append(
    el("section", { className: "hero" },
      el("div", { className: "z", textContent: "Z" }),
      el("h1", {}, "ZyhStudios"),
      el("p", {}, "Apps de escritorio, el firmware ZYHT32 y los paquetes de la comunidad. Una sola cuenta ZYH para todo."),
      el("div", { className: "row", style: "justify-content:center" },
        el("a", { className: "btn", href: "/productos/", textContent: "Ver los productos" }),
        el("a", { className: "btn ghost", href: "#/paquetes", textContent: "Explorar paquetes" }))));
  try {      // enlace de TikTok: lo cambia el equipo desde Administrar
    const { site } = await api("site");
    if (site?.tiktok_url) frag.querySelector(".hero .row").append(el("a", { className: "btn ghost", href: site.tiktok_url, target: "_blank", rel: "noopener noreferrer", textContent: "♪ " + (site.tiktok_text || "TikTok") }));
  } catch { /* sin enlace */ }
  // Videos y zonas salen de las carpetas (manifiesto.json lo arma tools/build.mjs).
  let m = null;
  try { m = await (await fetch("/manifiesto.json")).json(); } catch { /* sin manifiesto: solo la portada */ }
  const vid = (v, auto) => el("figure", { className: "vfig" },
    el("video", { src: v.url, controls: true, preload: "metadata", playsInline: true, muted: !!auto, loop: !!auto, autoplay: !!auto, className: "vid" }),
    v.titulo ? el("figcaption", { className: "small muted", textContent: v.titulo }) : "");
  const prods = m?.productos || [];
  if (m?.anuncios?.length) frag.prepend(adsCarousel(m.anuncios));
  const nov = novedades(prods);
  if (nov.length) frag.append(el("h2", { className: "sec" }, "Últimas actualizaciones"), el("div", { className: "nov-grid" }, ...nov));
  frag.append(el("a", { className: "zy-promo", href: "#/zyphora" },
    el("div", { className: "zy-promo-ic", textContent: "💬" }),
    el("div", {}, el("h2", { style: "margin:0 0 4px" }, "Zyphora: mensajes gratis, sin premium"),
      el("p", { className: "muted", style: "margin:0" }, "Chats, grupos, notas de voz, temas y fondos. Escribe desde la web o desde tu ZYHT32 con la misma Cuenta ZYH, y todo llega a los dos lados.")),
    el("span", { className: "btn", textContent: state.user ? "Abrir Zyphora" : "Entrar y chatear" })));
  if ((m?.productos || []).some((p) => p.slug === "zyphora")) frag.append(el("p", { className: "small", style: "margin:-6px 0 18px;text-align:center" },
    "¿En el celular? ", el("a", { href: "/productos/zyphora/" }, "Descarga Zyphora para Android"), " (gratis)."));
  frag.append(el("h2", { className: "sec" }, "Nuestras apps"));
  if (!prods.length) frag.append(el("div", { className: "empty-apps" }, el("div", { className: "z", textContent: "Z", style: "font-size:64px;line-height:1" }),
    el("h3", {}, "Muy pronto"), el("p", { className: "muted" }, "Las apps de ZYH Studios llegan aquí. Mientras tanto crea tu cuenta ZYH y síguenos en TikTok.")));
  else frag.append(el("div", { className: "apps-grid" }, ...prods.map((p) => {
    const lv = p.versiones[p.versiones.length - 1], cover = lv.imagenes?.[0] || p.ejemplos?.imagenes?.[0];
    const price = p.gratis ? "Gratis" : p.planes.length ? "Desde US$" + Math.min(...p.planes.map((x) => x.usd)).toFixed(2) : "";
    return el("a", { className: "appcard", href: `/productos/${p.slug}/${lv.version}/` },
      el("div", { className: "ac-cover", style: cover ? `background-image:url('${cover}')` : "" }, cover ? "" : el("img", { src: p.logo, alt: "", width: 72, height: 72 })),
      el("div", { className: "ac-body" }, el("div", { className: "ac-head" }, el("img", { src: p.logo, alt: "", width: 40, height: 40 }), el("h3", {}, p.nombre)),
        el("p", { className: "muted small", textContent: p.descripcion }),
        el("div", { className: "ac-foot" }, el("span", { className: "tag", textContent: p.compatible.join(" · ") }), price ? el("span", { className: "tag " + (p.gratis ? "ok" : "warn"), textContent: price }) : "",
          el("span", { className: "ac-go", textContent: "Ver →" }))));
  })));
  if (m?.videos.items.length) {
    const c = m.videos.config;
    frag.append(el("h2", {}, c.titulo), el("div", { className: "vgrid" }, ...m.videos.items.map((v) => vid(v, c.autoplay))));
  }
  for (const p of prods.filter((x) => x.versiones[x.versiones.length - 1].videos.length)) {
    const lv = p.versiones[p.versiones.length - 1];
    frag.append(el("section", { className: "zona" },
      el("div", { className: "row", style: "justify-content:space-between" },
        el("h2", { style: "margin:0" }, p.nombre), el("a", { className: "btn sm", href: `/productos/${p.slug}/${lv.version}/`, textContent: "Ver " + p.nombre })),
      el("p", { className: "muted" }, p.descripcion),
      lv.videos.length ? el("div", { className: "vgrid" }, ...lv.videos.map((v) => vid(v, false))) : ""));
  }
  if (!m) frag.append(el("h2", {}, "Qué encuentras aquí"));
  return frag;
};

// ------------------------------------------------------------------ anuncios (public/anuncios/) y novedades (versiones nuevas)
function adsCarousel(list) {
  const slides = list.map((a, i) => {
    const media = a.tipo === "video"
      ? el("video", { src: a.url, muted: true, loop: true, playsInline: true, autoplay: i === 0, preload: i === 0 ? "auto" : "metadata", className: "ad-media" })
      : el("img", { src: a.url, alt: a.titulo || "Anuncio de ZYH Studios", className: "ad-media", loading: i === 0 ? "eager" : "lazy" });
    const inner = [media, a.titulo ? el("div", { className: "ad-cap", textContent: a.titulo }) : ""];
    return a.enlace ? el("a", { className: "ad-slide", href: a.enlace, hidden: i !== 0 }, ...inner) : el("div", { className: "ad-slide", hidden: i !== 0 }, ...inner);
  });
  let cur = 0, timer = null;
  const dots = list.length > 1 ? el("div", { className: "ad-dots" }, ...list.map((a, i) => el("button", { type: "button", className: "ad-dot" + (i === 0 ? " on" : ""), ariaLabel: "Anuncio " + (i + 1), onclick: () => { show(i); restart(); } }))) : "";
  const show = (i) => {
    slides[cur].hidden = true; slides[cur].querySelector("video")?.pause();
    cur = (i + slides.length) % slides.length; slides[cur].hidden = false;
    const v = slides[cur].querySelector("video"); if (v) { v.currentTime = 0; v.play().catch(() => {}); }
    dots && [...dots.children].forEach((d, k) => d.classList.toggle("on", k === cur));
  };
  // las imágenes pasan cada 6 s; un video pasa cuando termina una vuelta (máx. 20 s)
  const restart = () => { clearTimeout(timer); if (slides.length < 2) return; const v = slides[cur].querySelector("video");
    timer = setTimeout(() => { if (document.body.contains(box)) { show(cur + 1); restart(); } }, v && v.duration ? Math.min(20000, v.duration * 1000) : 6000); };
  const box = el("section", { className: "ads", ariaLabel: "Anuncios" }, ...slides, dots,
    list.length > 1 ? el("button", { type: "button", className: "ad-nav prev", ariaLabel: "Anterior", textContent: "‹", onclick: () => { show(cur - 1); restart(); } }) : "",
    list.length > 1 ? el("button", { type: "button", className: "ad-nav next", ariaLabel: "Siguiente", textContent: "›", onclick: () => { show(cur + 1); restart(); } }) : "");
  setTimeout(restart, 50);
  return box;
}
// "Actualización de ZYH Business 1.12": sale sola cuando agregas una carpeta de versión nueva con su notas.txt y su version.json (fecha)
function novedades(prods, max = 4) {
  const lines = (t) => String(t || "").split("\n").map((l) => l.replace(/^[-•*\s]+/, "").trim()).filter((l) => l && !/^(novedades|versi[oó]n|primera versi[oó]n)/i.test(l) && !/:$/.test(l));
  const items = prods.map((p) => { const v = p.versiones[p.versiones.length - 1]; return { p, v, t: Date.parse(v.fecha || "") || 0 }; })
    .filter((x) => x.t).sort((a, b) => b.t - a.t).slice(0, max);
  return items.map(({ p, v, t }) => {
    const nueva = p.versiones.length === 1 && /^(0\.|1\.0($|\.))/.test(v.version), fresh = Date.now() - t < 15 * 86400000;
    return el("a", { className: "nov", href: `/productos/${p.slug}/${v.version}/` },
      el("div", { className: "nov-head" }, el("img", { src: p.logo, alt: "", width: 44, height: 44 }),
        el("div", {}, el("div", { className: "nov-t" }, (nueva ? "Nueva app: " : "Actualización de ") + p.nombre + " " + v.version),
          el("div", { className: "small muted" }, new Date(t + 12 * 3600000).toLocaleDateString("es-CO", { day: "numeric", month: "short", year: "numeric" }),
            fresh ? el("span", { className: "tag ok", style: "margin-left:8px", textContent: nueva ? "Nueva" : "Nuevo" }) : ""))),
      el("ul", { className: "small" }, ...lines(v.notas).slice(0, 3).map((l) => el("li", { textContent: l }))),
      el("span", { className: "nov-go small", textContent: "Ver todo lo nuevo →" }));
  });
}

// ------------------------------------------------------------------ apps
const APPS = [
  ["ZYH Browser", "Navegador con pestañas, descargas y ajustes. Gratis.", "Gratis"],
  ["ZYH Compressor", "Comprime con tres algoritmos y verifica cada archivo.", "Desde US$2.99/mes"],
  ["ZYH Business", "Inventario, ventas y una IA que atiende tu WhatsApp.", "Desde US$12.99/mes"],
  ["ZYH Bridged", "Juega en red con tus amigos. Emparejamiento cifrado.", "Desde US$5"],
  ["ZYH ZVID", "Convierte videos al formato de la pantalla del ZYHT32.", "Gratis"],
  ["ZYHT32 IDE", "Programa y actualiza tu ZYHT32 en un clic.", "Gratis"],
];
routes["apps"] = async () => { location.replace("/productos/"); return el("p", {}); };
const _appsViejo = async () => {
  const frag = document.createDocumentFragment();
  frag.append(el("h1", {}, "Apps de ZYH Studios"),
    el("p", { className: "muted" }, "Descarga el instalador desde la sección de paquetes; cada app pide tu cuenta ZYH para activar el plan."),
    el("div", { className: "grid" }, ...APPS.map(([n, d, p]) =>
      el("div", { className: "card" }, el("h3", {}, n), el("p", { className: "muted", textContent: d }), el("span", { className: "tag", textContent: p })))),
    el("p", { className: "small muted", style: "margin-top:18px" }, "¿Ya tienes una app instalada? Entra con tu cuenta ZYH desde la propia app para activar tu plan."));
  return frag;
};

// ------------------------------------------------------------------ paquetes
function pkgCard(p) {
  const icon = p.icon ? el("img", { src: p.icon, alt: "", loading: "lazy", width: 56, height: 56 })
    : el("div", { className: "icon-ph", textContent: p.name[0].toUpperCase() });
  const tags = [el("span", { className: "tag", textContent: PLATFORM_NAMES[p.platform] || p.platform }), el("span", { className: "tag", textContent: "v" + p.version })];
  if (p.status !== "publicado") tags.unshift(el("span", { className: "tag " + STATUS[p.status][0], textContent: STATUS[p.status][1] }));
  return el("a", { className: "card pkg", href: "#/paquete/" + p.slug }, icon,
    el("div", {}, el("h3", {}, p.name), el("p", { className: "muted small", textContent: p.summary || "" }), el("div", { style: "margin-top:6px" }, ...tags)));
}

routes["paquetes"] = async () => {
  const frag = document.createDocumentFragment();
  const q = el("input", { type: "search", placeholder: "Buscar paquete…", value: "" });
  const list = el("div", { className: "grid" });
  let platform = "";
  const chips = el("div", { className: "filters" }, q,
    ...[["", "Todos"], ...PLATFORMS_ORDER].map(([v, t]) => {
      const b = el("button", { className: "chip" + (v === "" ? " on" : ""), textContent: t, type: "button" });
      b.onclick = () => { platform = v; [...chips.querySelectorAll(".chip")].forEach((c) => c.classList.toggle("on", c === b)); load(); };
      return b;
    }));
  async function load() {
    list.replaceChildren(el("p", { className: "muted" }, "Cargando…"));
    const u = new URLSearchParams(); if (platform) u.set("platform", platform); if (q.value.trim()) u.set("q", q.value.trim());
    const { packages } = await api("packages?" + u);
    list.replaceChildren(...(packages.length ? packages.map(pkgCard)
      : [el("p", { className: "muted" }, "Todavía no hay paquetes publicados aquí.")]));
  }
  let t; q.oninput = () => { clearTimeout(t); t = setTimeout(load, 300); };
  frag.append(el("div", { className: "row", style: "justify-content:space-between" }, el("h1", {}, "Paquetes"),
    state.user ? el("a", { className: "btn", href: "#/subir", textContent: "＋ Subir paquete" }) : el("a", { className: "btn ghost", href: "#/entrar", textContent: "Entrar para subir" })),
    chips, list);
  load();
  return frag;
};
const PLATFORMS_ORDER = [["linux", "Linux"], ["windows", "Windows"], ["zyht32", "ZYHT32"], ["otro", "Otro"]];

routes["paquete"] = async (slug) => {
  const { package: p } = await api("packages/" + encodeURIComponent(slug));
  const frag = document.createDocumentFragment();
  const head = el("div", { className: "pkg", style: "gap:16px;align-items:center" },
    p.icon ? el("img", { src: p.icon, alt: "", width: 56, height: 56 }) : el("div", { className: "icon-ph", textContent: p.name[0].toUpperCase() }),
    el("div", {}, el("h1", { style: "margin:0" }, p.name), el("p", { className: "muted", textContent: p.summary || "" })));
  const tags = el("div", { style: "margin:10px 0" },
    el("span", { className: "tag", textContent: PLATFORM_NAMES[p.platform] || p.platform }),
    el("span", { className: "tag", textContent: "v" + p.version }),
    el("span", { className: "tag", textContent: "por " + p.owner }),
    el("span", { className: "tag", textContent: p.downloads + " descargas" }),
    ...(p.status !== "publicado" ? [el("span", { className: "tag " + STATUS[p.status][0], textContent: STATUS[p.status][1] })] : []));
  const actions = el("div", { className: "row" });
  if (p.has_file) actions.append(el("a", { className: "btn", href: "/api/packages/" + p.slug + "/download", textContent: "Descargar" + (p.size ? ` (${fmtSize(p.size)})` : "") }));
  if (p.can_edit) {
    actions.append(el("a", { className: "btn ghost", href: "#/editar/" + p.slug, textContent: "Editar" }));
    const del = el("button", { className: "btn danger", textContent: "Borrar", type: "button" });
    del.onclick = async () => {
      if (!confirm(`¿Borrar el paquete "${p.name}"? No se puede deshacer.`)) return;
      await api("packages/" + p.slug, { method: "DELETE" }); toast("Paquete borrado."); location.hash = "#/paquetes";
    };
    actions.append(del);
  }
  frag.append(head, tags, actions);
  if (p.review_note) frag.append(el("p", { className: "err", textContent: "Nota de revisión: " + p.review_note }));
  if (p.images?.length) frag.append(el("div", { className: "shots" }, ...p.images.map((src) => el("img", { src, alt: "", loading: "lazy" }))));
  if (p.description) frag.append(el("h2", {}, "Descripción"), el("p", { className: "desc", textContent: p.description }));
  frag.append(el("p", { className: "small muted", style: "margin-top:20px" },
    "Los paquetes de la comunidad los sube cada autor; ZYH Studios los revisa antes de publicarlos, pero no responde por su contenido."));
  return frag;
};

// ------------------------------------------------------------------ subir / editar paquete
async function uploadFile(file, kind) {
  const max = state.config.limits[kind];
  if (file.size > max) throw new Error(`"${file.name}" pesa ${fmtSize(file.size)} y el máximo es ${fmtSize(max)}.`);
  const r = await api(`upload?kind=${kind}&name=${encodeURIComponent(file.name)}`, { method: "POST", raw: file });
  return r.id;
}

async function packageForm(slug) {
  if (!state.user) { location.hash = "#/entrar"; return el("p", {}, "Necesitas entrar."); }
  const existing = slug ? (await api("packages/" + encodeURIComponent(slug))).package : null;
  const f = el("form", { className: "box wide" });
  const field = (label, node, hint) => { f.append(el("label", { textContent: label }), node); if (hint) f.append(el("p", { className: "hint", textContent: hint })); return node; };
  const name = field("Nombre del paquete", el("input", { required: true, maxLength: 60, value: existing?.name || "" }));
  const summary = field("Resumen corto", el("input", { maxLength: 140, value: existing?.summary || "", placeholder: "Una línea que explique qué hace" }));
  const version = field("Versión", el("input", { maxLength: 20, value: existing?.version || "1.0" }));
  const platform = field("Plataforma", el("select", {}, ...PLATFORMS_ORDER.map(([v, t]) => el("option", { value: v, textContent: t, selected: existing?.platform === v }))));
  const description = field("Descripción", el("textarea", { maxLength: 5000, value: existing?.description || "" }));
  const icon = field("Icono (PNG o JPG)", el("input", { type: "file", accept: "image/*" }), existing?.icon_id ? "Ya tiene icono. Elige otro solo si quieres cambiarlo." : `Máximo ${fmtSize(state.config.limits.icon)}.`);
  const images = field("Imágenes (hasta 5)", el("input", { type: "file", accept: "image/*", multiple: true }),
    existing?.image_ids?.length ? `Tiene ${existing.image_ids.length}. Si eliges nuevas, reemplazan a las anteriores.` : `Máximo ${fmtSize(state.config.limits.image)} cada una.`);
  const file = field("Archivo del paquete", el("input", { type: "file" }),
    existing?.file_id ? `Ya tiene archivo (${existing.file_name}). Elige otro solo si quieres cambiarlo.` : `Máximo ${fmtSize(state.config.limits.package)}. Si pesa más, usa el enlace de abajo.`);
  const external = field("…o enlace de descarga (https)", el("input", { type: "url", value: existing?.external_url || "", placeholder: "https://github.com/usuario/proyecto/releases/…" }));
  const err = el("p", { className: "err" });
  const submit = el("button", { className: "btn", type: "submit", textContent: slug ? "Guardar cambios" : "Subir paquete" });
  f.append(el("div", { className: "row", style: "margin-top:18px" }, submit), err);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = ""; submit.disabled = true; submit.textContent = "Subiendo…";
    try {
      const body = { name: name.value, summary: summary.value, description: description.value, version: version.value,
        platform: platform.value, external_url: external.value.trim(),
        icon_id: existing?.icon_id || "", file_id: existing?.file_id || "", image_ids: existing?.image_ids || [] };
      if (icon.files[0]) body.icon_id = await uploadFile(icon.files[0], "icon");
      if (file.files[0]) body.file_id = await uploadFile(file.files[0], "package");
      if (images.files.length) { body.image_ids = []; for (const im of [...images.files].slice(0, 5)) body.image_ids.push(await uploadFile(im, "image")); }
      const r = await api(slug ? "packages/" + slug : "packages", { method: slug ? "PUT" : "POST", body });
      toast(r.status === "publicado" ? "Paquete publicado." : "Paquete enviado: ZYH Studios lo revisará antes de publicarlo.");
      location.hash = "#/cuenta";
    } catch (e2) { err.textContent = e2.message; }
    submit.disabled = false; submit.textContent = slug ? "Guardar cambios" : "Subir paquete";
  };
  const frag = document.createDocumentFragment();
  frag.append(el("h1", {}, slug ? "Editar paquete" : "Subir un paquete"),
    el("p", { className: "muted" }, state.user.perms?.includes("paquetes.revisar") ? "Con tu rol, tus paquetes se publican al instante."
      : "Tu paquete queda esperando aprobación; ZYH Studios lo revisa y luego aparece en la lista."), f);
  return frag;
}
routes["subir"] = () => packageForm(null);
routes["editar"] = (slug) => packageForm(slug);

// ------------------------------------------------------------------ planes
routes["planes"] = async () => { location.replace("/productos/"); return el("p", {}); };

// ------------------------------------------------------------------ entrar / crear cuenta
routes["entrar"] = async () => {
  if (state.user) { location.hash = "#/cuenta"; return el("p", {}); }
  let mode = "login";
  const frag = document.createDocumentFragment();
  const f = el("form", { className: "box" });
  const title = el("h1", { className: "center" }, "Entrar");
  const user = el("input", { required: true, autocomplete: "username", minLength: 3, maxLength: 32, placeholder: "tu usuario" });
  const pass = el("input", { type: "password", required: true, autocomplete: "current-password", minLength: 8, maxLength: 72 });
  const email = el("input", { type: "email", autocomplete: "email", maxLength: 120, placeholder: "opcional, para recuperar tu cuenta" });
  const emailWrap = el("div", { hidden: true }, el("label", {}, "Correo"), email);
  const err = el("p", { className: "err" });
  const submit = el("button", { className: "btn", type: "submit", style: "width:100%", textContent: "Entrar" });
  const swap = el("button", { className: "btn ghost", type: "button", style: "width:100%;margin-top:8px", textContent: "Crear una cuenta ZYH" });
  const code = el("input", { inputMode: "numeric", autocomplete: "one-time-code", maxLength: 12, placeholder: "000000", style: "text-align:center;font-size:1.4em;letter-spacing:4px" });
  const codeWrap = el("div", { hidden: true }, el("label", {}, "Código de verificación"), code,
    el("p", { className: "hint" }, "Los 6 dígitos de tu app autenticadora (Google Authenticator, Aegis, Authy…), o uno de tus códigos de respaldo."));
  const forgot = el("p", { className: "small center", style: "margin-top:12px" }, el("a", { href: "#/recuperar" }, "¿Olvidaste tu contraseña?"));
  f.append(el("label", {}, "Usuario"), user, el("p", { className: "hint" }, "3 a 32 caracteres: letras, números, punto, guion o guion bajo."),
    el("label", {}, "Contraseña"), pass, el("p", { className: "hint" }, "Mínimo 8 caracteres."), emailWrap, codeWrap,
    el("div", { style: "margin-top:16px" }, submit), swap, err, forgot);
  swap.onclick = () => {
    mode = mode === "login" ? "register" : "login";
    const reg = mode === "register";
    title.textContent = reg ? "Crear cuenta ZYH" : "Entrar";
    submit.textContent = reg ? "Crear cuenta" : "Entrar";
    swap.textContent = reg ? "Ya tengo cuenta" : "Crear una cuenta ZYH";
    emailWrap.hidden = !reg; pass.autocomplete = reg ? "new-password" : "current-password"; err.textContent = "";
    codeWrap.hidden = true; code.value = ""; forgot.hidden = reg;
  };
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    if (pass.value.length < 8) { err.textContent = "La contraseña debe tener al menos 8 caracteres."; return; }
    submit.disabled = true; const was = submit.textContent; submit.textContent = "Un momento…";
    try {
      const dk = await derive(user.value.trim(), pass.value);
      const body = { username: user.value.trim(), dk };
      if (mode === "register") body.email = email.value.trim();
      if (mode === "login" && !codeWrap.hidden) body.code = code.value.trim();
      let r;
      try { r = await api(mode === "register" ? "register" : "login", { method: "POST", body }); }
      catch (e3) {
        if (e3.data?.need_2fa) {   // paso 2: la contraseña estaba bien, falta el código
          const first = codeWrap.hidden;
          codeWrap.hidden = false; user.readOnly = pass.readOnly = true; title.textContent = "Verificación en dos pasos";
          err.textContent = first ? "" : e3.message; code.value = ""; setTimeout(() => code.focus(), 50);
          submit.disabled = false; submit.textContent = "Verificar y entrar"; return;
        }
        throw e3;
      }
      state.user = (await api("me")).user || r.user; toast(mode === "register" ? `Cuenta creada. ¡Hola, ${r.user.username}!` : `Hola, ${r.user.username}`);
      location.hash = "#/cuenta";
    } catch (e2) { err.textContent = e2.message; }
    submit.disabled = false; submit.textContent = codeWrap.hidden ? was : "Verificar y entrar";
  };
  frag.append(title, f);
  return frag;
};

// ------------------------------------------------------------------ recuperar cuenta
routes["recuperar"] = async (ticketArg) => {
  const frag = document.createDocumentFragment();
  frag.append(el("h1", { className: "center" }, "Recuperar tu cuenta ZYH"));
  frag.append(el("div", { className: "box wide" }, el("h2", { style: "margin-top:0" }, "Cómo funciona"),
    el("ol", { className: "small", style: "line-height:1.7" },
      el("li", {}, "Escribe tu usuario, el correo con el que te registraste (si pusiste uno) y una ", el("b", {}, "contraseña nueva"), "."),
      el("li", {}, "Dinos cómo contactarte (por ejemplo tu usuario de TikTok o tu correo) por si necesitamos confirmar que la cuenta es tuya."),
      el("li", {}, "Te damos un ", el("b", {}, "número de solicitud"), ". Guárdalo: con él miras cómo va."),
      el("li", {}, "El equipo de ZYH Studios revisa que la cuenta sea tuya. Si lo aprueba, tu contraseña nueva queda activa y ya puedes entrar en la web y en las apps."),
      el("li", {}, "Por seguridad se cierran todas las sesiones abiertas de tu cuenta.")),
    el("p", { className: "small muted" }, "Nadie del equipo ve tu contraseña: se transforma en tu navegador antes de enviarse. ZYH Studios nunca te pedirá tu contraseña por mensaje.")));
  // formulario
  const f = el("form", { className: "box", style: "margin-top:18px" });
  const u = el("input", { required: true, autocomplete: "username", minLength: 3, maxLength: 32, placeholder: "tu usuario" });
  const em = el("input", { type: "email", maxLength: 120, autocomplete: "email", placeholder: "el correo de tu cuenta (si tiene)" });
  const p1 = el("input", { type: "password", required: true, autocomplete: "new-password", minLength: 8, maxLength: 72 });
  const p2 = el("input", { type: "password", required: true, autocomplete: "new-password", minLength: 8, maxLength: 72 });
  const ct = el("input", { required: true, maxLength: 120, placeholder: "TikTok @usuario, correo u otro medio" });
  const nt = el("textarea", { rows: 3, maxLength: 500, placeholder: "Opcional: algo que nos ayude a saber que es tu cuenta (qué apps usas, cuándo la creaste, tu plan…)" });
  const err = el("p", { className: "err" }), ok = el("div"), btn = el("button", { className: "btn", type: "submit", style: "width:100%", textContent: "Enviar solicitud" });
  f.append(el("h2", { style: "margin-top:0" }, "1. Pide la recuperación"), el("label", {}, "Usuario"), u, el("label", {}, "Correo de la cuenta"), em,
    el("label", {}, "Contraseña nueva"), p1, el("label", {}, "Repite la contraseña nueva"), p2, el("p", { className: "hint" }, "Mínimo 8 caracteres."),
    el("label", {}, "Cómo contactarte"), ct, el("label", {}, "Algo más"), nt, el("div", { style: "margin-top:14px" }, btn), err, ok);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    if (p1.value.length < 8) { err.textContent = "La contraseña debe tener al menos 8 caracteres."; return; }
    if (p1.value !== p2.value) { err.textContent = "Las contraseñas no coinciden."; return; }
    btn.disabled = true; btn.textContent = "Enviando…";
    try {
      const name = u.value.trim().toLowerCase();
      const r = await api("recover", { method: "POST", body: { username: name, email: em.value.trim(), contact: ct.value.trim(), note: nt.value.trim(), new_dk: await derive(name, p1.value) } });
      f.querySelectorAll("input,textarea,button").forEach((x) => (x.disabled = true)); btn.textContent = "Solicitud enviada";
      ok.replaceChildren(el("div", { className: "box", style: "margin:14px 0 0;max-width:none;text-align:center" },
        el("p", {}, "Solicitud enviada. Tu número es:"), el("p", {}, el("code", { textContent: r.ticket, style: "font-size:1.6em;user-select:all" })),
        el("p", { className: "small muted" }, "Guárdalo (cópialo o tómale captura). Abajo puedes mirar cómo va."),
        el("button", { className: "btn ghost sm", type: "button", textContent: "Copiar número", onclick: () => { navigator.clipboard?.writeText(r.ticket); toast("Copiado."); } })));
      tk.value = r.ticket;
    } catch (e2) { err.textContent = e2.message; btn.disabled = false; btn.textContent = "Enviar solicitud"; }
  };
  frag.append(f);
  // estado
  const tk = el("input", { maxLength: 20, placeholder: "XXXXX-XXXXX", value: ticketArg || "", style: "text-transform:uppercase" });
  const st = el("div", { style: "margin-top:12px" });
  const look = async () => {
    st.replaceChildren();
    if (!tk.value.trim()) return;
    try {
      const r = await api("recover/status?ticket=" + encodeURIComponent(tk.value.trim()));
      const txt = { pendiente: ["warn", "En revisión", "El equipo todavía no la revisa. Vuelve a mirar más tarde."],
        aprobada: ["ok", "Aprobada", "Ya puedes entrar con tu usuario y la contraseña nueva que escribiste."],
        rechazada: ["bad", "Rechazada", "No pudimos confirmar que la cuenta es tuya."], vencida: ["bad", "Vencida", "Pasaron 7 días sin respuesta. Puedes enviar otra."] }[r.status] || ["", r.status, ""];
      st.append(el("p", {}, el("span", { className: "tag " + txt[0], textContent: txt[1] }), " ", txt[2]),
        r.answer ? el("p", { className: "small" }, el("b", {}, "Respuesta del equipo: "), r.answer) : "",
        r.status === "aprobada" ? el("a", { className: "btn sm", href: "#/entrar", textContent: "Entrar" }) : "");
    } catch (e) { st.append(el("p", { className: "err", textContent: e.message })); }
  };
  frag.append(el("div", { className: "box", style: "margin-top:18px" }, el("h2", { style: "margin-top:0" }, "2. Mira cómo va tu solicitud"),
    el("div", { className: "row" }, tk, el("button", { className: "btn sm", type: "button", textContent: "Consultar", onclick: look })), st));
  if (ticketArg) look();
  return frag;
};

// ------------------------------------------------------------------ verificación en dos pasos (Mi cuenta)
function twofaBox() {
  const box = el("div", { className: "box wide", style: "margin-top:14px" });
  const draw = () => {
    const on = !!state.user.twofa;
    box.replaceChildren(el("h3", { style: "margin-top:0" }, "Verificación en dos pasos ", el("span", { className: "tag " + (on ? "ok" : ""), textContent: on ? "activada" : "desactivada" })),
      el("p", { className: "small" }, on ? "Para entrar a tu cuenta ZYH se pide tu contraseña y un código de 6 dígitos de tu app autenticadora."
        : "Además de tu contraseña, al entrar se pedirá un código de 6 dígitos que cambia cada 30 segundos. Sirve con Google Authenticator, Aegis, Authy, Microsoft Authenticator…"),
      el("p", { className: "small muted" }, "Vale para tu cuenta ZYH en la web. En las apps que todavía no piden el código, usa «Vincular» o entra desde la web."));
    const err = el("p", { className: "err" });
    if (!on) {
      box.append(el("button", { className: "btn sm", type: "button", textContent: "Activar", onclick: async () => {
        err.textContent = "";
        try {
          const r = await api("2fa/setup", { method: "POST", body: {} });
          let img = "";
          try { await new Promise((ok, no) => { if (window.qrcode) return ok(); const sc = el("script", { src: "/vendor/qrcode.js" }); sc.onload = ok; sc.onerror = no; document.head.append(sc); });
            const q = window.qrcode(0, "M"); q.addData(r.uri); q.make(); img = el("img", { src: q.createDataURL(5, 2), alt: "QR para la app autenticadora", style: "width:200px;height:200px;border-radius:10px;background:#fff" }); } catch { /* sin QR: queda la clave */ }
          const c = el("input", { inputMode: "numeric", autocomplete: "one-time-code", maxLength: 6, placeholder: "000000", style: "max-width:200px;text-align:center;font-size:1.3em;letter-spacing:4px" });
          const go = el("button", { className: "btn sm", type: "button", textContent: "Confirmar y activar" });
          go.onclick = async () => {
            err.textContent = "";
            try {
              const k = await api("2fa/enable", { method: "POST", body: { code: c.value.trim() } });
              state.user.twofa = true; draw();
              box.append(el("div", { className: "box", style: "margin:12px 0 0;max-width:none" }, el("h4", { style: "margin-top:0" }, "Guarda tus códigos de respaldo"),
                el("p", { className: "small" }, "Si pierdes el teléfono, cada uno sirve una sola vez en lugar del código. Guárdalos en un lugar seguro: no se vuelven a mostrar."),
                el("pre", { style: "user-select:all;font-size:1.1em" }, k.backup_codes.join("\n")),
                el("button", { className: "btn ghost sm", type: "button", textContent: "Copiar códigos", onclick: () => { navigator.clipboard?.writeText(k.backup_codes.join("\n")); toast("Copiados."); } })));
              toast("Verificación en dos pasos activada.");
            } catch (e2) { err.textContent = e2.message; }
          };
          box.replaceChildren(el("h3", { style: "margin-top:0" }, "Activar verificación en dos pasos"),
            el("ol", { className: "small", style: "line-height:1.7" }, el("li", {}, "Abre tu app autenticadora y añade una cuenta escaneando este QR (o escribiendo la clave)."),
              el("li", {}, "Escribe abajo el código de 6 dígitos que te muestra.")),
            el("div", { className: "center" }, img), el("p", { className: "center", style: "word-break:break-all;user-select:all" }, el("b", {}, r.secret.replace(/(.{4})/g, "$1 ").trim())),
            el("div", { className: "row", style: "justify-content:center" }, c, go,
              el("button", { className: "btn ghost sm", type: "button", textContent: "Cancelar", onclick: draw })), err);
        } catch (e2) { err.textContent = e2.message; }
      } }), err);
    } else {
      const c = el("input", { maxLength: 12, placeholder: "código o código de respaldo", style: "max-width:240px" });
      box.append(el("div", { className: "row" }, c, el("button", { className: "btn danger sm", type: "button", textContent: "Desactivar", onclick: async () => {
        err.textContent = "";
        try { await api("2fa/disable", { method: "POST", body: { code: c.value.trim() } }); state.user.twofa = false; toast("Verificación en dos pasos desactivada."); draw(); } catch (e2) { err.textContent = e2.message; }
      } })), err);
    }
  };
  draw();
  return box;
}

// ------------------------------------------------------------------ mi cuenta
routes["cuenta"] = async () => {
  if (!state.user) { location.hash = "#/entrar"; return el("p", {}); }
  const [{ licenses }, { packages }] = await Promise.all([api("licenses"), api("packages?scope=mine")]);
  const frag = document.createDocumentFragment();
  const out = el("button", { className: "btn ghost sm", textContent: "Cerrar sesión", type: "button" });
  out.onclick = async () => { await api("logout", { method: "POST" }); state.user = null; toast("Sesión cerrada."); location.hash = "#/"; };
  frag.append(el("div", { className: "row", style: "justify-content:space-between" },
    el("h1", {}, state.user.username, state.user.code ? el("small", { className: "muted", style: "font-size:.5em;margin-left:10px" }, "ID " + state.user.code) : ""), el("div", { className: "row" }, el("span", { className: "tag", textContent: state.user.role === "admin" ? "administrador" : "cuenta ZYH" }), out)));

  frag.append(el("h2", {}, "Mis licencias"));
  if (!licenses.length) {
    frag.append(el("p", { className: "muted" }, "Todavía no tienes planes. ", el("a", { href: "/productos/" }, "Ver productos"), "."));
  } else {
    frag.append(el("div", { className: "scroll" }, el("table", {},
      el("thead", {}, el("tr", {}, ...["Producto", "Plan", "Dispositivos", "Vence", ""].map((t) => el("th", {}, t)))),
      el("tbody", {}, ...licenses.map((l) => el("tr", {},
        el("td", {}, l.product_name), el("td", {}, l.plan_name),
        el("td", {}, `${l.used} de ${l.devices >= 999 ? "ilimitados" : l.devices}`), el("td", {}, fmtDate(l.expires)),
        el("td", {}, el("span", { className: "tag " + (l.active ? "ok" : "bad"), textContent: l.active ? "activa" : "vencida" }))))))));
    frag.append(el("p", { className: "small muted" }, "Para activar el plan en una app, entra con tu cuenta ZYH desde la propia app."));
  }

  frag.append(el("div", { className: "row", style: "justify-content:space-between;margin-top:26px" },
    el("h2", { style: "margin:0" }, "Mis paquetes"), el("a", { className: "btn sm", href: "#/subir", textContent: "＋ Subir paquete" })));
  frag.append(packages.length ? el("div", { className: "grid", style: "margin-top:12px" }, ...packages.map(pkgCard))
    : el("p", { className: "muted" }, "Aún no has subido paquetes."));

  frag.append(await accountSettings(licenses));

  // cambiar contraseña
  const f = el("form", { className: "box", style: "margin-top:26px" });
  const oldp = el("input", { type: "password", required: true, autocomplete: "current-password", maxLength: 72 });
  const newp = el("input", { type: "password", required: true, autocomplete: "new-password", minLength: 8, maxLength: 72 });
  const err = el("p", { className: "err" });
  const btn = el("button", { className: "btn", type: "submit", textContent: "Cambiar contraseña" });
  f.append(el("h2", { style: "margin-top:0" }, "Cambiar contraseña"), el("label", {}, "Contraseña actual"), oldp,
    el("label", {}, "Contraseña nueva"), newp, el("p", { className: "hint" }, "Mínimo 8 caracteres. Se cerrarán tus otras sesiones."),
    el("div", { style: "margin-top:14px" }, btn), err);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    if (newp.value.length < 8) { err.textContent = "La contraseña nueva debe tener al menos 8 caracteres."; return; }
    btn.disabled = true;
    try {
      await api("password", { method: "POST", body: { old_dk: await derive(state.user.username, oldp.value), new_dk: await derive(state.user.username, newp.value) } });
      toast("Contraseña cambiada."); f.reset();
    } catch (e2) { err.textContent = e2.message; }
    btn.disabled = false;
  };
  frag.append(f);
  return frag;
};

// ------------------------------------------------------------------ configuración de la cuenta ZYH
async function accountSettings(licenses) {
  const [{ sessions }, { links }, { payments }] = await Promise.all([api("account/sessions"), api("account/links"), api("payments")]);
  const wrap = el("section", { style: "margin-top:26px" });
  wrap.append(el("h2", {}, "Configuración de tu cuenta ZYH"),
    el("div", { className: "box wide" }, el("h3", { style: "margin-top:0" }, "Acerca de la cuenta ZYH"),
      el("p", { className: "small" }, "Una sola cuenta para la web y todas las apps de ZYH Studios (Business, Zyphora, Remote, Compressor, Bridged, Browser, ZVID, ZYHT32 IDE y el ZYHT32). Tu contraseña nunca sale de tu equipo: se convierte en una clave cifrada antes de enviarse, y todo viaja por HTTPS. En las apps, tu sesión se guarda cifrada (AES-256) y atada a ese equipo."),
      el("p", { className: "small muted" }, "ID de tu cuenta: ", el("code", {}, state.user.code || "—"))));
  wrap.append(twofaBox());

  // apps y sesiones conectadas
  const sb = el("div", { className: "box wide", style: "margin-top:14px" }, el("h3", { style: "margin-top:0" }, "Apps y sesiones conectadas"));
  sb.append(el("div", { className: "scroll" }, el("table", {}, el("thead", {}, el("tr", {}, ...["Dónde", "Tipo", "Desde", ""].map((t) => el("th", {}, t)))),
    el("tbody", {}, ...sessions.map((x) => el("tr", {}, el("td", {}, x.label), el("td", {}, x.kind === "app" ? "App" : "Web"), el("td", {}, fmtDate(x.created_at)),
      el("td", {}, x.current ? el("span", { className: "tag ok", textContent: "esta sesión" }) : el("button", { className: "btn danger sm", type: "button", textContent: "Cerrar",
        onclick: async () => { await api("account/sessions/" + x.id, { method: "DELETE" }); toast("Sesión cerrada."); render(); } }))))))));
  if (sessions.some((x) => x.kind === "app")) sb.append(el("div", { style: "margin-top:10px" }, el("button", { className: "btn ghost sm", type: "button", textContent: "Cerrar la sesión en todas las apps",
    onclick: async () => { if (!confirm("Tendrás que volver a entrar en cada app.")) return; await api("account/sessions/apps", { method: "DELETE" }); toast("Apps desconectadas."); render(); } })));
  wrap.append(sb);

  // Zyphora
  const z = links.find((l) => l.provider === "zyphora");
  const zb = el("div", { className: "box wide", style: "margin-top:14px" }, el("h3", { style: "margin-top:0" }, "Vincular con Zyphora"));
  if (z && z.external) {
    zb.append(el("p", {}, "Vinculada con ", el("code", {}, z.external), " ", el("span", { className: "tag " + (z.verified ? "ok" : "warn"), textContent: z.verified ? "verificada" : "sin verificar" })),
      el("button", { className: "btn ghost sm", type: "button", textContent: "Desvincular", onclick: async () => { await api("account/link-zyphora", { method: "DELETE" }); toast("Desvinculada."); render(); } }));
  } else {
    const zid = el("input", { placeholder: "tu usuario o ID de Zyphora", maxLength: 60 });
    const out = el("p", { className: "small" });
    zb.append(el("p", { className: "small muted" }, "Guarda tu usuario de Zyphora, o genera un código y escríbelo en Zyphora para verificar que la cuenta es tuya."),
      el("div", { className: "row" }, zid, el("button", { className: "btn sm", type: "button", textContent: "Vincular", onclick: async () => {
        try { await api("account/link-zyphora", { method: "POST", body: { zyphora_id: zid.value.trim() } }); toast("Vinculada (sin verificar)."); render(); } catch (e) { out.textContent = e.message; } } }),
        el("button", { className: "btn ghost sm", type: "button", textContent: "Generar código de verificación", onclick: async () => {
          try { const r = await api("account/link-zyphora/code", { method: "POST", body: {} }); out.textContent = "Tu código: " + r.code + " (vale 10 minutos). Escríbelo en Zyphora."; } catch (e) { out.textContent = e.message; } } })), out);
  }
  wrap.append(zb);

  // Ya pagué
  const pf = el("form", { className: "box wide", style: "margin-top:14px" });
  const prod = el("select", {}, ...Object.entries(state.config.plans).map(([k, v]) => el("option", { value: k, textContent: v.name })));
  const plan = el("select", {}), ref = el("input", { required: true, placeholder: "ID de la transacción de PayPal", maxLength: 60 });
  const num = el("input", { placeholder: "Número desde el que pagaste (opcional)", maxLength: 30, inputMode: "tel" });
  const perr = el("p", { className: "err" });
  const fillp = () => plan.replaceChildren(...Object.entries((state.config.plans[prod.value]?.plans || {})).map(([k, v]) => el("option", { value: k, textContent: `${v[0]} — US$${v[1]}` })));
  prod.onchange = fillp; fillp();
  pf.append(el("h3", { style: "margin-top:0" }, "Ya pagué: avisar mi pago"), el("p", { className: "small muted" }, "Después de pagar en PayPal, pega aquí el ID de la transacción. Una persona del equipo lo revisa y activa tu plan. Tu número se guarda cifrado y solo lo ve Recursos humanos."),
    el("label", {}, "Producto"), prod, el("label", {}, "Plan"), plan, el("label", {}, "ID de transacción"), ref, el("label", {}, "Número (opcional)"), num,
    el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Enviar pago a revisión" })), perr);
  pf.onsubmit = async (e) => { e.preventDefault(); perr.textContent = "";
    try { await api("payments", { method: "POST", body: { product: prod.value, plan: plan.value, reference: ref.value, payer_number: num.value } }); toast("Pago enviado a revisión."); render(); } catch (e2) { perr.textContent = e2.message; } };
  wrap.append(pf);
  if (payments.length) wrap.append(el("div", { className: "scroll", style: "margin-top:10px" }, el("table", {}, el("thead", {}, el("tr", {}, ...["Fecha", "Plan", "ID", "Estado"].map((t) => el("th", {}, t)))),
    el("tbody", {}, ...payments.map((p) => el("tr", {}, el("td", {}, fmtDate(p.created_at)), el("td", {}, `${p.product_name} · ${p.plan_name}`), el("td", {}, el("code", {}, p.reference)),
      el("td", {}, el("span", { className: "tag " + (p.status === "correcta" ? "ok" : p.status === "rechazada" ? "bad" : "warn"), textContent: p.status }), p.note ? " " + p.note : "")))))));
  return wrap;
}

// ------------------------------------------------------------------ administración
routes["admin"] = async () => {
  if (!state.user?.perms?.length) { location.hash = "#/"; return el("p", {}); }
  const can = (p) => state.user.perms?.includes(p);
  const [{ licenses }, { packages }, rolesData] = await Promise.all([can("cuentas.ver") ? api("admin/licenses") : { licenses: [] }, can("paquetes.revisar") ? api("packages?scope=all") : { packages: [] }, can("cuentas.ver") ? api("admin/roles") : { roles: [], perms: {} }]);
  const frag = document.createDocumentFragment();
  frag.append(el("h1", {}, "Administrar"), el("p", {}, el("a", { className: "btn ghost sm", href: "#/admin-tienda", textContent: "Tienda ZYHT32 (publicar y ganancias)" }), " ", el("a", { className: "btn ghost sm", href: "#/admin-business", textContent: "ZYH Business (avisos y opiniones)" }),
    state.user.perms?.includes("cuentas.restablecer") ? [" ", el("a", { className: "btn ghost sm", href: "#/admin-soporte", textContent: "Soporte de cuentas" }), " ", el("a", { className: "btn ghost sm", href: "#/admin-recuperacion", textContent: "Recuperar cuentas" })] : ""));

  // --- dar un plan
  const f = el("form", { className: "box wide" });
  const u = el("input", { required: true, placeholder: "usuario ZYH", maxLength: 40 });
  const prod = el("select", {}, ...Object.entries(state.config.plans).map(([k, v]) => el("option", { value: k, textContent: v.name })));
  const plan = el("select", {});
  const days = el("input", { type: "number", value: "30", min: "1", max: "3660" });
  const extra = el("input", { type: "number", value: "0", min: "0", max: "999" });
  const note = el("input", { maxLength: 200, placeholder: "referencia del pago (opcional)" });
  const err = el("p", { className: "err" });
  const fillPlans = () => plan.replaceChildren(...Object.entries((state.config.plans[prod.value]?.plans || {})).map(([k, v]) => el("option", { value: k, textContent: `${v[0]} — US$${v[1]}` })));
  prod.onchange = fillPlans; fillPlans();
  f.append(el("h2", { style: "margin-top:0" }, "Dar un plan a una cuenta"),
    el("label", {}, "Usuario"), u, el("label", {}, "Producto"), prod, el("label", {}, "Plan"), plan,
    el("label", {}, "Días"), days, el("label", {}, "Dispositivos extra"), extra, el("label", {}, "Nota"), note,
    el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Activar plan" })), err);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    try {
      await api("admin/licenses", { method: "POST", body: { username: u.value.trim(), product: prod.value, plan: plan.value, days: +days.value, extra_devices: +extra.value, note: note.value } });
      toast("Plan activado."); render();
    } catch (e2) { err.textContent = e2.message; }
  };
  if (can("planes.dar")) frag.append(f);

  // --- paquetes por revisar
  if (can("paquetes.revisar")) {
  frag.append(el("h2", {}, "Paquetes"));
  const pend = packages.filter((p) => p.status === "pendiente");
  frag.append(el("p", { className: "muted small" }, pend.length ? `${pend.length} esperando aprobación.` : "Nada pendiente por revisar."));
  frag.append(el("div", { className: "grid" }, ...packages.slice(0, 40).map((p) => {
    const card = el("div", { className: "card" }, el("h3", {}, p.name),
      el("p", { className: "small muted", textContent: `por ${p.owner} · ${PLATFORM_NAMES[p.platform]} · v${p.version}` }),
      el("span", { className: "tag " + STATUS[p.status][0], textContent: STATUS[p.status][1] }));
    const row = el("div", { className: "row", style: "margin-top:10px" }, el("a", { className: "btn ghost sm", href: "#/paquete/" + p.slug, textContent: "Ver" }));
    const setStatus = async (status, ask) => {
      const n = ask ? prompt("Motivo (lo verá el autor):", "") : "";
      if (ask && n === null) return;
      await api(`admin/packages/${p.id}/status`, { method: "POST", body: { status, note: n || "" } }); toast("Listo."); render();
    };
    if (p.status !== "publicado") row.append(el("button", { className: "btn sm", textContent: "Publicar", type: "button", onclick: () => setStatus("publicado", false) }));
    if (p.status !== "rechazado") row.append(el("button", { className: "btn danger sm", textContent: "Rechazar", type: "button", onclick: () => setStatus("rechazado", true) }));
    card.append(row);
    return card;
  })));
  }

  // --- licencias
  if (can("cuentas.ver")) {
  const licRow = (l) => {
    const soltar = el("button", { className: "btn ghost sm", textContent: "Soltar equipos", type: "button" });
    soltar.onclick = async () => { await api(`admin/licenses/${l.id}/reset`, { method: "POST" }); toast("Equipos liberados."); render(); };
    const quitar = el("button", { className: "btn danger sm", textContent: "Quitar", type: "button" });
    quitar.onclick = async () => {
      if (!confirm("¿Quitar esta licencia?")) return;
      await api("admin/licenses/" + l.id, { method: "DELETE" }); toast("Licencia quitada."); render();
    };
    const tr = el("tr");
    tr.append(el("td", {}, l.username), el("td", {}, state.config.plans[l.product]?.name || l.product), el("td", {}, l.plan_name),
      el("td", {}, `${l.used} de ${l.devices >= 999 ? "sin límite" : l.devices}`), el("td", {}, fmtDate(l.expires)),
      el("td", {}, can("planes.dar") ? el("div", { className: "row" }, soltar, quitar) : ""));
    return tr;
  };
  frag.append(el("h2", {}, "Licencias"));
  frag.append(licenses.length
    ? el("div", { className: "scroll" }, el("table", {},
        el("thead", {}, el("tr", {}, ...["Usuario", "Producto", "Plan", "Equipos", "Vence", ""].map((t) => el("th", {}, t)))),
        el("tbody", {}, ...licenses.map(licRow))))
    : el("p", { className: "muted" }, "Todavía no has activado ningún plan."));

  // --- cuentas ZYH: búsqueda por ID (exacta o aproximada) o por usuario
  frag.append(el("h2", {}, "Cuentas ZYH"),
    el("p", { className: "muted small" }, "Busca por ID (por ejemplo 0000001, o solo una parte como 12) o por nombre de usuario."));
  const q = el("input", { type: "search", placeholder: "ID o usuario…", maxLength: 40, ariaLabel: "Buscar cuenta" });
  const out = el("div", { className: "scroll" });
  const rowOf = (x) => el("tr", {},
    el("td", {}, el("code", {}, x.code)), el("td", {}, x.username), el("td", { className: "small muted" }, x.email || "—"), el("td", {}, x.id === 1 ? "dueño" : x.role === "admin" ? "administrador" : x.role === "user" ? "cuenta" : x.role),
    el("td", {}, el("span", { className: "tag " + (x.disabled ? "bad" : "ok"), textContent: x.disabled ? "baneada" : "activa" })),
    el("td", {}, x.planes_activos ? el("span", { className: "tag ok", textContent: x.planes_activos + " plan" + (x.planes_activos > 1 ? "es" : "") }) : el("span", { className: "small muted" }, "sin plan")),
    el("td", {}, x.reportes ? el("span", { className: "tag warn", textContent: x.reportes + " reporte" + (x.reportes > 1 ? "s" : "") }) : ""),
    el("td", {}, el("a", { className: "btn ghost sm", href: "#/admin-cuenta/" + x.id, textContent: "Ver" })));
  async function buscar() {
    const { users } = await api("admin/users?q=" + encodeURIComponent(q.value.trim()));
    out.replaceChildren(users.length ? el("table", {},
      el("thead", {}, el("tr", {}, ...["ID", "Usuario", "Correo", "Rol", "Estado", "Planes", "Reportes", ""].map((t) => el("th", {}, t)))),
      el("tbody", {}, ...users.map(rowOf))) : el("p", { className: "muted" }, "No hay cuentas con ese ID o usuario."));
  }
  let tq; q.oninput = () => { clearTimeout(tq); tq = setTimeout(buscar, 250); };
  frag.append(el("div", { className: "filters" }, q), out);
  buscar();
  }

  // --- roles del equipo (solo quien gestiona roles)
  if (can("planes.verificar") || can("transferencias.ver")) frag.append(await paymentsPanel(can));
  if (can("sitio.editar")) frag.append(await sitePanel());
  if (can("roles.gestionar")) frag.append(rolesPanel(rolesData));
  return frag;
};

async function sitePanel() {
  const { site } = await api("site");
  const f = el("form", { className: "box wide", style: "margin-top:26px" });
  const url = el("input", { value: site.tiktok_url || "", placeholder: "https://www.tiktok.com/@tuusuario", maxLength: 200 });
  const text = el("input", { value: site.tiktok_text || "", maxLength: 60, placeholder: "Síguenos en TikTok" });
  const err = el("p", { className: "err" });
  f.append(el("h2", { style: "margin-top:0" }, "Enlace de TikTok del inicio"), el("label", {}, "Enlace (déjalo vacío para ocultar el botón)"), url,
    el("label", {}, "Texto del botón"), text, el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Guardar" })), err);
  f.onsubmit = async (e) => { e.preventDefault(); err.textContent = ""; try { await api("admin/site", { method: "PUT", body: { tiktok_url: url.value.trim(), tiktok_text: text.value.trim() } }); toast("Guardado."); } catch (e2) { err.textContent = e2.message; } };
  return f;
}

async function paymentsPanel(can) {
  const box = el("section", { style: "margin-top:26px" });
  const state_ = { st: "pendiente" };
  const draw = async () => {
    const { payments, numero_completo } = await api("admin/payments?status=" + state_.st);
    const sel = el("select", {}, ...[["pendiente", "Pendientes"], ["correcta", "Correctas"], ["rechazada", "Rechazadas"]].map(([v, t]) => el("option", { value: v, textContent: t, selected: v === state_.st })));
    sel.onchange = () => { state_.st = sel.value; draw(); };
    const rows = payments.map((p) => {
      const acts = el("div", { className: "row" });
      if (p.status === "pendiente" && can("planes.verificar")) {
        acts.append(el("button", { className: "btn sm", type: "button", textContent: "Correcto: activar plan", onclick: async () => {
          if (!confirm(`¿El pago ${p.reference} de ${p.user} es correcto? Se activa el plan.`)) return;
          try { await api(`admin/payments/${p.id}/review`, { method: "POST", body: { action: "correcta" } }); toast("Plan activado."); draw(); } catch (e) { toast(e.message); } } }),
          el("button", { className: "btn danger sm", type: "button", textContent: "Rechazar", onclick: async () => {
            const note = prompt("Motivo del rechazo:") || ""; try { await api(`admin/payments/${p.id}/review`, { method: "POST", body: { action: "rechazada", note } }); toast("Rechazado."); draw(); } catch (e) { toast(e.message); } } }));
      }
      return el("tr", {}, el("td", {}, fmtDate(p.created_at)), el("td", {}, p.user, " ", el("code", {}, p.code)), el("td", {}, `${p.product_name} · ${p.plan_name}${p.extra ? " +" + p.extra + " eq." : ""}`),
        el("td", {}, "US$" + p.amount_usd), el("td", {}, el("code", {}, p.reference)), el("td", {}, p.number || "—"),
        el("td", {}, el("span", { className: "tag " + (p.status === "correcta" ? "ok" : p.status === "rechazada" ? "bad" : "warn"), textContent: p.status }), p.note ? el("div", { className: "small muted" }, p.note) : ""), el("td", {}, acts));
    });
    box.replaceChildren(el("div", { className: "row", style: "justify-content:space-between" }, el("h2", { style: "margin:0" }, "Pagos y transferencias de clientes"), sel),
      el("p", { className: "small muted" }, numero_completo ? "Ves el número completo de cada transferencia." : "El número del cliente aparece oculto (solo los últimos 4 dígitos)."),
      rows.length ? el("div", { className: "scroll" }, el("table", {}, el("thead", {}, el("tr", {}, ...["Fecha", "Cuenta", "Plan", "Valor", "ID PayPal", "Número", "Estado", ""].map((t) => el("th", {}, t)))), el("tbody", {}, ...rows))) : el("p", { className: "muted" }, "No hay pagos en esta lista."));
  };
  await draw();
  return box;
}

function rolesPanel({ roles, perms }) {
  const box = el("section", {}, el("h2", {}, "Roles del equipo"),
    el("p", { className: "muted small" }, "Crea roles con los permisos que quieras y luego asígnaselos a las cuentas desde su ficha. El dueño (cuenta 0000001) siempre puede todo."));
  const plantillas = { Soporte: ["cuentas.ver", "usuarios.reportar"], Ventas: ["cuentas.ver", "planes.dar"], Moderador: ["cuentas.ver", "usuarios.reportar", "usuarios.banear", "paquetes.revisar"] };
  const permBoxes = (sel) => Object.entries(perms).map(([k, label]) => {
    const cb = el("input", { type: "checkbox", value: k, checked: sel.includes(k), style: "width:auto;margin-right:8px" });
    return el("label", { style: "display:flex;align-items:center;font-weight:400;margin:6px 0" }, cb, label);
  });
  const readPerms = (root) => [...root.querySelectorAll("input[type=checkbox]:checked")].map((c) => c.value);

  // lista de roles existentes
  for (const r of roles) {
    const card = el("div", { className: "card", style: "margin-bottom:12px" },
      el("div", { className: "row", style: "justify-content:space-between" }, el("h3", { style: "margin:0" }, r.name),
        el("span", { className: "tag", textContent: r.miembros + " cuenta" + (r.miembros === 1 ? "" : "s") })));
    if (!r.custom) {
      card.append(el("p", { className: "small muted" }, r.key === "user" ? "Sin permisos de administración." : "Todos los permisos menos gestionar roles: " + r.perms.map((p) => perms[p]).join("; ") + "."));
    } else {
      const list = el("div", {}, ...permBoxes(r.perms));
      const save = el("button", { className: "btn sm", type: "button", textContent: "Guardar permisos" });
      save.onclick = async () => { await api("admin/roles/" + r.key, { method: "PUT", body: { perms: readPerms(list) } }); toast("Rol guardado."); render(); };
      const del = el("button", { className: "btn danger sm", type: "button", textContent: "Borrar rol" });
      del.onclick = async () => { if (!confirm(`¿Borrar el rol "${r.name}"? Sus cuentas pasan a cuenta normal.`)) return; await api("admin/roles/" + r.key, { method: "DELETE" }); toast("Rol borrado."); render(); };
      card.append(list, el("div", { className: "row", style: "margin-top:8px" }, save, del));
    }
    box.append(card);
  }

  // crear rol
  const f = el("form", { className: "box wide" });
  const name = el("input", { required: true, maxLength: 40, placeholder: "Nombre del rol (ejemplo: Soporte)" });
  const checks = el("div", {}, ...permBoxes([]));
  const err = el("p", { className: "err" });
  const tpl = el("div", { className: "row", style: "margin:8px 0" }, ...Object.entries(plantillas).map(([n, ps]) =>
    el("button", { className: "chip", type: "button", textContent: n, onclick: () => {
      name.value = n; checks.querySelectorAll("input").forEach((c) => { c.checked = ps.includes(c.value); }); } })));
  f.append(el("h3", { style: "margin-top:0" }, "Crear un rol"), el("label", {}, "Nombre"), name, el("p", { className: "hint" }, "Plantillas rápidas:"), tpl,
    el("label", {}, "Permisos"), checks, el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Crear rol" })), err);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    try { await api("admin/roles", { method: "POST", body: { name: name.value, perms: readPerms(checks) } }); toast("Rol creado."); render(); } catch (e2) { err.textContent = e2.message; }
  };
  box.append(f);
  return box;
}

// ------------------------------------------------------------------ una cuenta (administración)
routes["admin-cuenta"] = async (id) => {
  if (!state.user?.perms?.length) { location.hash = "#/"; return el("p", {}); }
  const can = (p) => state.user.perms?.includes(p);
  const [{ user: u, licenses, reports }, { roles }] = await Promise.all([api("admin/users/" + encodeURIComponent(id)), api("admin/roles")]);
  const roleName = (k) => roles.find((r) => r.key === k)?.name || k;
  const frag = document.createDocumentFragment();
  const isOwner = u.id === 1, isMe = u.username === state.user.username;
  frag.append(el("p", { className: "small" }, el("a", { href: "#/admin" }, "← Administrar")),
    el("div", { className: "row", style: "justify-content:space-between" },
      el("h1", { style: "margin:0" }, u.username, " ", el("code", {}, u.code)),
      el("div", { className: "row" }, el("span", { className: "tag " + (u.disabled ? "bad" : "ok"), textContent: u.disabled ? "baneada" : "activa" }),
        el("span", { className: "tag", textContent: roleName(u.role) }))),
    el("p", { className: "muted small" }, `Correo: ${u.email || "—"} · Creada: ${fmtDate(u.created_at)}`));

  // --- planes de la cuenta
  frag.append(el("h2", {}, "Planes de esta cuenta"));
  if (!licenses.length) frag.append(el("p", { className: "muted" }, "No tiene ningún plan."));
  else frag.append(el("div", { className: "scroll" }, el("table", {},
    el("thead", {}, el("tr", {}, ...["Producto", "Plan", "Equipos", "Vence", "Estado", ""].map((t) => el("th", {}, t)))),
    el("tbody", {}, ...licenses.map((l) => {
      const soltar = el("button", { className: "btn ghost sm", textContent: "Soltar equipos", type: "button" });
      soltar.onclick = async () => { await api(`admin/licenses/${l.id}/reset`, { method: "POST" }); toast("Equipos liberados."); render(); };
      const quitar = el("button", { className: "btn danger sm", textContent: "Quitar", type: "button" });
      quitar.onclick = async () => { if (!confirm("¿Quitar este plan?")) return; await api("admin/licenses/" + l.id, { method: "DELETE" }); toast("Plan quitado."); render(); };
      return el("tr", {}, el("td", {}, l.product_name), el("td", {}, l.plan_name), el("td", {}, `${l.used} de ${l.devices >= 999 ? "ilimitados" : l.devices}`),
        el("td", {}, fmtDate(l.expires)), el("td", {}, el("span", { className: "tag " + (l.active ? "ok" : "bad"), textContent: l.active ? "activo" : "vencido" })),
        el("td", {}, can("planes.dar") ? el("div", { className: "row" }, soltar, quitar) : ""));
    })))));

  // --- dar un plan
  const f = el("form", { className: "box wide", style: "margin-top:18px" });
  const prod = el("select", {}, ...Object.entries(state.config.plans).map(([k, v]) => el("option", { value: k, textContent: v.name })));
  const plan = el("select", {});
  const days = el("input", { type: "number", value: "30", min: "1", max: "3660" });
  const extra = el("input", { type: "number", value: "0", min: "0", max: "999" });
  const note = el("input", { maxLength: 200, placeholder: "referencia del pago (opcional)" });
  const err = el("p", { className: "err" });
  const fill = () => plan.replaceChildren(...Object.entries((state.config.plans[prod.value]?.plans || {})).map(([k, v]) => el("option", { value: k, textContent: `${v[0]} — US$${v[1]}` })));
  prod.onchange = fill; fill();
  f.append(el("h2", { style: "margin-top:0" }, "Dar un plan"), el("label", {}, "Producto"), prod, el("label", {}, "Plan"), plan,
    el("label", {}, "Días"), days, el("label", {}, "Equipos extra"), extra, el("label", {}, "Nota"), note,
    el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Activar plan" })), err);
  f.onsubmit = async (e) => {
    e.preventDefault(); err.textContent = "";
    try { await api("admin/licenses", { method: "POST", body: { username: u.username, product: prod.value, plan: plan.value, days: +days.value, extra_devices: +extra.value, note: note.value } }); toast("Plan activado."); render(); }
    catch (e2) { err.textContent = e2.message; }
  };
  if (can("planes.dar")) frag.append(f);

  // --- regalar días
  if ((can("dias.regalar") || can("planes.dar")) && !(isMe && !isOwner)) {
    const gf = el("form", { className: "box wide", style: "margin-top:18px" });
    const gdays = el("input", { type: "number", value: "3", min: "1", max: "365" });
    const gprod = el("select", {}, el("option", { value: "", textContent: "Todos sus planes activos" }), ...Object.entries(state.config.plans).map(([k, v]) => el("option", { value: k, textContent: v.name })));
    const gnote = el("input", { maxLength: 150, placeholder: "Motivo del regalo (opcional)" });
    const gerr = el("p", { className: "err" });
    gf.append(el("h2", { style: "margin-top:0" }, "Regalar días gratis"), el("p", { className: "small muted" }, "Se suman a los planes activos. Si no tiene ninguno, elige el producto: se crea el primer plan con esos días."),
      el("label", {}, "Días"), gdays, el("label", {}, "Producto"), gprod, el("label", {}, "Nota"), gnote,
      el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Regalar días" })), gerr);
    gf.onsubmit = async (e) => { e.preventDefault(); gerr.textContent = "";
      try { await api(`admin/users/${u.id}/gift`, { method: "POST", body: { days: +gdays.value, product: gprod.value, note: gnote.value } }); toast("Días regalados."); render(); } catch (e2) { gerr.textContent = e2.message; } };
    frag.append(gf);
  }

  // --- reportar / banear / rol
  const teamTarget = u.role !== "user" && !can("roles.gestionar");   // un miembro del equipo solo lo toca quien gestiona roles
  if (isOwner || isMe) frag.append(el("p", { className: "small muted", style: "margin-top:18px" }, isOwner ? "La cuenta del dueño no se puede reportar ni banear." : "Esta es tu cuenta."));
  else if (teamTarget) frag.append(el("p", { className: "small muted", style: "margin-top:18px" }, "Esta cuenta es parte del equipo: solo quien gestiona roles puede cambiarla."));
  else if (can("usuarios.reportar") || can("usuarios.banear") || can("roles.gestionar")) {
    const rf = el("form", { className: "box wide", style: "margin-top:18px" });
    const reason = el("input", { maxLength: 300, placeholder: "Motivo (lo ven solo los del equipo)" });
    const rerr = el("p", { className: "err" });
    const buttons = el("div", { className: "row", style: "margin-top:14px" });
    if (can("usuarios.reportar")) buttons.append(el("button", { className: "btn ghost", type: "submit", textContent: "Reportar usuario" }));
    if (can("usuarios.banear")) buttons.append(el("button", { className: "btn danger", type: "button", textContent: u.disabled ? "Quitar baneo" : "Banear usuario",
      onclick: async () => {
        if (!u.disabled && !reason.value.trim()) { rerr.textContent = "Escribe el motivo del baneo."; return; }
        if (!confirm(u.disabled ? "¿Quitar el baneo?" : `¿Banear a ${u.username}? Se cierran sus sesiones.`)) return;
        try { await api("admin/users/" + u.id, { method: "POST", body: { disabled: !u.disabled, reason: reason.value } }); toast("Listo."); render(); } catch (e2) { rerr.textContent = e2.message; }
      } }));
    rf.append(el("h2", { style: "margin-top:0" }, "Reportar o banear"), el("label", {}, "Motivo"), reason, buttons, rerr);
    if (can("roles.gestionar")) {
      const sel = el("select", {}, ...roles.map((r) => el("option", { value: r.key, textContent: r.name, selected: r.key === u.role })));
      const setRole = el("button", { className: "btn ghost", type: "button", textContent: "Cambiar rol",
        onclick: async () => { try { await api("admin/users/" + u.id, { method: "POST", body: { role: sel.value } }); toast("Rol cambiado."); render(); } catch (e2) { rerr.textContent = e2.message; } } });
      rf.append(el("h2", {}, "Rol de esta cuenta"), el("div", { className: "row" }, sel, setRole));
    }
    rf.onsubmit = async (e) => {
      e.preventDefault(); rerr.textContent = "";
      try { await api(`admin/users/${u.id}/report`, { method: "POST", body: { reason: reason.value } }); toast("Reporte guardado."); render(); } catch (e2) { rerr.textContent = e2.message; }
    };
    frag.append(rf);
  }

  // --- recuperar cuenta (restablecer contraseña)
  if (can("cuentas.restablecer") && !isOwner && !isMe && !teamTarget) {
    const no2 = el("input", { type: "checkbox", style: "width:auto;margin:0" });
    const ok = el("input", { type: "checkbox", style: "width:auto;margin:0" }), why = el("input", { maxLength: 200, placeholder: "Cómo lo verificaste (opcional, queda en el historial)" });
    const out = el("div"), perr = el("p", { className: "err" });
    const go = el("button", { className: "btn", type: "button", textContent: "Restablecer contraseña" });
    go.onclick = async () => {
      perr.textContent = "";
      if (!ok.checked) { perr.textContent = "Primero confirma que verificaste que es el dueño de la cuenta."; return; }
      if (!confirm(`¿Restablecer la contraseña de ${u.username}? Se cerrarán todas sus sesiones (web, apps y ZYHT32).`)) return;
      const abc = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789", r = crypto.getRandomValues(new Uint8Array(12));
      const temp = Array.from(r, (x) => abc[x % abc.length]).join("");
      go.disabled = true;
      try {
        await api(`admin/users/${u.id}/password`, { method: "POST", body: { dk: await derive(u.username, temp), reason: why.value, remove_2fa: no2.checked } });
        const pass = el("code", { textContent: temp, style: "font-size:1.3em;user-select:all" });
        out.replaceChildren(el("div", { className: "box", style: "margin:12px 0 0;max-width:none;text-align:left" },
          el("p", {}, "Contraseña temporal de ", el("b", {}, u.username), ":"), pass, " ",
          el("button", { className: "btn ghost sm", type: "button", textContent: "Copiar", onclick: () => { navigator.clipboard?.writeText(temp); toast("Copiada."); } }),
          el("p", { className: "small muted" }, "Pásasela a la persona por un medio privado. Al entrar a la web se le pedirá que ponga una nueva. Esta contraseña no se vuelve a mostrar.")));
        ok.checked = false; why.value = "";
      } catch (e2) { perr.textContent = e2.message; }
      go.disabled = false;
    };
    frag.append(el("div", { className: "box wide", style: "margin-top:18px" }, el("h2", { style: "margin-top:0" }, "Recuperar cuenta"),
      el("p", { className: "small muted" }, "Las contraseñas no se guardan, así que no se pueden ver. Si la persona la olvidó, genera una temporal. Antes, confirma que es el dueño: que te diga el correo con el que se registró (", u.email ? el("b", {}, u.email) : "esta cuenta no tiene correo", ") y su ID ", el("b", {}, u.code), "."),
      el("label", { style: "display:flex;gap:10px;align-items:center;margin:10px 0" }, ok, "Verifiqué que es el dueño de esta cuenta"),
      u.twofa ? el("label", { style: "display:flex;gap:10px;align-items:center;margin:10px 0" }, no2, "Quitar también la verificación en dos pasos (perdió su app autenticadora)") : "", why,
      el("div", { style: "margin-top:12px" }, go), perr, out));
  }

  // --- historial de reportes
  frag.append(el("h2", {}, "Reportes y baneos"));
  frag.append(reports.length ? el("div", { className: "scroll" }, el("table", {},
    el("thead", {}, el("tr", {}, ...["Fecha", "Motivo", "Por", ""].map((t) => el("th", {}, t)))),
    el("tbody", {}, ...reports.map((r) => el("tr", {}, el("td", {}, fmtDate(r.created_at)), el("td", {}, r.reason), el("td", {}, r.by_name || "—"),
      el("td", {}, can("usuarios.reportar") ? el("button", { className: "btn ghost sm", type: "button", textContent: "Quitar",
        onclick: async () => { await api("admin/reports/" + r.id, { method: "DELETE" }); toast("Listo."); render(); } }) : "")))))) : el("p", { className: "muted" }, "Sin reportes."));
  return frag;
};

// ------------------------------------------------------------------ términos

// ------------------------------------------------------------------ tienda de apps para ZYHT32
const money = (n) => "US$" + Number(n).toFixed(2);
let _man = null;
const manifest = async () => _man || (_man = await fetch("/manifiesto.json").then((r) => r.json()).catch(() => ({})));
const storeMedia = async (slug) => ((await manifest()).tienda || {})[slug] || { icono: "", imagenes: [], videos: [] };

routes["tienda"] = async () => {
  const [{ apps, open }, man] = await Promise.all([api("store/apps"), manifest()]);
  const frag = document.createDocumentFragment();
  frag.append(el("h1", {}, "Tienda ZYHT32"),
    el("p", { className: "muted" }, "Apps hechas para el ZYHT32 IDE. Cada venta se reparte: 65% para quien creó la app y 35% para ZYH Studios."));
  if (!open) frag.append(el("p", { className: "box small" }, "El ZYHT32 todavía no está en lanzamiento, así que por ahora solo ZYH Studios publica apps aquí. Cuando se abra, cualquier creador con cuenta ZYH podrá publicar las suyas."));
  if (!apps.length) { frag.append(el("p", { className: "muted" }, "Pronto habrá apps aquí.")); return frag; }
  frag.append(el("div", { className: "grid" }, ...apps.map((a) => {
    const m = (man.tienda || {})[a.slug] || {};
    return el("a", { className: "card pkg", href: "#/tienda-app/" + a.slug },
      m.imagenes?.[0] ? el("img", { src: m.imagenes[0], alt: "", loading: "lazy", style: "width:100%;border-radius:10px;margin-bottom:10px" })
        : el("div", { className: "icon-ph", textContent: a.name[0].toUpperCase() }),
      el("h3", { style: "margin:6px 0" }, a.name), el("p", { className: "small muted", textContent: (a.description || "").slice(0, 110) }),
      el("span", { className: "tag", textContent: a.category }), el("span", { className: "tag " + (a.price_usd ? "warn" : "ok"), textContent: a.price_usd ? money(a.price_usd) : "Gratis" }));
  })));
  return frag;
};

routes["tienda-app"] = async (slug) => {
  const [{ app: a }, m] = await Promise.all([api("store/apps/" + encodeURIComponent(slug)), storeMedia(slug)]);
  const frag = document.createDocumentFragment();
  frag.append(el("p", { className: "small" }, el("a", { href: "#/tienda" }, "← Tienda ZYHT32")),
    el("div", { className: "pkg", style: "gap:16px;align-items:center" },
      m.icono ? el("img", { src: m.icono, alt: "", width: 56, height: 56 }) : el("div", { className: "icon-ph", textContent: a.name[0].toUpperCase() }),
      el("div", {}, el("h1", { style: "margin:0" }, a.name), el("p", { className: "muted" }, "por ", a.author))),
    el("div", { style: "margin:10px 0" }, el("span", { className: "tag", textContent: a.category }), el("span", { className: "tag", textContent: "v" + a.version }),
      el("span", { className: "tag", textContent: a.downloads + " descargas" }), el("span", { className: "tag", textContent: fmtSize(a.size) })));
  if (m.videos?.length) frag.append(el("h2", {}, "Cómo se usa"), ...m.videos.map((v) => el("figure", { style: "margin:0 0 12px" },
    el("video", { src: v.url, controls: true, preload: "metadata", style: "max-width:100%;border-radius:12px;border:1px solid var(--line)" }), el("figcaption", { className: "small muted", textContent: v.titulo }))));
  if (m.imagenes?.length) frag.append(el("h2", {}, "Así se ve"), el("div", { className: "shots" }, ...m.imagenes.map((src) => el("img", { src, alt: "Captura de " + a.name, loading: "lazy" }))));
  if (!m.videos?.length && !m.imagenes?.length) frag.append(el("p", { className: "small muted" }, "Esta app todavía no tiene imágenes ni video."));
  if (a.description) frag.append(el("h2", {}, "Descripción"), el("p", { className: "desc", textContent: a.description }));

  const buy = el("div", { className: "box wide", style: "margin-top:16px" });
  buy.append(el("h2", { style: "margin-top:0" }, a.price_usd ? money(a.price_usd) : "Gratis"));
  if (a.price_usd) buy.append(el("p", { className: "small muted" }, `De cada venta: ${money(a.creator_usd)} (65%) para ${a.author} y ${money(a.studio_usd)} (35%) para ZYH Studios.`));
  const dl = el("a", { className: "btn", href: "/api/store/download/" + a.slug, textContent: "Descargar .zip" });
  if (a.owned) {
    buy.append(el("div", { className: "row" }, state.user ? dl : el("a", { className: "btn", href: "#/entrar", textContent: "Entra para descargar" })),
      el("p", { className: "small muted" }, "Descomprime el .zip en la raíz de tu microSD: queda en zyht32/apps/" + a.slug + "/ y aparece en el ZYHT32."));
  } else if (!state.user) {
    buy.append(el("a", { className: "btn", href: "#/entrar", textContent: "Entra para comprar" }));
  } else if (a.pending) {
    buy.append(el("p", { className: "tag warn", textContent: "Tu pago está en revisión" }));
  } else {
    const ref = el("input", { required: true, placeholder: "ID de la transacción de PayPal", maxLength: 60 }), num = el("input", { placeholder: "Número desde el que pagaste (opcional)", maxLength: 30, inputMode: "tel" });
    const err = el("p", { className: "err" });
    const f = el("form", {}, el("label", {}, "ID de transacción"), ref, el("label", {}, "Número (opcional)"), num,
      el("div", { style: "margin-top:12px" }, el("button", { className: "btn", type: "submit", textContent: "Ya pagué: avisar" })), err);
    f.onsubmit = async (e) => { e.preventDefault(); err.textContent = "";
      try { await api("payments", { method: "POST", body: { product: "tienda", plan: a.slug, reference: ref.value, payer_number: num.value } }); toast("Pago enviado a revisión."); render(); } catch (e2) { err.textContent = e2.message; } };
    buy.append(a.paypal_id ? el("a", { className: "btn", href: "https://www.paypal.com/ncp/payment/" + a.paypal_id, target: "_blank", rel: "noopener noreferrer", textContent: "1. Pagar con PayPal" })
      : el("p", { className: "small muted" }, "Esta app aún no tiene botón de pago."),
      el("p", { className: "small muted", style: "margin-top:12px" }, "2. Cuando pagues, pega aquí el ID de la transacción. Una persona del equipo lo revisa y te abre la descarga."), f);
  }
  frag.append(buy);
  return frag;
};

const fileB64 = (file) => new Promise((ok, no) => { const r = new FileReader(); r.onload = () => ok(String(r.result).split(",")[1]); r.onerror = no; r.readAsDataURL(file); });
routes["admin-soporte"] = async (q) => {
  if (!state.user?.perms?.includes("cuentas.restablecer")) { location.hash = "#/"; return el("p", {}); }
  const st = await api("admin/support/status");
  const frag = document.createDocumentFragment();
  frag.append(el("p", { className: "small" }, el("a", { href: "#/admin" }, "← Administrar")), el("h1", {}, "Soporte de cuentas"),
    el("p", { className: "muted small" }, "Desbloquea cuentas, pon contraseñas nuevas o cambia el nombre de usuario. Cada acción pide un código de la herramienta ",
      el("b", {}, "ZYH Soporte"), " de tu PC (muestra 5 códigos de 5 caracteres que cambian cada minuto; cada uno sirve una vez). Las contraseñas no se pueden ver: no se guardan en ningún lado."));
  // clave de soporte (solo el dueño)
  if (st.owner) {
    const kb = el("div", { className: "box wide" }, el("h3", { style: "margin-top:0" }, "Clave de soporte ", el("span", { className: "tag " + (st.paired ? "ok" : "warn"), textContent: st.paired ? "creada" : "sin crear" })));
    const out = el("div");
    kb.append(el("p", { className: "small" }, "La herramienta ZYH Soporte la necesita una sola vez para vincularse. Quien la tenga puede arreglar cualquier cuenta: guárdala solo en tu PC."),
      el("button", { className: "btn sm", type: "button", textContent: st.paired ? "Crear una clave nueva (la anterior deja de servir)" : "Crear clave de soporte", onclick: async () => {
        if (st.paired && !confirm("La herramienta vinculada con la clave anterior dejará de funcionar hasta que pongas la nueva. ¿Seguir?")) return;
        const r = await api("admin/support/key", { method: "POST", body: {} });
        out.replaceChildren(el("div", { className: "box", style: "margin:12px 0 0;max-width:none" }, el("p", {}, "Tu clave de soporte (cópiala en ZYH Soporte; no se vuelve a mostrar):"),
          el("p", {}, el("code", { textContent: r.key, style: "font-size:1.05em;word-break:break-all;user-select:all" })),
          el("button", { className: "btn ghost sm", type: "button", textContent: "Copiar", onclick: () => { navigator.clipboard?.writeText(r.key); toast("Copiada."); } })));
      } }), out);
    frag.append(kb);
  }
  // buscar cuenta
  const qi = el("input", { placeholder: "usuario o ID (por ejemplo ana o 0000004)", value: q || "", maxLength: 40 });
  const res = el("div");
  const find = async () => {
    res.replaceChildren();
    if (!qi.value.trim()) return;
    try { const { user: u } = await api("admin/support/find?q=" + encodeURIComponent(qi.value.trim().replace(/^@/, ""))); res.append(supportCard(u, find)); }
    catch (e) { res.append(el("p", { className: "err", textContent: e.message })); }
  };
  frag.append(el("div", { className: "box wide", style: "margin-top:14px" }, el("h3", { style: "margin-top:0" }, "Buscar cuenta"),
    el("form", { className: "row", onsubmit: (e) => { e.preventDefault(); find(); } }, qi, el("button", { className: "btn sm", type: "submit", textContent: "Buscar" }))), res);
  if (q) find();
  return frag;
};
function supportCard(u, reload) {
  const card = el("div", { className: "box wide", style: "margin-top:14px" });
  const code = el("input", { maxLength: 7, placeholder: "ABCDE", autocomplete: "off", style: "max-width:150px;text-transform:uppercase;letter-spacing:3px;text-align:center;font-size:1.2em" });
  const msg = el("p", { className: "small" }), err = el("p", { className: "err" });
  const run = async (body, needPw) => {
    err.textContent = ""; msg.textContent = "";
    if (!code.value.trim()) { err.textContent = "Escribe un código de ZYH Soporte."; code.focus(); return false; }
    try { const r = await api("admin/support/do", { method: "POST", body: { ...body, user: String(u.id), code: code.value.trim() } }); code.value = ""; toast(r.msg || "Hecho."); msg.textContent = r.msg || "Hecho."; return true; }
    catch (e) { err.textContent = e.message; return false; }
  };
  const pw = (ph) => el("input", { type: "password", autocomplete: "new-password", minLength: 8, maxLength: 72, placeholder: ph });
  const p1 = pw("contraseña nueva"), p2 = pw("repítela"), mc = el("input", { type: "checkbox", style: "width:auto;margin:0" });
  const nn = el("input", { maxLength: 32, placeholder: "nombre nuevo" }), n1 = pw("contraseña nueva"), n2 = pw("repítela");
  const checkPw = (a, b) => { if (a.value.length < 8) { err.textContent = "La contraseña debe tener al menos 8 caracteres."; return false; } if (a.value !== b.value) { err.textContent = "Las contraseñas no coinciden."; return false; } return true; };
  card.append(el("h3", { style: "margin-top:0" }, "@" + u.username, " ", el("small", { className: "muted" }, "ID " + u.code), " ",
      el("span", { className: "tag " + (u.locked ? "bad" : "ok"), textContent: u.locked ? "bloqueada por intentos" : "sin bloqueo" }),
      u.disabled ? el("span", { className: "tag bad", textContent: "baneada" }) : "", u.twofa ? el("span", { className: "tag", textContent: "dos pasos" }) : ""),
    el("p", { className: "small" }, `Correo: ${u.email || "(sin correo)"} · Rol: ${u.role} · Creada: ${fmtDate(u.created_at)} · Intentos fallidos (15 min): ${u.failed_logins}`),
    el("p", { className: "small" }, "Sesiones abiertas: ", u.sessions.length ? u.sessions.map((x) => `${x.label || (x.kind === "app" ? "App" : "Web")}`).join(" · ") : "ninguna"),
    el("div", { className: "row", style: "align-items:center;margin:12px 0" }, el("b", {}, "Código de ZYH Soporte:"), code),
    el("div", { className: "row" },
      el("button", { className: "btn sm", type: "button", textContent: "Desbloquear", onclick: async () => { if (await run({ action: "unlock" })) reload(); } }),
      el("button", { className: "btn ghost sm", type: "button", textContent: "Cerrar todas sus sesiones", onclick: async () => { if (await run({ action: "sessions" })) reload(); } }),
      u.twofa ? el("button", { className: "btn ghost sm", type: "button", textContent: "Quitar dos pasos", onclick: async () => { if (await run({ action: "no2fa" })) reload(); } }) : ""),
    el("h4", {}, "Poner contraseña nueva"), el("div", { className: "row" }, p1, p2),
    el("label", { style: "display:flex;gap:10px;align-items:center;margin:8px 0" }, mc, "Pedirle que la cambie al entrar"),
    el("button", { className: "btn sm", type: "button", textContent: "Cambiar contraseña", onclick: async () => {
      if (!checkPw(p1, p2)) return;
      if (await run({ action: "password", new_dk: await derive(u.username, p1.value), must_change: mc.checked })) { p1.value = p2.value = ""; reload(); }
    } }),
    el("h4", {}, "Cambiar nombre de usuario"), el("p", { className: "small muted" }, "La clave de la cuenta depende del nombre, así que al cambiarlo también se pone una contraseña nueva. Sus planes, licencias y chats se conservan."),
    el("div", { className: "row" }, nn, n1, n2),
    el("button", { className: "btn sm", type: "button", style: "margin-top:8px", textContent: "Cambiar nombre", onclick: async () => {
      const name = nn.value.trim().toLowerCase().replace(/^@/, "");
      if (!/^[a-z0-9_.-]{3,32}$/.test(name)) { err.textContent = "Nombre: 3 a 32 caracteres (letras, números, punto, guion o guion bajo)."; return; }
      if (!checkPw(n1, n2)) return;
      if (await run({ action: "rename", new_username: name, new_dk: await derive(name, n1.value) })) location.hash = "#/admin-soporte/" + encodeURIComponent(name);
    } }), msg, err);
  return card;
}

routes["admin-recuperacion"] = async () => {
  if (!state.user?.perms?.includes("cuentas.restablecer")) { location.hash = "#/"; return el("p", {}); }
  const { requests } = await api("admin/recovery");
  const frag = document.createDocumentFragment();
  const when = (t) => new Date(t * 1000).toLocaleString("es-CO");
  frag.append(el("p", { className: "small" }, el("a", { href: "#/admin" }, "← Administrar")), el("h1", {}, "Solicitudes para recuperar cuenta"),
    el("p", { className: "muted small" }, "Antes de aprobar, confirma que quien pide es el dueño: que el correo coincida y, si hace falta, escríbele por el medio de contacto que dejó. Al aprobar, la contraseña nueva que esa persona escribió queda activa y se cierran todas sus sesiones. Las solicitudes vencen a los 7 días."));
  if (!requests.length) frag.append(el("p", { className: "muted" }, "No hay solicitudes."));
  for (const r of requests) {
    const card = el("div", { className: "box wide", style: "margin-top:12px" });
    const ans = el("input", { maxLength: 300, placeholder: "Respuesta para la persona (opcional, la ve con su número)" });
    const no2 = el("input", { type: "checkbox", style: "width:auto;margin:0" }), err = el("p", { className: "err" });
    const decide = async (decision) => {
      err.textContent = "";
      if (decision === "aprobar" && !confirm(`¿Aprobar y cambiar la contraseña de ${r.username}?`)) return;
      try { await api("admin/recovery/" + r.id, { method: "POST", body: { decision, answer: ans.value, remove_2fa: no2.checked } }); toast(decision === "aprobar" ? "Cuenta recuperada." : "Solicitud rechazada."); render(); }
      catch (e) { err.textContent = e.message; }
    };
    const stTag = { pendiente: "warn", aprobada: "ok", rechazada: "bad", vencida: "bad" }[r.status] || "";
    card.append(el("div", { className: "row", style: "justify-content:space-between" }, el("h3", { style: "margin:0" }, "#" + r.id + " · ", r.exists ? el("a", { href: "#/admin-cuenta/" + r.user_id }, r.username) : r.username),
        el("span", { className: "tag " + stTag, textContent: r.status })),
      el("p", { className: "small" }, "Pedida: " + when(r.created_at)),
      !r.exists ? el("p", { className: "err" }, "Ese usuario no existe.") :
        el("p", { className: "small" }, "Correo que escribió: ", el("b", {}, r.email_given || "(ninguno)"), " · Correo de la cuenta: ", el("b", {}, r.email_real || "(sin correo)"), " ",
          el("span", { className: "tag " + (r.email_match ? "ok" : "bad"), textContent: r.email_match ? "coinciden" : "no coinciden" }),
          r.user_created ? " · Cuenta creada: " + fmtDate(r.user_created) : "", r.twofa ? " · Tiene verificación en dos pasos" : ""),
      el("p", { className: "small" }, "Contacto: ", el("b", {}, r.contact)), r.note ? el("p", { className: "small" }, "Nota: ", r.note) : "");
    if (r.status === "pendiente") {
      card.append(ans, r.twofa ? el("label", { style: "display:flex;gap:10px;align-items:center;margin:10px 0" }, no2, "Quitar también la verificación en dos pasos") : "",
        el("div", { className: "row", style: "margin-top:10px" },
          r.exists ? el("button", { className: "btn sm", type: "button", textContent: "Aprobar", onclick: () => decide("aprobar") }) : "",
          el("button", { className: "btn danger sm", type: "button", textContent: "Rechazar", onclick: () => decide("rechazar") })), err);
    } else if (r.decided_at) card.append(el("p", { className: "small muted" }, `Respondida por ${r.decided_name || "—"} el ${when(r.decided_at)}`, r.answer ? ": " + r.answer : ""));
    frag.append(card);
  }
  return frag;
};

routes["admin-business"] = async () => {
  const frag = document.createDocumentFragment();
  frag.append(el("p", { className: "small" }, el("a", { href: "#/admin" }, "← Administrar")), el("h1", {}, "ZYH Business: avisos, opiniones y solicitudes"));
  const [{ feedback, resumen }, { requests }, { news }, props] = await Promise.all([api("admin/feedback"), api("admin/requests"), api("admin/news"), api("zr/proposals").catch(() => ({ items: [] }))]);
  const when = (t) => new Date(t * 1000).toLocaleString("es-CO");
  // avisos
  const t = el("input", { placeholder: "Título del aviso", maxLength: 120 }), b = el("textarea", { placeholder: "Texto (opcional)", rows: 3, maxLength: 1200 });
  const app = el("select", {}, el("option", { value: "all" }, "Todas las apps"), el("option", { value: "business" }, "Solo ZYH Business"), el("option", { value: "zyphora" }, "Solo Zyphora"), el("option", { value: "pc" }, "Solo Business en PC"), el("option", { value: "phone" }, "Solo Business en celular"));
  const h = el("select", {}, ...[[1, "1 hora"], [6, "6 horas"], [24, "1 día"], [72, "3 días"], [168, "1 semana"], [720, "30 días"]].map(([x, t]) => el("option", { value: x }, t)));
  h.value = "24";
  const send = el("button", { className: "btn", textContent: "Publicar aviso", onclick: async () => { try { await api("admin/news", { method: "POST", body: { title: t.value, body: b.value, app: app.value, hours: +h.value } }); toast("Aviso publicado."); render(); } catch (e) { toast(e.message); } } });
  frag.append(el("div", { className: "box" }, el("h2", {}, "Avisos en Inicio"), el("p", { className: "muted small" }, "Salen en ZYH Noticias de ZYH Business y Zyphora y se borran solos cuando pasa el tiempo que elijas. ZYH Business en el celular las muestra máximo 24 horas."), t, b, el("div", { className: "row" }, app, h, send)));
  frag.append(el("div", { className: "box" }, el("h3", {}, "Avisos recientes"), ...(news.length ? news.map((n) => el("div", { className: "row", style: "justify-content:space-between" }, el("span", {}, `${n.title} · ${n.app} · ${when(n.at)}`),
    el("button", { className: "btn ghost sm", textContent: "Quitar", onclick: async () => { await api("admin/news/" + n.id, { method: "DELETE" }); render(); } }))) : [el("p", { className: "muted" }, "Sin avisos.")])));
  frag.append(el("div", { className: "box" }, el("h2", {}, "Opiniones"), el("p", { className: "muted small" }, resumen.map((r) => `${r.product}: ${r.avg} ★ (${r.n})`).join(" · ") || "Todavía no hay opiniones."),
    ...feedback.map((f) => el("p", { className: "small" }, el("b", {}, "★".repeat(f.stars)), ` ${f.username || "—"} · ${when(f.created_at)}`, f.comment ? el("br") : "", f.comment || ""))));
  frag.append(el("div", { className: "box" }, el("h2", {}, "Propuestas de mejora (centro de propuestas)"), ...(props.items.length ? props.items.map((q) => el("div", { className: "small", style: "margin:8px 0" },
    el("b", {}, q.title), ` · @${q.from || "—"} · ${q.app} · ${when(q.at)} · `, el("button", { className: "btn ghost sm", textContent: "Borrar", onclick: async () => { await api("admin/proposals/" + q.id, { method: "DELETE" }); render(); } }), el("br"), q.body)) : [el("p", { className: "muted" }, "Sin propuestas.")])));
  frag.append(el("div", { className: "box" }, el("h2", {}, "Solicitudes (otro tipo de negocio o función)"), ...(requests.length ? requests.map((q) => el("div", { className: "small", style: "margin:8px 0" }, el("b", {}, q.username || "—"), ` · ${when(q.created_at)} · `, el("button", { className: "btn ghost sm", textContent: "Borrar", onclick: async () => { await api("admin/requests/" + q.id, { method: "DELETE" }); render(); } }), el("br"), q.text)) : [el("p", { className: "muted" }, "Sin solicitudes.")])));
  return frag;
};
routes["admin-tienda"] = async () => {
  if (!state.user) { location.hash = "#/entrar"; return el("p", {}); }
  const [{ apps, open, can_publish }, earn] = await Promise.all([api("store/apps"), api("store/earnings")]);
  const frag = document.createDocumentFragment(), owner = !!state.user.owner;
  frag.append(el("p", { className: "small" }, el("a", { href: "#/admin" }, "← Administrar")), el("h1", {}, "Tienda ZYHT32"));
  if (owner) {
    const t = el("button", { className: "btn " + (open ? "danger" : ""), type: "button", textContent: open ? "Cerrar la tienda a otros creadores" : "Abrir la tienda a otros creadores",
      onclick: async () => { await api("store/open", { method: "PUT", body: { open: !open } }); toast(open ? "Tienda cerrada: solo tú publicas." : "Tienda abierta a creadores con permiso."); render(); } });
    frag.append(el("div", { className: "box wide" }, el("p", { className: "small" }, "Estado: ", el("b", {}, open ? "abierta a creadores" : "solo ZYH Studios (ZYHT32 aún no está en lanzamiento)")), t));
  }
  if (can_publish) {
    const f = el("form", { className: "box wide", style: "margin-top:14px" }), err = el("p", { className: "err" });
    const slug = el("input", { required: true, placeholder: "nombre-corto (igual a la carpeta zyht32/apps/…)", maxLength: 40 }), name = el("input", { required: true, maxLength: 60 });
    const desc = el("textarea", { rows: 4, maxLength: 1500 }), cat = el("input", { value: "Útiles", maxLength: 30 });
    const price = el("input", { type: "number", min: "0", max: "99", step: "0.01", value: "0" }), ver = el("input", { value: "1.0", maxLength: 12 }), pp = el("input", { placeholder: "ID del botón de pago de PayPal (si no es gratis)", maxLength: 30 });
    const pack = el("input", { type: "file", accept: ".zip" });
    f.append(el("h2", { style: "margin-top:0" }, "Publicar o actualizar una app"), el("label", {}, "Nombre corto"), slug, el("label", {}, "Nombre"), name, el("label", {}, "Descripción"), desc,
      el("label", {}, "Categoría"), cat, el("label", {}, "Precio en USD (0 = gratis; mínimo 0.99)"), price, el("label", {}, "Versión"), ver, el("label", {}, "Botón de PayPal"), pp,
      el("label", {}, "Paquete .zip (máx. 800 KB; solo zyht32/apps/<nombre>/ con main.zyht32, app.txt, icono.png)"), pack,
      el("p", { className: "small muted" }, "Las imágenes y videos se ponen en la carpeta public/tienda/<nombre-corto>/ (icono.png, imagenes/, videos/) y salen solos al desplegar."),
      el("div", { style: "margin-top:14px" }, el("button", { className: "btn", type: "submit", textContent: "Publicar" })), err);
    f.onsubmit = async (e) => { e.preventDefault(); err.textContent = "";
      try { const body = { slug: slug.value.trim(), name: name.value, description: desc.value, category: cat.value, price_usd: Number(price.value), version: ver.value, paypal_id: pp.value };
        if (pack.files[0]) body.pack = await fileB64(pack.files[0]);
        await api("store/apps", { method: "POST", body }); toast("App publicada."); render(); } catch (e2) { err.textContent = e2.message; } };
    frag.append(f);
  } else frag.append(el("p", { className: "box small" }, "Por ahora solo ZYH Studios puede publicar en la tienda."));
  frag.append(el("h2", {}, "Apps publicadas"));
  frag.append(apps.length ? el("div", { className: "scroll" }, el("table", {}, el("thead", {}, el("tr", {}, ...["App", "Autor", "Precio", "Descargas", ""].map((t) => el("th", {}, t)))),
    el("tbody", {}, ...apps.map((a) => el("tr", {}, el("td", {}, el("a", { href: "#/tienda-app/" + a.slug }, a.name)), el("td", {}, a.author), el("td", {}, a.price_usd ? money(a.price_usd) : "Gratis"), el("td", {}, a.downloads),
      el("td", {}, (owner || a.author === state.user.username) ? el("button", { className: "btn danger sm", type: "button", textContent: "Retirar",
        onclick: async () => { if (!confirm("¿Retirar " + a.name + " de la tienda?")) return; await api("store/apps/" + a.slug, { method: "DELETE" }); toast("Retirada."); render(); } }) : "")))))) : el("p", { className: "muted" }, "Aún no hay apps."));
  frag.append(el("h2", {}, earn.all ? "Ganancias (todas)" : "Tus ganancias"), el("p", { className: "small muted" }, "Reparto: 65% creador · 35% ZYH Studios."),
    el("div", { className: "scroll" }, el("table", {}, el("thead", {}, el("tr", {}, ...["App", "Autor", "Ventas", "Total", "Creador 65%", "ZYH 35%"].map((t) => el("th", {}, t)))),
      el("tbody", {}, ...earn.apps.map((a) => el("tr", {}, el("td", {}, a.name), el("td", {}, a.author), el("td", {}, a.sales), el("td", {}, money(a.gross_usd)), el("td", {}, money(a.creator_usd)), el("td", {}, money(a.studio_usd)))),
        el("tr", {}, el("td", {}, el("b", {}, "Total")), el("td", {}), el("td", {}, earn.totals.sales), el("td", {}, money(earn.totals.gross_usd)), el("td", {}, money(earn.totals.creator_usd)), el("td", {}, money(earn.totals.studio_usd)))))));
  return frag;
};

const loadScript = (src) => new Promise((ok, no) => { if (window.ZY) return ok(); const s = el("script", { src }); s.onload = ok; s.onerror = () => no(new Error("No se pudo cargar Zyphora.")); document.head.append(s); });
routes["zyphora"] = async () => { await loadScript("/zyphora.js"); return window.ZY.view(); };

routes["terminos"] = async () => {
  const frag = document.createDocumentFragment();
  frag.append(el("h1", {}, "Términos y condiciones"), el("div", { className: "box wide desc" },
    `1. Licencia de uso. ZYH Studios te concede una licencia personal e intransferible para usar sus apps según el plan contratado y el número de dispositivos permitido.

2. Pagos. Los planes se cobran por adelantado a través de PayPal. Los precios se expresan en dólares. ZYH Browser, ZYH ZVID y el ZYHT32 IDE son gratuitos.

3. Cuenta ZYH. Eres responsable de tu usuario y contraseña (mínimo 8 caracteres). No compartas tu cuenta: cada licencia cubre un número limitado de dispositivos.

4. Paquetes de la comunidad. Lo que subas debe ser tuyo o tener permiso de su autor. ZYH Studios revisa los paquetes antes de publicarlos y puede rechazarlos o retirarlos, pero no responde por el contenido de terceros.

5. Prohibido modificar, descompilar, piratear o redistribuir el software o su sistema de licencias.

6. Datos. Los datos de tus negocios se guardan en tu equipo. En esta web guardamos solo tu cuenta, tus licencias y los paquetes que subas.

7. Garantía. El software se entrega "tal cual", sin garantía de estar libre de errores.

8. Cambios. ZYH Studios puede actualizar estos términos y las funciones de las apps en futuras versiones.

© ZyhStudios.`));
  return frag;
};

// ------------------------------------------------------------------ arranque
$("#menu-btn").onclick = () => $("#nav").classList.toggle("open");
addEventListener("hashchange", render);
(async () => {
  try {
    const [cfg, me] = await Promise.all([api("config"), api("me")]);
    state.config = cfg; state.user = me.user;
    try { state.apps = (await (await fetch("/manifiesto.json")).json()).productos || []; } catch { state.apps = []; }
  } catch { state.config = { limits: { icon: 524288, image: 2097152, package: 15728640 }, plans: {}, paypal: "" }; }
  render();
  tiktokWelcome();
})();

// Al entrar a la web: invitación a la cuenta oficial de TikTok (el enlace lo cambia el equipo desde Administrar). Sale una vez por visita.
async function tiktokWelcome() {
  try { if (sessionStorage.getItem("zyh_tt")) return; } catch { /* sin almacenamiento: se muestra igual */ }
  let site; try { site = (await api("site")).site; } catch { return; }
  if (!site?.tiktok_url) return;
  const close = () => { try { sessionStorage.setItem("zyh_tt", "1"); } catch { /* nada */ } ov.remove(); };
  const ov = el("div", { className: "tt-ov", role: "dialog", "aria-modal": "true", "aria-label": "TikTok oficial" },
    el("div", { className: "tt-box" },
      el("div", { className: "z", textContent: "Z", style: "font-size:54px;line-height:1" }),
      el("h2", { style: "margin:8px 0 4px" }, "Entra a nuestra cuenta oficial"),
      el("p", { className: "tt-handle", textContent: "@zyh_studios" }),
      el("p", { className: "small muted" }, "Videos, novedades y cómo usar tus apps ZYH."),
      el("div", { className: "row", style: "justify-content:center;margin-top:14px" },
        el("a", { className: "btn", href: site.tiktok_url, target: "_blank", rel: "noopener noreferrer", textContent: "♪ Abrir TikTok", onclick: () => setTimeout(close, 50) }),
        el("button", { className: "btn ghost", type: "button", textContent: "Ahora no", onclick: close }))));
  ov.addEventListener("click", (e) => { if (e.target === ov) close(); });
  document.addEventListener("keydown", function esc(e) { if (e.key === "Escape") { document.removeEventListener("keydown", esc); close(); } });
  document.body.append(ov);
}
