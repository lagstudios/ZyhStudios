#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
==============================================================================
LAG STUDIOS - ZYH COMPRESSOR ENTERPRISE & ENGINE (V1.6 WINDOWS + LINUX)
==============================================================================
Cliente de Evaluación: Vercon
==============================================================================
Un solo código para Windows 10/11 y Linux. El formato .zyh (cabecera b'ZYH1')
es 100 % compatible con los archivos creados por la versión 1.5.

Novedades 1.6 (sin eliminar funciones de la 1.5):
- Motor por bloques (streaming): ya no carga archivos completos en RAM.
- RLE acelerado con expresiones regulares (decenas de veces más rápido).
- Nivel de compresión seleccionable (Rápida / Equilibrada / Máxima).
- Escritura atómica: si algo falla, no queda un .zyh a medio escribir.
- Protección contra rutas peligrosas al extraer (../, rutas absolutas).
- Rutas compatibles entre Windows y Linux dentro del .zyh.
- Errores ZYH-005/006/007/008/009 detectados de verdad.
- Visor del contenido de un .zyh (usa el inspector que ya existía).
- Interfaz sin congelarse: todo el trabajo pesado va en segundo plano.
"""

from __future__ import annotations

import sys
import os
import re
import json
import base64
import errno
import queue
import random
import string
import struct
import zlib
import bz2
import lzma

# --- ZYH: núcleo de licencias (verificación oculta; la app solo pregunta) ---
for _ZC in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_core"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "_core")):
    if os.path.isdir(os.path.join(_ZC, "zyhcore")):
        sys.path.insert(0, os.path.abspath(_ZC)); break
try:
    from zyhcore import guard as _zyh_guard
except Exception:
    _zyh_guard = None
import threading
import logging
import platform
import subprocess
from datetime import datetime, timedelta
from pathlib import Path, PurePosixPath
from typing import Optional, Dict, List, Callable, Tuple

APP_VERSION = "1.7 Bridged"
IS_WINDOWS = os.name == "nt"
PLATFORM_LABEL = "Windows" if IS_WINDOWS else "Linux"
CHUNK_SIZE = 4 * 1024 * 1024  # 4 MB por bloque: RAM baja y buena velocidad


def user_data_dir() -> Path:
    """Carpeta de datos del usuario, con permisos de escritura en ambos sistemas."""
    if IS_WINDOWS:
        base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or Path.home())
        path = base / "LagStudios" / "ZYH_Compressor"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (Path.home() / ".local" / "share"))
        path = base / "zyh_compressor"
    try:
        path.mkdir(parents=True, exist_ok=True)
    except OSError:
        path = Path.home()
    return path


LOG_FILE = user_data_dir() / "enterprise_audit.log"
_handlers: List[logging.Handler] = []
try:
    _handlers.append(logging.FileHandler(LOG_FILE, encoding="utf-8"))
except OSError:
    pass
if sys.stdout is not None:  # En el .exe sin consola stdout puede ser None
    _handlers.append(logging.StreamHandler(sys.stdout))
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s",
                    handlers=_handlers or [logging.NullHandler()])

try:
    import psutil
except ImportError:  # pragma: no cover - depende del equipo
    psutil = None

BG = "#071029"
PANEL = "#0b2340"
ACCENT = "#1e6fb3"
ACCENT_LIGHT = "#3aa0ff"
TEXT = "#E6F0FA"
MUTED = "#9FB3C8"


def fit_window(win, width, height, min_w=640, min_h=480, center=True):
    """Ajusta la ventana a la pantalla: nunca mas grande que ella, centrada, y F11 = pantalla completa."""
    try:
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w = max(320, min(width, int(sw * 0.94)))
        h = max(260, min(height, int(sh * 0.90)))
        win.minsize(min(min_w, w), min(min_h, h))
        x, y = max(0, (sw - w) // 2), max(0, (sh - h) // 3)
        win.geometry(f"{w}x{h}+{x}+{y}")
        if win.master is None and not getattr(win, "_fit_f11", False):
            win._fit_f11 = True
            win.bind("<F11>", lambda e: win.attributes("-fullscreen", not win.attributes("-fullscreen")))
            win.bind("<Escape>", lambda e: win.attributes("-fullscreen", False))
    except Exception:
        pass


def fmt_countdown(sec):
    sec = int(sec)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return f"{d} d  {h:02d}:{m:02d}:{s:02d}"

ADMIN_KEY = "LagStudiosAdmin2026"

COMPRESSION_LEVELS = {
    "Rápida (1)": 1,
    "Equilibrada (6)": 6,
    "Máxima (9)": 9,
}
DEFAULT_LEVEL_LABEL = "Equilibrada (6)"


# ==============================================================================
# SECCIÓN 1: MOTOR DE COMPRESIÓN Y CATÁLOGO DE ERRORES (ENGINE)
# ==============================================================================

class ZyhException(Exception):
    def __init__(self, code: str, title: str, description: str, solution: str):
        super().__init__(f"[{code}] {title}: {description}")
        self.code = code
        self.title = title
        self.description = description
        self.solution = solution


ZYH_ERRORS = {
    "ZYH-001": ("Encabezado Inválido", "El archivo seleccionado no tiene el encabezado mágico b'ZYH1'.", "Asegúrese de seleccionar un archivo .zyh legítimo o vuelva a generar el empaquetado."),
    "ZYH-002": ("Estructura Corrupta", "El índice de archivos o la tabla de metadatos está truncada.", "Solicite un reenvío del archivo .zyh original."),
    "ZYH-003": ("Suma de Comprobación CRC32 Fallida", "El contenido descomprimido no coincide con el checksum grabado.", "El archivo sufrió corrupción de bits durante la transmisión o almacenamiento."),
    "ZYH-004": ("Error de Descompresión RLE / Deflate", "No se pudo expandir el bloque de datos zlib/RLE.", "Compruebe la integridad de la memoria RAM o intente reparar el archivo."),
    "ZYH-005": ("Acceso Denegado a Disco", "No hay permisos para escribir el archivo de salida en el directorio de destino.", "Ejecute el programa con permisos apropiados o cambie la ruta de extracción."),
    "ZYH-006": ("Espacio Insuficiente en Disco", "No hay suficiente espacio libre en el almacenamiento para extraer el contenido.", "Libere espacio en el disco de destino e intente de nuevo."),
    "ZYH-007": ("Ruta de Extracción Demasiado Larga", "La ruta de destino supera el límite del sistema operativo.", "Extraiga el archivo en una ruta más corta (ej. C:\\zyh o /tmp)."),
    "ZYH-008": ("Archivo Protegido o Bloqueado", "El destino está siendo utilizado por otro proceso.", "Cierre las aplicaciones que puedan estar usando el archivo y reintente."),
    "ZYH-009": ("Desbordamiento de Memoria RAM", "El archivo descomprimido excede la memoria utilizable del sistema.", "Cierre aplicaciones pesadas para liberar memoria RAM."),
    "ZYH-010": ("Licencia Expirada o Inválida", "Su suscripción actual no permite procesar el archivo.", "Renueve o actualice su licencia en la pestaña de gestión de planes."),
    "ZYH-011": ("Ruta Insegura en el Archivo", "El .zyh intenta escribir fuera de la carpeta de destino (../ o ruta absoluta).", "No extraiga archivos .zyh de origen desconocido."),
}


def get_zyh_error(code: str) -> ZyhException:
    t, d, s = ZYH_ERRORS.get(code, ("Error Desconocido", "Ocurrió un fallo no documentado.", "Consulte con el soporte de ZYH Studios."))
    return ZyhException(code, t, d, s)


def os_error_to_zyh(exc: BaseException) -> ZyhException:
    """Traduce errores del sistema operativo al catálogo ZYH."""
    if isinstance(exc, ZyhException):
        return exc
    if isinstance(exc, MemoryError):
        return get_zyh_error("ZYH-009")
    if isinstance(exc, PermissionError):
        # En Windows un archivo abierto por otro programa da PermissionError (winerror 32/33)
        if getattr(exc, "winerror", None) in (32, 33):
            return get_zyh_error("ZYH-008")
        return get_zyh_error("ZYH-005")
    if isinstance(exc, OSError):
        if exc.errno == errno.ENOSPC or getattr(exc, "winerror", None) in (39, 112):
            return get_zyh_error("ZYH-006")
        if exc.errno == errno.ENAMETOOLONG or getattr(exc, "winerror", None) in (206,):
            return get_zyh_error("ZYH-007")
        if exc.errno in (errno.EBUSY, errno.ETXTBSY) or getattr(exc, "winerror", None) in (32, 33):
            return get_zyh_error("ZYH-008")
        if exc.errno == errno.EACCES:
            return get_zyh_error("ZYH-005")
    return get_zyh_error("ZYH-002")


# Una "corrida" RLE: el mismo byte repetido 4 veces o más.
_RUN_RE = re.compile(rb"(.)\1{3,}", re.DOTALL)
# Un token RLE: 0x00, longitud, valor.
_TOKEN_RE = re.compile(rb"\x00(.)(.)", re.DOTALL)
_ESCAPED_ZERO = b"\x00\x01\x00"


class ZyhEngine15:
    """Motor ZYH1. Mismo formato que la 1.5, implementación mucho más rápida.

    Formato del contenido: RLE propio (0x00 = escape) y después zlib.
      - corrida de 4..255 bytes iguales -> 00 LEN VAL
      - byte 0x00 suelto              -> 00 01 00
      - cualquier otro byte           -> literal
    """
    MAGIC_HEADER = b"ZYH1"
    MAGIC_V2 = b"ZYH2"                 # 2.x: 1 byte de algoritmo tras el encabezado
    LEVEL_ALGO = {1: 1, 6: 2, 9: 3}    # Rápida=DEFLATE · Equilibrada=BZIP2 · Máxima=LZMA

    @staticmethod
    def _new_comp(algo: int, level: int):
        if algo == 2:
            return bz2.BZ2Compressor(9)
        if algo == 3:
            return lzma.LZMACompressor(preset=9 | lzma.PRESET_EXTREME)
        return zlib.compressobj(level)

    class _NoFlush:
        def __init__(self, d): self.d = d
        def decompress(self, b): return self.d.decompress(b)
        def flush(self): return b""

    @classmethod
    def _new_decomp(cls, algo: int):
        if algo == 2:
            return cls._NoFlush(bz2.BZ2Decompressor())
        if algo == 3:
            return cls._NoFlush(lzma.LZMADecompressor())
        return zlib.decompressobj()

    # ---------------------------- RLE -------------------------------------
    @staticmethod
    def rle_encode(data: bytes) -> bytes:
        out: List[bytes] = []
        pos = 0
        for m in _RUN_RE.finditer(data):
            start, end = m.span()
            if start > pos:
                out.append(data[pos:start].replace(b"\x00", _ESCAPED_ZERO))
            value = data[start:start + 1]
            full, rest = divmod(end - start, 255)
            if full:
                out.append((b"\x00\xff" + value) * full)
            if rest >= 4:
                out.append(b"\x00" + bytes((rest,)) + value)
            elif rest:
                out.append((value * rest).replace(b"\x00", _ESCAPED_ZERO))
            pos = end
        if pos < len(data):
            out.append(data[pos:].replace(b"\x00", _ESCAPED_ZERO))
        return b"".join(out)

    @staticmethod
    def rle_decode_chunk(buf: bytes) -> Tuple[bytes, bytes]:
        """Decodifica lo que se pueda y devuelve (datos, resto_incompleto)."""
        out: List[bytes] = []
        pos = 0
        for m in _TOKEN_RE.finditer(buf):
            start = m.start()
            if start > pos:
                out.append(buf[pos:start])
            out.append(m.group(2) * m.group(1)[0])
            pos = m.end()
        rest = buf[pos:]
        zero = rest.find(b"\x00")
        if zero >= 0:  # token cortado al final del bloque: se completa con el siguiente
            out.append(rest[:zero])
            return b"".join(out), rest[zero:]
        out.append(rest)
        return b"".join(out), b""

    # ------------------ API compatible con la versión 1.5 -----------------
    @classmethod
    def compress_bytes(cls, data: bytes, level: int = 9) -> bytes:
        return zlib.compress(cls.rle_encode(data), level)

    @classmethod
    def decompress_bytes(cls, data: bytes) -> bytes:
        try:
            rle_data = zlib.decompress(data)
        except zlib.error:
            raise get_zyh_error("ZYH-004")
        decoded, tail = cls.rle_decode_chunk(rle_data)
        return decoded + tail  # igual que la 1.5: un token incompleto final se copia tal cual

    # --------------------------- Utilidades -------------------------------
    @staticmethod
    def archive_name(rel_path: str) -> str:
        """Ruta interna portable: siempre con '/'."""
        return rel_path.replace("\\", "/")

    @staticmethod
    def safe_output_path(dest_folder: str, rel_path: str) -> Path:
        name = rel_path.replace("\\", "/")
        parts = [p for p in PurePosixPath(name).parts if p not in ("", ".")]
        if not parts or name.startswith("/") or ".." in parts or re.match(r"^[A-Za-z]:", name):
            raise get_zyh_error("ZYH-011")
        if IS_WINDOWS:  # nombres válidos en Windows aunque el .zyh venga de Linux
            parts = [re.sub(r'[<>:"|?*\x00-\x1f]', "_", p).rstrip(" .") or "_" for p in parts]
        base = Path(dest_folder).resolve()
        out = base.joinpath(*parts)
        try:
            out.resolve().relative_to(base)
        except ValueError:
            raise get_zyh_error("ZYH-011")
        return out

    @staticmethod
    def collect_files(src: Path) -> List[Tuple[Path, str]]:
        if src.is_dir():
            files = []
            for f in sorted(src.rglob("*")):
                if f.is_file() and not f.is_symlink():
                    files.append((f, f.relative_to(src).as_posix()))
            return files
        return [(src, src.name)]

    # --------------------------- Comprimir --------------------------------
    @classmethod
    def compress_target(cls, src_path: str, dest_path: str, level: int = 6,
                        progress_cb: Optional[Callable[[float, str], None]] = None,
                        cancel_event: Optional[threading.Event] = None) -> int:
        """Crea un .zyh por bloques. Devuelve el número de archivos empaquetados."""
        src = Path(src_path)
        files = cls.collect_files(src)
        if not files:
            raise ValueError("La carpeta está vacía: no hay archivos para comprimir.")
        total_bytes = sum(max(f.stat().st_size, 1) for f, _ in files)
        done_bytes = 0
        dest = Path(dest_path)
        tmp = dest.with_name(dest.name + ".part")
        try:
            with open(tmp, "wb") as out_f:
                algo = cls.LEVEL_ALGO.get(level, 1)
                out_f.write(cls.MAGIC_V2)
                out_f.write(bytes([algo]))
                out_f.write(struct.pack(">I", len(files)))
                for idx, (file_path, rel_path) in enumerate(files, start=1):
                    path_bytes = cls.archive_name(rel_path).encode("utf-8")
                    if len(path_bytes) > 0xFFFF:
                        raise get_zyh_error("ZYH-007")
                    out_f.write(struct.pack(">H", len(path_bytes)))
                    out_f.write(path_bytes)
                    meta_pos = out_f.tell()
                    out_f.write(b"\x00" * 12)  # CRC32 + tamaño: se rellenan al terminar
                    comp = cls._new_comp(algo, level)
                    crc = 0
                    comp_size = 0
                    with open(file_path, "rb") as in_f:
                        while True:
                            if cancel_event is not None and cancel_event.is_set():
                                raise InterruptedError("Operación cancelada")
                            block = in_f.read(CHUNK_SIZE)
                            if not block:
                                break
                            crc = zlib.crc32(block, crc)
                            packed = comp.compress(cls.rle_encode(block))
                            if packed:
                                out_f.write(packed)
                                comp_size += len(packed)
                            done_bytes += len(block)
                            if progress_cb:
                                progress_cb(min(done_bytes / total_bytes, 0.999),
                                            f"Comprimiendo {idx}/{len(files)}: {rel_path}")
                    packed = comp.flush()
                    out_f.write(packed)
                    comp_size += len(packed)
                    end_pos = out_f.tell()
                    out_f.seek(meta_pos)
                    out_f.write(struct.pack(">I", crc & 0xFFFFFFFF))
                    out_f.write(struct.pack(">Q", comp_size))
                    out_f.seek(end_pos)
                    if file_path.stat().st_size == 0:
                        done_bytes += 1
            os.replace(tmp, dest)
        except BaseException:
            try:
                tmp.unlink()
            except OSError:
                pass
            raise
        if progress_cb:
            progress_cb(1.0, "Archivo .zyh generado exitosamente")
        logging.info("Comprimido %s -> %s (%d archivos, nivel %d)", src, dest, len(files), level)
        return len(files)

    # -------------------------- Descomprimir ------------------------------
    @classmethod
    def _read_exact(cls, f, size: int) -> bytes:
        data = f.read(size)
        if len(data) != size:
            raise get_zyh_error("ZYH-002")
        return data

    @classmethod
    def decompress_target(cls, archive_path: str, dest_folder: str,
                          progress_cb: Optional[Callable[[float, str], None]] = None,
                          cancel_event: Optional[threading.Event] = None) -> int:
        if not os.path.exists(archive_path):
            raise get_zyh_error("ZYH-002")
        archive_size = max(os.path.getsize(archive_path), 1)
        extracted_count = 0
        try:
            with open(archive_path, "rb") as f:
                magic = f.read(4)
                if magic == cls.MAGIC_V2:
                    algo = cls._read_exact(f, 1)[0]
                elif magic == cls.MAGIC_HEADER:
                    algo = 1
                else:
                    raise get_zyh_error("ZYH-001")
                total_files = struct.unpack(">I", cls._read_exact(f, 4))[0]
                for _ in range(total_files):
                    path_len_data = f.read(2)
                    if not path_len_data:
                        break  # mismo comportamiento tolerante que la 1.5
                    if len(path_len_data) != 2:
                        raise get_zyh_error("ZYH-002")
                    path_len = struct.unpack(">H", path_len_data)[0]
                    rel_path = cls._read_exact(f, path_len).decode("utf-8", errors="replace")
                    expected_crc = struct.unpack(">I", cls._read_exact(f, 4))[0]
                    comp_size = struct.unpack(">Q", cls._read_exact(f, 8))[0]

                    out_path = cls.safe_output_path(dest_folder, rel_path)
                    out_path.parent.mkdir(parents=True, exist_ok=True)
                    decomp = cls._new_decomp(algo)
                    carry = b""
                    crc = 0
                    remaining = comp_size
                    tmp_out = out_path.with_name(out_path.name + ".zyhpart")
                    try:
                        with open(tmp_out, "wb") as out_f:
                            while remaining > 0:
                                if cancel_event is not None and cancel_event.is_set():
                                    raise InterruptedError("Operación cancelada")
                                block = f.read(min(CHUNK_SIZE, remaining))
                                if not block:
                                    raise get_zyh_error("ZYH-002")
                                remaining -= len(block)
                                try:
                                    rle = decomp.decompress(block)
                                except (zlib.error, OSError, EOFError, lzma.LZMAError):
                                    raise get_zyh_error("ZYH-004")
                                if rle:
                                    data, carry = cls.rle_decode_chunk(carry + rle)
                                    if data:
                                        crc = zlib.crc32(data, crc)
                                        out_f.write(data)
                                if progress_cb:
                                    progress_cb(min(f.tell() / archive_size, 0.999), f"Extrayendo: {rel_path}")
                            try:
                                rle = decomp.flush()
                            except (zlib.error, OSError, EOFError, lzma.LZMAError):
                                raise get_zyh_error("ZYH-004")
                            data, carry = cls.rle_decode_chunk(carry + rle)
                            data += carry
                            if data:
                                crc = zlib.crc32(data, crc)
                                out_f.write(data)
                        if (crc & 0xFFFFFFFF) != expected_crc:
                            raise get_zyh_error("ZYH-003")
                        os.replace(tmp_out, out_path)
                    except BaseException:
                        try:
                            tmp_out.unlink()
                        except OSError:
                            pass
                        raise
                    extracted_count += 1
                    if progress_cb:
                        progress_cb(extracted_count / max(total_files, 1), f"Extraído: {rel_path}")
        except (ZyhException, InterruptedError):
            raise
        except (OSError, MemoryError) as exc:
            logging.exception("Error del sistema extrayendo %s", archive_path)
            raise os_error_to_zyh(exc)
        except Exception:
            logging.exception("Error inesperado extrayendo %s", archive_path)
            raise get_zyh_error("ZYH-002")
        logging.info("Extraído %s -> %s (%d archivos)", archive_path, dest_folder, extracted_count)
        return extracted_count


class ZyhArchiveInspector:
    @classmethod
    def inspect(cls, archive_path: str) -> List[Dict]:
        if not os.path.exists(archive_path):
            return []
        files_info = []
        try:
            with open(archive_path, "rb") as f:
                magic = f.read(4)
                if magic == ZyhEngine15.MAGIC_V2:
                    f.read(1)
                elif magic != ZyhEngine15.MAGIC_HEADER:
                    return []
                raw_files_count = f.read(4)
                if len(raw_files_count) < 4:
                    return []
                total_files = struct.unpack(">I", raw_files_count)[0]
                for _ in range(total_files):
                    path_len_data = f.read(2)
                    if len(path_len_data) < 2:
                        break
                    path_len = struct.unpack(">H", path_len_data)[0]
                    rel_path = f.read(path_len).decode("utf-8", errors="replace")
                    crc = struct.unpack(">I", f.read(4))[0]
                    comp_size = struct.unpack(">Q", f.read(8))[0]
                    f.seek(comp_size, os.SEEK_CUR)
                    files_info.append({
                        "filename": rel_path,
                        "crc32": f"{crc:08X}",
                        "comp_size": comp_size,
                    })
        except Exception:
            pass
        return files_info


# ==============================================================================
# SECCIÓN 2: TELEMETRÍA, LICENCIAS Y UTILIDADES
# ==============================================================================

def _hidden_run(cmd, timeout: int = 6) -> str:
    """Ejecuta un comando sin abrir ventanas de consola en Windows."""
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                         creationflags=flags, check=False, errors="replace")
    return out.stdout or ""


class HardwareInfo:
    @classmethod
    def get_cpu_name(cls) -> str:
        try:
            if IS_WINDOWS:
                import winreg  # type: ignore
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,
                                    r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as key:
                    return str(winreg.QueryValueEx(key, "ProcessorNameString")[0]).strip()
            with open("/proc/cpuinfo", encoding="utf-8", errors="ignore") as f:
                for line in f:
                    if line.lower().startswith(("model name", "hardware", "processor\t: arm")):
                        return line.split(":", 1)[1].strip()
        except Exception:
            pass
        return platform.processor() or platform.machine() or "CPU Genérica"

    @classmethod
    def get_gpu_info(cls) -> str:
        try:
            if IS_WINDOWS:
                out = _hidden_run(["powershell", "-NoProfile", "-Command",
                                   "(Get-CimInstance Win32_VideoController).Name"])
                gpus = [l.strip() for l in out.splitlines() if l.strip()]
                if not gpus:  # Windows antiguos: wmic
                    out = _hidden_run(["wmic", "path", "win32_VideoController", "get", "name"])
                    gpus = [l.strip() for l in out.splitlines() if l.strip() and "Name" not in l]
                return gpus[0] if gpus else "No detectado"
            out = _hidden_run(["lspci"])
            for line in out.splitlines():
                if re.search(r"vga|3d|display", line, re.IGNORECASE):
                    return line.split(": ", 1)[-1].strip()
        except Exception:
            pass
        return "No detectado"

    @classmethod
    def get_specs(cls) -> Dict[str, str]:
        total_ram = round(psutil.virtual_memory().total / (1024 ** 3), 2) if psutil else 0
        root = os.path.abspath(os.sep) if not IS_WINDOWS else (os.environ.get("SystemDrive", "C:") + "\\")
        try:
            disk_total = round((psutil.disk_usage(root).total if psutil else 0) / (1024 ** 3), 2)
        except Exception:
            disk_total = 0
        return {
            "CPU": cls.get_cpu_name(),
            "GPU": cls.get_gpu_info(),
            "RAM_TOTAL": f"{total_ram} GB",
            "DISKO": f"{disk_total} GB",
            "SO": f"{platform.system()} {platform.release()}",
        }


class SecureStorage:
    @classmethod
    def _get_path(cls) -> Path:
        # En Windows guarda dentro de AppData del Usuario para evitar PermissionError
        if IS_WINDOWS:
            base = Path(os.environ.get("APPDATA", Path.home())) / "LagStudios"
        else:
            base = Path.home() / ".lagstudios_sys"
        return base / "lic_sys.dat"

    @classmethod
    def save(cls, data: dict) -> bool:
        p = cls._get_path()
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            encoded = base64.b64encode(json.dumps(data).encode()).decode()
            tmp = p.with_suffix(".tmp")
            tmp.write_text(encoded, encoding="utf-8")
            os.replace(tmp, p)
            return True
        except Exception:
            return False

    @classmethod
    def read(cls) -> dict:
        p = cls._get_path()
        if not p.exists():
            return {}
        try:
            data = json.loads(base64.b64decode(p.read_text(encoding="utf-8").encode()).decode())
            return data if isinstance(data, dict) else {}
        except Exception:
            return {}

    @classmethod
    def delete_by_admin(cls, key: str) -> bool:
        if key != ADMIN_KEY:
            return False
        p = cls._get_path()
        if p.exists():
            try:
                os.remove(p)
                return True
            except Exception:
                return False
        return True


class LicenseManager:
    @classmethod
    def verify_or_register(cls, email: str, plan: str = "Lite", devices: int = 1) -> dict:
        ent = _zyh_guard.require("compressor") if _zyh_guard else None
        if ent:
            exp = datetime.fromtimestamp(ent.expires)
            return {"email": email, "licencia_id": "", "plan_activo": ent.label,
                    "dispositivos": ent.devices, "created_at": (exp - timedelta(days=30)).isoformat(),
                    "expires_at": exp.isoformat(), "active": True}
        return {"email": email, "licencia_id": "", "plan_activo": "Lite (prueba gratis)", "active": False}

        data = SecureStorage.read()
        now = datetime.now()

        if data:
            try:
                expires = datetime.fromisoformat(str(data["expires_at"]))
            except (KeyError, ValueError):
                return cls.change_plan(email, plan, devices)  # licencia dañada: se regenera
            if now > expires:
                data["active"] = False
                data["plan_activo"] = "Expirado"
                return data
            data["active"] = True
            return data

        return cls.change_plan(email, plan, devices)

    @classmethod
    def change_plan(cls, email: str, new_plan: str, devices: int = 1) -> dict:
        now = datetime.now()
        days = 60 if new_plan in ["V-Pro", "V-Pro+"] else 30
        exp = now + timedelta(days=days)
        base_id = "".join(random.choices(string.ascii_uppercase + string.digits, k=8))
        lic_id = f"{base_id}{devices}" if new_plan in ["V-Pro", "V-Pro+"] else base_id

        new_lic = {
            "email": email,
            "licencia_id": lic_id,
            "plan_activo": new_plan,
            "dispositivos": devices,
            "created_at": now.isoformat(),
            "expires_at": exp.isoformat(),
            "active": True,
        }
        SecureStorage.save(new_lic)
        return new_lic


def human_readable_size(n: int) -> str:
    step = 1024.0
    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(n)
    i = 0
    while size >= step and i < len(units) - 1:
        size /= step
        i += 1
    return f"{size:.2f} {units[i]}"


def folder_size(path: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for name in files:
            try:
                total += os.path.getsize(os.path.join(root, name))
            except OSError:
                pass
    return total


# ==============================================================================
# SECCIÓN 3: INTERFAZ GRÁFICA COMPRESOR
# ==============================================================================

def _load_gui():
    try:
        import customtkinter as ctk
        from tkinter import filedialog, messagebox
    except ImportError:
        print("Falta customtkinter o tkinter. Instala con: pip install customtkinter psutil")
        if not IS_WINDOWS:
            print("En Linux también: sudo apt install python3-tk")
        sys.exit(1)
    return ctk, filedialog, messagebox


ctk, filedialog, messagebox = (None, None, None)


def _enable_windows_dpi() -> None:
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass


class CompressorAppMixin:
    """Lógica de la ventana (separada para poder construirla tras importar CTk)."""

    # ----------------------------- arranque -------------------------------
    def _init_app(self):
        self.title(f"ZYH Compressor ({PLATFORM_LABEL} v{APP_VERSION})")
        fit_window(self, 1060, 720, 860, 560)
        self.configure(fg_color=BG)

        self.selected_path: Optional[str] = None
        self.is_folder = False
        self.busy = False
        self.cancel_event = threading.Event()
        self.ui_queue: "queue.Queue[Callable[[], None]]" = queue.Queue()
        self.process = psutil.Process(os.getpid()) if psutil else None
        self.current_lic = LicenseManager.verify_or_register("contacto@vercon.com", "Lite", devices=1)
        self.specs = {"CPU": "Detectando…", "GPU": "Detectando…", "RAM_TOTAL": "…", "DISKO": "…", "SO": PLATFORM_LABEL}

        ctk.set_appearance_mode("dark")
        ctk.set_default_color_theme("blue")

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)

        self._build_left_panel()
        self._build_right_panel()
        self.after(100, self._drain_ui_queue)
        self.after(500, self._start_resource_monitoring)
        threading.Thread(target=self._detect_hardware, daemon=True).start()

        if len(sys.argv) > 1 and sys.argv[1].lower().endswith(".zyh") and os.path.isfile(sys.argv[1]):
            self.selected_path = sys.argv[1]
            self.is_folder = False
            self._update_info()

    # ------------------------- utilidades de hilos ------------------------
    def _ui(self, fn: Callable[[], None]) -> None:
        """Programa una acción de interfaz desde cualquier hilo (Tk no es thread-safe)."""
        self.ui_queue.put(fn)

    def _drain_ui_queue(self):
        try:
            while True:
                self.ui_queue.get_nowait()()
        except queue.Empty:
            pass
        except Exception:
            logging.exception("Error en actualización de interfaz")
        self.after(80, self._drain_ui_queue)

    def _detect_hardware(self):
        specs = HardwareInfo.get_specs()

        def apply():
            self.specs = specs
            self.hw_label.configure(text=self._specs_text())
        self._ui(apply)

    def _specs_text(self) -> str:
        return (f"• CPU: {self.specs['CPU']}\n"
                f"• GPU: {self.specs['GPU']}\n"
                f"• RAM: {self.specs['RAM_TOTAL']}\n"
                f"• Disco: {self.specs['DISKO']}\n"
                f"• Sistema: {self.specs.get('SO', PLATFORM_LABEL)}")

    # ------------------------------ paneles -------------------------------
    def _build_left_panel(self):
        left = ctk.CTkFrame(self, fg_color=PANEL, corner_radius=12)
        left.grid(row=0, column=0, padx=16, pady=16, sticky="nsew")
        left.grid_columnconfigure(0, weight=1)
        left.grid_rowconfigure(5, weight=1)

        ctk.CTkLabel(left, text=f"Comprimidor Zyh Enterprise v{APP_VERSION}", font=ctk.CTkFont(size=18, weight="bold"), text_color=TEXT).grid(row=0, column=0, sticky="w", padx=14, pady=12)

        sel = ctk.CTkFrame(left, fg_color=PANEL, corner_radius=8)
        sel.grid(row=1, column=0, sticky="ew", padx=12, pady=(0, 8))
        sel.grid_columnconfigure(0, weight=1)
        self.path_label = ctk.CTkLabel(sel, text="Seleccione un archivo/carpeta o un archivo .zyh", anchor="w", text_color=MUTED, wraplength=430, justify="left")
        self.path_label.grid(row=0, column=0, sticky="ew", padx=8, pady=8)

        btns = ctk.CTkFrame(left, fg_color=PANEL, corner_radius=8)
        btns.grid(row=2, column=0, sticky="ew", padx=12, pady=(0, 8))
        btns.grid_columnconfigure((0, 1, 2), weight=1)
        ctk.CTkButton(btns, text="Buscar Archivo / .ZYH", fg_color=ACCENT, hover_color=ACCENT_LIGHT, command=self.browse_file).grid(row=0, column=0, padx=4, pady=6, sticky="ew")
        ctk.CTkButton(btns, text="Buscar Carpeta", fg_color=ACCENT, hover_color=ACCENT_LIGHT, command=self.browse_folder).grid(row=0, column=1, padx=4, pady=6, sticky="ew")
        ctk.CTkButton(btns, text="Ver contenido .ZYH", fg_color="#334e70", hover_color=ACCENT_LIGHT, command=self.inspect_archive).grid(row=0, column=2, padx=4, pady=6, sticky="ew")

        info = ctk.CTkFrame(left, fg_color=PANEL, corner_radius=8)
        info.grid(row=3, column=0, sticky="ew", padx=12, pady=(0, 8))
        info.grid_columnconfigure(1, weight=1)
        self.size_orig = ctk.CTkLabel(info, text="Tamaño: -", text_color=MUTED, anchor="w")
        self.size_orig.grid(row=0, column=0, sticky="w", padx=8, pady=2)
        ctk.CTkLabel(info, text="Compresión:", text_color=MUTED).grid(row=0, column=1, sticky="e", padx=(8, 4))
        self.level_var = ctk.StringVar(master=self, value=DEFAULT_LEVEL_LABEL)
        self.level_menu = ctk.CTkOptionMenu(info, values=list(COMPRESSION_LEVELS), variable=self.level_var, width=150, fg_color=ACCENT, button_color=ACCENT, button_hover_color=ACCENT_LIGHT)
        self.level_menu.grid(row=0, column=2, padx=8, pady=4)
        self.after(400, self._apply_level_limits)

        prog = ctk.CTkFrame(left, fg_color=PANEL, corner_radius=8)
        prog.grid(row=4, column=0, sticky="ew", padx=12, pady=(0, 12))
        prog.grid_columnconfigure((0, 1, 2), weight=1)

        self.progress = ctk.CTkProgressBar(prog)
        self.progress.set(0.0)
        self.progress.grid(row=0, column=0, columnspan=3, padx=12, pady=(8, 4), sticky="ew")

        self.progress_label = ctk.CTkLabel(prog, text=f"Estado: Listo ({PLATFORM_LABEL} v{APP_VERSION})", text_color=MUTED, anchor="w")
        self.progress_label.grid(row=1, column=0, columnspan=3, sticky="ew", padx=12, pady=(0, 4))

        self.compress_btn = ctk.CTkButton(prog, text="Comprimir a .ZYH", fg_color=ACCENT, hover_color=ACCENT_LIGHT, font=ctk.CTkFont(weight="bold"), command=self.start_compress)
        self.compress_btn.grid(row=2, column=0, padx=6, pady=(4, 8), sticky="ew")
        self.extract_btn = ctk.CTkButton(prog, text="Extraer .ZYH", fg_color="#16A34A", hover_color="#22C55E", font=ctk.CTkFont(weight="bold"), command=self.start_decompress)
        self.extract_btn.grid(row=2, column=1, padx=6, pady=(4, 8), sticky="ew")
        self.cancel_btn = ctk.CTkButton(prog, text="Cancelar", fg_color="#7f1d1d", hover_color="#b91c1c", state="disabled", command=self.cancel_job)
        self.cancel_btn.grid(row=2, column=2, padx=6, pady=(4, 8), sticky="ew")

        telemetry = ctk.CTkFrame(left, fg_color="#071029", corner_radius=8)
        telemetry.grid(row=5, column=0, sticky="nsew", padx=12, pady=(0, 12))
        ctk.CTkLabel(telemetry, text="Rendimiento en Vivo", font=ctk.CTkFont(size=13, weight="bold"), text_color=ACCENT_LIGHT).pack(anchor="w", padx=8, pady=(6, 2))

        self.app_metrics_lbl = ctk.CTkLabel(telemetry, text="Consumo App: CPU 0.0% | RAM 0 MB", text_color=TEXT, anchor="w")
        self.app_metrics_lbl.pack(anchor="w", padx=8, pady=2)
        self.sys_metrics_lbl = ctk.CTkLabel(telemetry, text="Sistema Global: CPU 0.0% | RAM 0.0%", text_color=MUTED, anchor="w")
        self.sys_metrics_lbl.pack(anchor="w", padx=8, pady=(0, 6))

    def _build_right_panel(self):
        right = ctk.CTkFrame(self, fg_color=PANEL, corner_radius=12)
        right.grid(row=0, column=1, padx=16, pady=16, sticky="nsew")
        right.grid_columnconfigure(0, weight=1)
        right.grid_rowconfigure(1, weight=1)

        hw_box = ctk.CTkFrame(right, fg_color="#071029", corner_radius=8)
        hw_box.grid(row=0, column=0, sticky="ew", padx=12, pady=12)
        ctk.CTkLabel(hw_box, text="Hardware Detectado", font=ctk.CTkFont(size=14, weight="bold"), text_color=ACCENT_LIGHT).pack(anchor="w", padx=10, pady=(6, 2))
        self.hw_label = ctk.CTkLabel(hw_box, text=self._specs_text(), text_color=TEXT, justify="left", wraplength=430)
        self.hw_label.pack(anchor="w", padx=10, pady=(0, 6))

        plans_box = ctk.CTkFrame(right, fg_color="#071029", corner_radius=8)
        plans_box.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 8))

        ctk.CTkLabel(plans_box, text="Gestión de Plan y Suscripción", font=ctk.CTkFont(size=14, weight="bold"), text_color=ACCENT_LIGHT).pack(anchor="w", padx=10, pady=(6, 4))

        self.plan_status_lbl = ctk.CTkLabel(plans_box, text=f"Plan Actual: {self.current_lic.get('plan_activo', 'Lite')}", font=ctk.CTkFont(weight="bold"), text_color="#22C55E")
        self.plan_status_lbl.pack(anchor="w", padx=10, pady=2)

        exp = str(self.current_lic.get("expires_at", ""))[:10]
        self.plan_exp_lbl = ctk.CTkLabel(plans_box, text=f"Vence: {exp or '—'}", text_color=MUTED)
        self.plan_exp_lbl.pack(anchor="w", padx=10, pady=0)

        self.cd_lbl = ctk.CTkLabel(plans_box, text="", font=ctk.CTkFont(size=18, weight="bold"), text_color=TEXT)
        self.cd_lbl.pack(anchor="w", padx=10, pady=(6, 0))
        self.cd_bar = ctk.CTkProgressBar(plans_box, height=8)
        self.cd_bar.pack(fill="x", padx=10, pady=(4, 2))
        self.cd_info = ctk.CTkLabel(plans_box, text="", text_color=MUTED, font=ctk.CTkFont(size=11))
        self.cd_info.pack(anchor="w", padx=10, pady=(0, 4))

        ctk.CTkButton(plans_box, text="Quiero un plan", fg_color=ACCENT, hover_color=ACCENT_LIGHT, font=ctk.CTkFont(weight="bold"), height=40, command=self.open_plans_window).pack(anchor="w", padx=10, pady=(10, 4), fill="x")
        self._tick_countdown()

        footer = ctk.CTkFrame(right, fg_color=PANEL, corner_radius=8)
        footer.grid(row=2, column=0, sticky="ew", padx=12, pady=(4, 12))
        footer.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(footer, text="ZYH Studios · licencia verificada en este equipo", text_color=MUTED).grid(row=0, column=0, padx=8, pady=6, sticky="w")
        self.lic_lbl = ctk.CTkLabel(footer, text="", text_color=MUTED)  # la ID del equipo nunca se muestra

    # ------------------------------- contador -------------------------------
    def _lic_span(self):
        lic = self.current_lic or {}
        try:
            return datetime.fromisoformat(str(lic["created_at"])), datetime.fromisoformat(str(lic["expires_at"]))
        except (KeyError, ValueError):
            return None

    def _tick_countdown(self):
        try:
            if not self.cd_lbl.winfo_exists(): return
            span = self._lic_span()
            if span is None:
                sin = "Sin vencimiento" if str(self.current_lic.get("expires_at", "")).startswith("2099") else "Sin fecha de pago"
                self.cd_lbl.configure(text=sin); self.cd_bar.set(1); self.cd_info.configure(text="")
            else:
                start, end = span
                total = max((end - start).total_seconds(), 1.0)
                left = max((end - datetime.now()).total_seconds(), 0.0)
                self.cd_lbl.configure(text=("Plan finalizado" if left <= 0 else "Quedan " + fmt_countdown(left)))
                self.cd_bar.set(min(1.0, max(0.0, 1 - left / total)))
                self.cd_info.configure(text=f"Pagado: {start:%Y-%m-%d %H:%M} · Termina: {end:%Y-%m-%d %H:%M}")
            self.after(1000, self._tick_countdown)
        except Exception:
            return

    # ------------------------------- planes -------------------------------
    def _refresh_plan_labels(self, plan: str):
        self.plan_status_lbl.configure(text=f"Plan Actual: {plan}")
        self.plan_exp_lbl.configure(text=f"Vence: {str(self.current_lic.get('expires_at', ''))[:10]}")
        self.lic_lbl.configure(text="")

    def apply_plan_change_direct(self):
        """Método original de la 1.5 (cambio directo desde self.plan_option)."""
        selected_raw = self.plan_option.get()
        clean_plan = selected_raw.split(" ")[0]
        devices = 15 if clean_plan == "V-Pro+" else (5 if clean_plan == "V-Pro" else 1)
        self.current_lic = LicenseManager.change_plan(email=self.current_lic.get("email", "contacto@vercon.com"), new_plan=clean_plan, devices=devices)
        self._refresh_plan_labels(clean_plan)
        messagebox.showinfo("Plan Actualizado", f"Activado plan: {clean_plan}")

    def _plan_price(self, plan: str, devices: int) -> float:
        """Precio mensual en dólares (mismo que la web de ZyhStudios)."""
        if plan == "Pro":
            return 4.62
        if plan == "V-Pro":
            return 7.69 + max(0, devices - 1) * 1.23
        if plan == "V-Pro+":
            return 15.38 + max(0, devices - 10) * 3.08
        return 0.0

    def open_plans_window(self):
        win = ctk.CTkToplevel(self)
        win.title("ZYH Compressor - Planes")
        fit_window(win, 1020, 610, 700, 440)
        win.configure(fg_color=BG)
        win.transient(self)
        win.after(150, win.lift)

        ctk.CTkLabel(win, text="Quiero un plan", font=ctk.CTkFont(size=28, weight="bold"), text_color=TEXT).pack(pady=(22, 4))
        ctk.CTkLabel(win, text="Elige el plan que se ajuste a tu cantidad de equipos. Plan Lite gratis: solo nivel 1, 5 usos o 5 días.", text_color=MUTED).pack(pady=(0, 16))

        selected_plan = ctk.StringVar(master=win, value="Pro")
        devices_var = ctk.StringVar(master=win, value="1")
        price_var = ctk.StringVar(master=win, value="US$4.62 / mes")
        device_hint = ctk.StringVar(master=win, value="1 equipo")

        cards = ctk.CTkFrame(win, fg_color="transparent")
        cards.pack(fill="both", expand=True, padx=18, pady=8)
        cards.grid_columnconfigure((0, 1, 2), weight=1)
        cards.grid_rowconfigure(0, weight=1)

        plan_cards = {}

        def select_plan(name: str):
            selected_plan.set(name)
            update_price()

        def update_price(*_):
            plan = selected_plan.get()
            try:
                devices = int(devices_var.get())
            except ValueError:
                devices = 1
            if plan == "Pro":
                devices = 1
                devices_var.set("1")
            elif plan == "V-Pro":
                devices = max(1, min(9, devices))
                devices_var.set(str(devices))
            elif plan == "V-Pro+":
                devices = max(10, devices)
                devices_var.set(str(devices))
            price = self._plan_price(plan, devices)
            price_var.set(f"US${price:,.2f} / mes")
            device_hint.set("1 equipo" if devices == 1 else f"{devices} equipos")
            for name, card in plan_cards.items():
                card.configure(border_width=2 if name == plan else 0, border_color=ACCENT_LIGHT)

        plan_data = [
            ("Pro", "US$4.62", "Para usuarios normales", "1 equipo", "Plan personal · al mes"),
            ("V-Pro", "US$7.69", "Para empresa mediana-pequeña", "1 a 9 equipos", "+US$1.23 por equipo adicional · al mes"),
            ("V-Pro+", "US$15.38", "Para empresas más grandes", "10 equipos hasta infinito", "+US$3.08 por equipo adicional · al mes"),
        ]

        for col, (name, price, desc, teams, extra) in enumerate(plan_data):
            card = ctk.CTkFrame(cards, fg_color="#071029", corner_radius=14, border_width=0)
            card.grid(row=0, column=col, padx=7, pady=6, sticky="nsew")
            plan_cards[name] = card
            ctk.CTkButton(card, text=name, fg_color=ACCENT, hover_color=ACCENT_LIGHT, font=ctk.CTkFont(size=20, weight="bold"), height=46, command=lambda n=name: select_plan(n)).pack(fill="x", padx=14, pady=(16, 12))
            ctk.CTkLabel(card, text=price, font=ctk.CTkFont(size=26, weight="bold"), text_color=TEXT).pack(pady=4)
            ctk.CTkLabel(card, text=desc, text_color=ACCENT_LIGHT, wraplength=250, justify="center").pack(pady=7)
            ctk.CTkLabel(card, text=teams, font=ctk.CTkFont(weight="bold"), text_color=TEXT).pack(pady=6)
            ctk.CTkLabel(card, text=extra, text_color=MUTED, wraplength=250, justify="center").pack(padx=12, pady=8)

        chooser = ctk.CTkFrame(win, fg_color="#071029", corner_radius=12)
        chooser.pack(fill="x", padx=25, pady=(4, 10))
        chooser.grid_columnconfigure(1, weight=1)
        ctk.CTkLabel(chooser, text="Equipos:", text_color=MUTED).grid(row=0, column=0, padx=(12, 6), pady=12)
        devices_entry = ctk.CTkEntry(chooser, textvariable=devices_var, width=90)
        devices_entry.grid(row=0, column=1, padx=6, pady=12, sticky="w")
        devices_entry.bind("<FocusOut>", update_price)
        devices_entry.bind("<Return>", update_price)
        ctk.CTkLabel(chooser, textvariable=device_hint, text_color=MUTED).grid(row=0, column=2, padx=8, pady=12)
        ctk.CTkLabel(chooser, text="Total:", text_color=MUTED).grid(row=0, column=3, padx=(20, 5), pady=12)
        ctk.CTkLabel(chooser, textvariable=price_var, font=ctk.CTkFont(size=18, weight="bold"), text_color="#22C55E").grid(row=0, column=4, padx=(0, 14), pady=12)

        def activate():
            plan = selected_plan.get()
            try:
                devices = int(devices_var.get())
            except ValueError:
                messagebox.showwarning("Plan", "La cantidad de equipos debe ser un número.", parent=win)
                return
            if plan == "Pro":
                devices = 1
            elif plan == "V-Pro" and not 1 <= devices <= 9:
                messagebox.showwarning("V-Pro", "V-Pro permite de 1 a 9 equipos.", parent=win)
                return
            elif plan == "V-Pro+" and devices < 10:
                messagebox.showwarning("V-Pro+", "V-Pro+ empieza desde 10 equipos.", parent=win)
                return
            messagebox.showinfo("Pagar plan", f"Plan: {plan}\nEquipos: {devices}\nTotal: {price_var.get()}\n\nPaga con PayPal en la web de ZyhStudios (sección Productos).\nTu plan se activa en tu cuenta ZYH y en este equipo cuando se verifique el pago.", parent=win)
            win.destroy()

        ctk.CTkButton(win, text="Continuar con este plan", fg_color="#16A34A", hover_color="#22C55E", height=42, font=ctk.CTkFont(weight="bold"), command=activate).pack(fill="x", padx=25, pady=(0, 8))
        self._zyh_account_row(win)
        ctk.CTkLabel(win, text="", height=1).pack(fill="x", padx=25, pady=(0, 10))
        update_price()
        return win

    def apply_plan_change(self):
        # Conserva el método original para no romper el resto del programa.
        self.open_plans_window()

    # ---------------------------- telemetría ------------------------------
    def _start_resource_monitoring(self):
        """Se ejecuta en el hilo de la interfaz cada segundo (psutil no bloquea)."""
        try:
            if psutil and self.process:
                app_cpu = self.process.cpu_percent(interval=None)
                app_ram_mb = self.process.memory_info().rss / (1024 * 1024)
                sys_cpu = psutil.cpu_percent(interval=None)
                sys_ram = psutil.virtual_memory().percent
                self.app_metrics_lbl.configure(text=f"Consumo App: CPU {app_cpu:.1f}% | RAM {app_ram_mb:.1f} MB")
                self.sys_metrics_lbl.configure(text=f"Sistema Global: CPU {sys_cpu:.1f}% | RAM {sys_ram:.1f}%")
            else:
                self.app_metrics_lbl.configure(text="Instala psutil para ver el consumo")
        except Exception:
            pass
        self.after(1000, self._start_resource_monitoring)

    # ----------------------------- selección ------------------------------
    def browse_file(self):
        p = filedialog.askopenfilename(parent=self, filetypes=[("Archivos Zyh", "*.zyh"), ("Todos los archivos", "*.*")])
        if p:
            self.selected_path = p
            self.is_folder = False
            self._update_info()

    def browse_folder(self):
        p = filedialog.askdirectory(parent=self)
        if p:
            self.selected_path = p
            self.is_folder = True
            self._update_info()

    def _update_info(self):
        if not self.selected_path:
            return
        self.path_label.configure(text=self.selected_path, text_color=TEXT)
        p = Path(self.selected_path)
        if self.is_folder:
            self.size_orig.configure(text="Tamaño: calculando…")
            path = self.selected_path

            def worker():
                total = folder_size(p)
                self._ui(lambda: self.selected_path == path and self.size_orig.configure(text=f"Tamaño: {human_readable_size(total)}"))
            threading.Thread(target=worker, daemon=True).start()
        else:
            try:
                self.size_orig.configure(text=f"Tamaño: {human_readable_size(p.stat().st_size)}")
            except OSError:
                self.size_orig.configure(text="Tamaño: -")

    def _progress_cb(self, p: float, msg: str):
        self._ui(lambda: (self.progress.set(p), self.progress_label.configure(text=msg)))

    def _set_busy(self, busy: bool):
        self.busy = busy
        state = "disabled" if busy else "normal"
        self.compress_btn.configure(state=state)
        self.extract_btn.configure(state=state)
        self.cancel_btn.configure(state="normal" if busy else "disabled")

    def cancel_job(self):
        self.cancel_event.set()
        self.progress_label.configure(text="Cancelando…")

    # ----------------------------- comprimir ------------------------------
    def _apply_level_limits(self) -> None:
        """Sin plan de pago (Lite) solo existe el nivel 1; con plan, los tres niveles."""
        try:
            paid = bool(_zyh_guard and _zyh_guard.require("compressor"))
            if paid:
                self.level_menu.configure(values=list(COMPRESSION_LEVELS))
            else:
                self.level_menu.configure(values=["Rápida (1)"]); self.level_var.set("Rápida (1)")
        except Exception:
            pass

    def _after_account(self) -> None:
        """Tras entrar con la cuenta ZYH: vuelve a leer el plan y ajusta la pantalla."""
        try:
            if _zyh_guard:
                _zyh_guard.refresh("compressor")
            self.current_lic = LicenseManager.verify_or_register("contacto@vercon.com", "Lite", devices=1)
            self._refresh_plan_labels(self.current_lic.get("plan_activo", "Sin plan"))
            self._apply_level_limits()
        except Exception:
            pass

    def _zyh_account_row(self, parent) -> None:
        """Entrar con la cuenta ZYH: así se activa aquí el plan comprado en la web."""
        try:
            import zyh_account_ui as AU
            u = AU.current_username()
        except Exception:
            return
        row = ctk.CTkFrame(parent, fg_color="transparent"); row.pack(fill="x", padx=25, pady=(0, 4))
        ctk.CTkLabel(row, text=(f"Cuenta ZYH: {u}" if u else "Sin cuenta ZYH en este equipo"),
                     text_color="#8bf5a2" if u else "#9aa4b8").pack(side="left", padx=(0, 10))
        ctk.CTkButton(row, text="Mi cuenta ZYH" if u else "Entrar con cuenta ZYH", height=32,
                      command=lambda: AU.open_dialog(parent, "compressor",
                                                     on_done=lambda: parent.after(100, self._after_account))).pack(side="left")

    def _zyh_plan_ok(self) -> bool:
        """Plan de pago activo = sigue. Sin plan = prueba Lite (solo nivel 1, 5 usos o 5 días, una por equipo)."""
        self._lite = False
        if _zyh_guard and _zyh_guard.require("compressor"):
            return True
        st = _zyh_guard.trial_use("compressor") if _zyh_guard else {"ok": False}
        if st.get("ok"):
            self._lite = True
            self.level_var.set("Rápida (1)")
            self.progress_label.configure(text=f"Plan Lite: solo nivel 1 · te quedan {st['uses_left']} usos o {st['days_left']} días")
            return True
        why = st.get("reason", "")
        msg = ("Tu prueba Lite de ZYH Compressor terminó (5 usos o 5 días).\nPara seguir comprimiendo y extrayendo necesitas un plan de pago."
               if why in ("prueba_terminada", "equipo_ya_uso", "cuenta_ya_uso", "")
               else "No se pudo usar la prueba Lite. Entra con tu cuenta ZYH o compra un plan.")
        if why == "equipo_ya_uso":
            msg = "La prueba Lite ya se usó en este equipo con otra cuenta.\nPara seguir necesitas un plan de pago."
        elif why == "cuenta_ya_uso":
            msg = "Esta cuenta ZYH ya usó su prueba Lite en otro equipo.\nPara seguir necesitas un plan de pago."
        messagebox.showinfo("Necesitas un plan", msg, parent=self)
        self.open_plans_window()
        return False

    def start_compress(self):
        if not self._zyh_plan_ok():
            return
        if self.busy:
            return
        if not self.selected_path:
            messagebox.showwarning("Atención", "Seleccione un archivo o carpeta primero.", parent=self)
            return
        src = Path(self.selected_path)
        dest = src.parent / f"{src.name}.zyh"
        level = 1 if getattr(self, "_lite", False) else COMPRESSION_LEVELS.get(self.level_var.get(), 6)   # Lite: solo el nivel 1
        self.cancel_event.clear()
        self._set_busy(True)
        self.progress.set(0)

        def worker():
            try:
                count = ZyhEngine15.compress_target(str(src), str(dest), level=level, progress_cb=self._progress_cb, cancel_event=self.cancel_event)
                size = dest.stat().st_size
                self._ui(lambda: messagebox.showinfo(f"Éxito v{APP_VERSION}", f"Empaquetado Zyh completado:\n{dest}\n\nArchivos: {count}\nTamaño final: {human_readable_size(size)}", parent=self))
            except InterruptedError:
                self._ui(lambda: (self.progress.set(0), self.progress_label.configure(text="Compresión cancelada")))
            except ValueError as e:
                msg = str(e)
                self._ui(lambda: messagebox.showwarning("Atención", msg, parent=self))
            except Exception as e:
                logging.exception("Error comprimiendo Zyh v%s", APP_VERSION)
                ze = os_error_to_zyh(e) if isinstance(e, (OSError, MemoryError)) else None
                msg = f"[{ze.code}] {ze.title}:\n{ze.description}\n\n{ze.solution}" if ze else f"Fallo al comprimir:\n{e}"
                self._ui(lambda: messagebox.showerror("Error", msg, parent=self))
            finally:
                self._ui(lambda: self._set_busy(False))

        threading.Thread(target=worker, daemon=True).start()

    # ----------------------------- extraer --------------------------------
    def start_decompress(self):
        if not self._zyh_plan_ok():
            return
        if self.busy:
            return
        if not self.selected_path or not self.selected_path.lower().endswith(".zyh"):
            messagebox.showwarning("Atención", "Seleccione un archivo con extensión .zyh válido.", parent=self)
            return
        dest_folder = filedialog.askdirectory(parent=self, title="Seleccione carpeta de extracción")
        if not dest_folder:
            return
        archive = self.selected_path
        self.cancel_event.clear()
        self._set_busy(True)
        self.progress.set(0)

        def worker():
            try:
                count = ZyhEngine15.decompress_target(archive, dest_folder, progress_cb=self._progress_cb, cancel_event=self.cancel_event)
                self._ui(lambda: (self.progress.set(1.0), self.progress_label.configure(text="Extracción completada"),
                                  messagebox.showinfo(f"Éxito v{APP_VERSION}", f"Extracción completada en:\n{dest_folder}\n\nArchivos: {count}", parent=self)))
            except InterruptedError:
                self._ui(lambda: (self.progress.set(0), self.progress_label.configure(text="Extracción cancelada")))
            except ZyhException as exc:
                title, text = f"Error [{exc.code}]", f"{exc.title}:\n{exc.description}\n\n{exc.solution}"
                self._ui(lambda: messagebox.showerror(title, text, parent=self))
            except Exception as e:
                msg = str(e)
                self._ui(lambda: messagebox.showerror("Error", f"Error inesperado al extraer:\n{msg}", parent=self))
            finally:
                self._ui(lambda: self._set_busy(False))

        threading.Thread(target=worker, daemon=True).start()

    # ------------------------------ inspector -----------------------------
    def inspect_archive(self):
        path = self.selected_path
        if not path or not path.lower().endswith(".zyh"):
            path = filedialog.askopenfilename(parent=self, title="Abrir .zyh", filetypes=[("Archivos Zyh", "*.zyh")])
            if not path:
                return
        files = ZyhArchiveInspector.inspect(path)
        if not files:
            messagebox.showwarning("Contenido .ZYH", "No es un .zyh válido o está vacío.", parent=self)
            return
        win = ctk.CTkToplevel(self)
        win.title(f"Contenido: {os.path.basename(path)}")
        fit_window(win, 720, 480, 560, 380)
        win.configure(fg_color=BG)
        win.transient(self)
        win.after(150, win.lift)
        total = sum(f["comp_size"] for f in files)
        ctk.CTkLabel(win, text=f"{len(files)} archivo(s) · {human_readable_size(total)} comprimidos", text_color=ACCENT_LIGHT, font=ctk.CTkFont(size=15, weight="bold")).pack(anchor="w", padx=14, pady=(12, 6))
        box = ctk.CTkTextbox(win, fg_color="#071029", text_color=TEXT, font=ctk.CTkFont(family="Consolas" if IS_WINDOWS else "DejaVu Sans Mono", size=12))
        box.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        lines = [f"{f['crc32']}  {human_readable_size(f['comp_size']):>11}  {f['filename']}" for f in files[:5000]]
        if len(files) > 5000:
            lines.append(f"… y {len(files) - 5000} más")
        box.insert("1.0", "CRC32     COMPRIMIDO   ARCHIVO\n" + "\n".join(lines))
        box.configure(state="disabled")
        return win

    # ------------------------------- admin --------------------------------
    def admin_panel(self):
        dialog = ctk.CTkInputDialog(text="Clave de administración:", title="Supervisor")
        key = dialog.get_input()
        if key and SecureStorage.delete_by_admin(key):
            messagebox.showinfo("Éxito", "Licencia reseteada.", parent=self)
            self.destroy()
        elif key:
            messagebox.showerror("Supervisor", "Clave incorrecta.", parent=self)


def build_app_class():
    class CompressorApp(CompressorAppMixin, ctk.CTk):
        def __init__(self):
            ctk.CTk.__init__(self)
            self._init_app()
    return CompressorApp


def cli_main(argv: List[str]) -> int:
    """Modo consola: útil en servidores y para automatizar (mismo motor)."""
    import argparse
    parser = argparse.ArgumentParser(prog="zyh_compressor", description=f"ZYH Compressor {APP_VERSION} ({PLATFORM_LABEL})")
    sub = parser.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("c", help="comprimir archivo o carpeta")
    c.add_argument("origen")
    c.add_argument("-o", "--salida")
    c.add_argument("-n", "--nivel", type=int, default=6, choices=range(0, 10))
    x = sub.add_parser("x", help="extraer .zyh")
    x.add_argument("archivo")
    x.add_argument("destino", nargs="?", default=".")
    l = sub.add_parser("l", help="listar contenido de .zyh")
    l.add_argument("archivo")
    args = parser.parse_args(argv)
    ent = _zyh_guard.require("compressor") if _zyh_guard else None
    if not (ent and ent.has("cli")):
        print("La línea de comandos es de los planes V-Pro y V-Pro+. Entra con tu cuenta ZYH desde la app o compra un plan en la web de ZyhStudios.", file=sys.stderr)
        return 3

    def prog(p, msg):
        print(f"\r{p * 100:5.1f}%  {msg[:70]:<70}", end="", flush=True)
    try:
        if args.cmd == "c":
            src = Path(args.origen)
            dest = Path(args.salida) if args.salida else src.parent / f"{src.name}.zyh"
            n = ZyhEngine15.compress_target(str(src), str(dest), level=args.nivel, progress_cb=prog)
            print(f"\nOK: {n} archivo(s) -> {dest} ({human_readable_size(dest.stat().st_size)})")
        elif args.cmd == "x":
            n = ZyhEngine15.decompress_target(args.archivo, args.destino, progress_cb=prog)
            print(f"\nOK: {n} archivo(s) extraídos en {args.destino}")
        else:
            for f in ZyhArchiveInspector.inspect(args.archivo):
                print(f"{f['crc32']}  {f['comp_size']:>12}  {f['filename']}")
        return 0
    except ZyhException as ze:
        print(f"\n[{ze.code}] {ze.title}: {ze.description}\n{ze.solution}", file=sys.stderr)
        return 2


def main():
    global ctk, filedialog, messagebox
    if len(sys.argv) > 1 and sys.argv[1] in ("c", "x", "l", "-h", "--help"):
        sys.exit(cli_main(sys.argv[1:]))
    import zyh_terms; zyh_terms.require("ZYH Compressor")   # términos: si no se aceptan, la app se cierra
    _enable_windows_dpi()
    ctk, filedialog, messagebox = _load_gui()
    app = build_app_class()()
    app.mainloop()


if __name__ == "__main__":
    main()
