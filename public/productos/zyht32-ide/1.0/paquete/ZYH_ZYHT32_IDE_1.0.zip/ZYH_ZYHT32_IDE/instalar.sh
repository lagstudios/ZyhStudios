#!/usr/bin/env bash
# ZYHT32 IDE — instalador (solo librerías de Python con --break-system-packages; no usa sudo)
DIR="$(cd "$(dirname "$0")" && pwd)"
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "Falta Python 3. Instálalo y repite."; exit 1; }
echo "Python: $($PY --version)"
$PY -m pip --version >/dev/null 2>&1 || $PY -m ensurepip --user >/dev/null 2>&1
$PY -m pip install --user --upgrade --break-system-packages customtkinter pillow pyserial esptool imageio-ffmpeg \
  || $PY -m pip install --user --upgrade customtkinter pillow pyserial esptool imageio-ffmpeg
$PY -c "import tkinter" 2>/dev/null || echo "AVISO: falta tkinter (paquete python3-tk de tu sistema); sin él la ventana no abre."
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/zyh-zyht32-ide.desktop" <<EOT
[Desktop Entry]
Type=Application
Name=ZYHT32 IDE
Exec=$PY "$DIR/app_completa/zyht32_ide.py"
Icon=$DIR/logo.png
Terminal=false
Categories=Utility;
EOT
echo "Listo. Abre \"ZYHT32 IDE\" desde tu menú de aplicaciones."
