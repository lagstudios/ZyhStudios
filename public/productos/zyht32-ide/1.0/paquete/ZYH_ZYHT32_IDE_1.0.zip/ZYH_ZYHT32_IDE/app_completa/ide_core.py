# -*- coding: utf-8 -*-
"""ZYHT32 IDE — lógica (sin interfaz): puertos, placa, particiones, OS, flasheo y compilación."""
import os, re, sys, json, glob, shutil, subprocess, threading, urllib.request

API = os.environ.get("ZYHT32_API", "https://api.github.com")
HOME = os.path.join(os.path.expanduser("~"), ".zyh", "zyht32")
FW_DIR = os.path.join(HOME, "firmware")
os.makedirs(FW_DIR, exist_ok=True)
SETTINGS = os.path.join(os.path.expanduser("~"), ".config", "zyh", "zyht32_ide", "settings.json")

CHIPS = {"ESP32-S3": "esp32s3", "ESP32": "esp32", "ESP32-S2": "esp32s2", "ESP32-C3": "esp32c3", "ESP32-C6": "esp32c6"}
FLASH_SIZES = ["4MB", "8MB", "16MB", "32MB"]
PSRAM_MODES = {"Desactivada": "disabled", "QSPI": "enabled", "OPI": "opi"}
BAUDS = ["115200", "460800", "921600"]
ESP32_JSON = "https://espressif.github.io/arduino-esp32/package_esp32_index.json"
LIBS = ["LovyanGFX", "SdFat", "ArduinoJson"]

ZYHT32_CSV = """# ZYHT32 OS - mapa de los 16 MB de flash (ESP32-S3 N16R8)
# Name,   Type, SubType,  Offset,   Size
nvs,      data, nvs,      0x9000,   0x5000,
otadata,  data, ota,      0xe000,   0x2000,
app0,     app,  ota_0,    0x10000,  0x400000,
app1,     app,  ota_1,    0x410000, 0x400000,
spiffs,   data, spiffs,   0x810000, 0x7E0000,
coredump, data, coredump, 0xFF0000, 0x10000,
"""

# nombre visible -> (esquema del core Arduino o None=CSV propio, flash mínimo MB)
PARTITION_PRESETS = {
    "ZYHT32 OS · 2×4 MB app + 7.9 MB /flash": ("__zyht32__", 16),
    "16 MB · 3 MB app + 9.9 MB FAT": ("app3M_fat9M_16MB", 16),
    "8 MB · por defecto": ("default_8MB", 8),
    "4 MB · por defecto (1.2 MB app + 1.5 MB datos)": ("default", 4),
    "4 MB · app enorme (3 MB, sin OTA)": ("huge_app", 4),
    "Personalizada": (None, 4),
}

DEFAULTS = {"chip": "ESP32-S3", "flash": "16MB", "psram": "OPI", "partition": "ZYHT32 OS · 2×4 MB app + 7.9 MB /flash",
            "custom_app_mb": 4.0, "custom_ota": True, "baud": "921600", "port": "",
            "repo": "ZYHStudios/ZYHT32_OS", "auto_update": True}


def load_settings():
    d = dict(DEFAULTS)
    try:
        d.update(json.load(open(SETTINGS, encoding="utf-8")))
    except Exception:
        pass
    return d


def save_settings(d):
    os.makedirs(os.path.dirname(SETTINGS), exist_ok=True)
    json.dump(d, open(SETTINGS, "w", encoding="utf-8"), indent=2)


# ------------------------------------------------------------------ puertos
def list_ports():
    """Puertos serie que detecta el sistema (kernel), con nombre amigable."""
    out = []
    try:
        from serial.tools import list_ports as lp
        for p in lp.comports():
            byid = ""
            for link in glob.glob("/dev/serial/by-id/*"):
                if os.path.realpath(link) == p.device:
                    byid = os.path.basename(link)
            desc = p.description if p.description and p.description != "n/a" else (p.product or "Puerto serie")
            vidpid = f"{p.vid:04X}:{p.pid:04X}" if p.vid is not None else ""
            chip = {"303A": "ESP32 USB nativo", "10C4": "CP210x", "1A86": "CH340/CH9102", "0403": "FTDI"}.get(
                f"{p.vid:04X}" if p.vid is not None else "", "")
            out.append({"device": p.device, "desc": desc, "vidpid": vidpid, "bridge": chip, "byid": byid})
    except Exception:
        pass
    return out


def port_label(p):
    extra = p["bridge"] or p["desc"]
    return f"{p['device']} · {extra}" if extra else p["device"]


# ------------------------------------------------------------------ esptool
def _esptool_v5():
    try:
        import esptool
        return int(str(esptool.__version__).split(".")[0]) >= 5
    except Exception:
        return False


def esptool_base():
    return [sys.executable, "-m", "esptool"]


def detect_cmd(port):
    return esptool_base() + ["--port", port, "flash-id" if _esptool_v5() else "flash_id"]


def parse_detect(text):
    """Lee el resultado de esptool: chip, flash y PSRAM."""
    info = {}
    m = re.search(r"Chip (?:is|type:)\s*(ESP32[-\w]*)", text, re.I)
    if m:
        name = m.group(1).upper().replace("ESP32S", "ESP32-S").replace("ESP32C", "ESP32-C")
        info["chip"] = name if name in CHIPS else "ESP32" if name == "ESP32" else name
    m = re.search(r"Detected flash size:\s*(\d+MB)", text, re.I)
    if m:
        info["flash"] = m.group(1).upper()
    m = re.search(r"Embedded PSRAM\s*(\d+MB)?", text, re.I)
    if m:
        info["psram_size"] = m.group(1) or "sí"
        info["psram"] = "OPI" if info.get("chip") == "ESP32-S3" and (m.group(1) or "") in ("8MB", "16MB") else "QSPI"
    m = re.search(r"MAC:\s*([0-9a-f:]{17})", text, re.I)
    if m:
        info["mac"] = m.group(1)
    return info


def flash_cmd(chip, port, baud, flash_size, files):
    """files = [(offset_hex, ruta)]"""
    v5 = _esptool_v5()
    cmd = esptool_base() + ["--chip", CHIPS.get(chip, "esp32s3"), "--port", port, "--baud", str(baud),
                            "write-flash" if v5 else "write_flash", "-z",
                            "--flash-size" if v5 else "--flash_size", flash_size]
    for off, path in files:
        cmd += [off, path]
    return cmd


def guess_offset(path):
    n = os.path.basename(path).lower()
    if any(k in n for k in ("merged", "factory", "full", "complete")):
        return "0x0"
    if "bootloader" in n:
        return "0x0"
    if "partition" in n:
        return "0x8000"
    if "boot_app0" in n:
        return "0xe000"
    return "0x10000"


# ------------------------------------------------------------------ particiones
def _mb(x):
    return int(round(x * 1024 * 1024))


def build_partitions(flash_mb, app_mb, ota=True, coredump=True):
    """Genera partitions.csv: tú eliges cuánto va a la app y el resto queda para datos (/flash)."""
    total = flash_mb * 1024 * 1024
    app = max(0x100000, (_mb(app_mb) // 0x10000) * 0x10000)
    rows = [("nvs", "data", "nvs", 0x9000, 0x5000)]
    if ota:
        rows.append(("otadata", "data", "ota", 0xE000, 0x2000))
    off = 0x10000
    rows.append(("app0", "app", "ota_0" if ota else "factory", off, app)); off += app
    if ota:
        rows.append(("app1", "app", "ota_1", off, app)); off += app
    cd = 0x10000 if coredump else 0
    data = total - off - cd
    if data < 0x20000:
        raise ValueError("La app no cabe: baja el tamaño de la app o desactiva OTA.")
    rows.append(("spiffs", "data", "spiffs", off, data)); off += data
    if coredump:
        rows.append(("coredump", "data", "coredump", off, cd))
    lines = ["# ZYHT32 IDE - particiones personalizadas", "# Name, Type, SubType, Offset, Size"]
    lines += [f"{n}, {t}, {s}, 0x{o:X}, 0x{z:X}," for n, t, s, o, z in rows]
    return "\n".join(lines) + "\n"


def parse_partitions(csv_text):
    out = []
    for ln in csv_text.splitlines():
        ln = ln.split("#")[0].strip()
        if not ln:
            continue
        parts = [p.strip() for p in ln.split(",")]
        if len(parts) >= 5 and parts[4]:
            out.append({"name": parts[0], "type": parts[1], "sub": parts[2], "size": int(parts[4], 0)})
    return out


def preset_csv(preset, flash_mb, app_mb, ota):
    scheme, _ = PARTITION_PRESETS.get(preset, (None, 4))
    if scheme == "__zyht32__":
        return ZYHT32_CSV
    if scheme is None:
        return build_partitions(flash_mb, app_mb, ota)
    return None  # esquema estándar del core


def fqbn(chip, flash, psram, preset):
    board = "esp32:esp32:" + CHIPS.get(chip, "esp32s3")
    opts = [f"FlashSize={flash.replace('MB', 'M')}"]
    if chip in ("ESP32-S3", "ESP32", "ESP32-S2"):
        opts.append(f"PSRAM={PSRAM_MODES.get(psram, 'disabled')}")
    scheme, _ = PARTITION_PRESETS.get(preset, (None, 4))
    if scheme and scheme != "__zyht32__":
        opts.append(f"PartitionScheme={scheme}")
    return board + ":" + ",".join(opts)


# ------------------------------------------------------------------ versiones del OS (GitHub)
def releases(repo, timeout=10):
    url = f"{API}/repos/{repo}/releases"
    req = urllib.request.Request(url, headers={"User-Agent": "ZYHT32-IDE", "Accept": "application/vnd.github+json"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        data = json.loads(r.read().decode())
    return parse_releases(data)


def parse_releases(data):
    out = []
    for rel in data:
        if rel.get("draft"):
            continue
        assets = [{"name": a["name"], "url": a["browser_download_url"], "size": a.get("size", 0)}
                  for a in rel.get("assets", []) if a["name"].lower().endswith(".bin")]
        out.append({"tag": rel.get("tag_name", "?"), "name": rel.get("name") or rel.get("tag_name", "?"),
                    "date": (rel.get("published_at") or "")[:10], "pre": bool(rel.get("prerelease")), "assets": assets})
    return out


def cached_versions():
    os.makedirs(FW_DIR, exist_ok=True)
    return sorted([d for d in os.listdir(FW_DIR) if os.path.isdir(os.path.join(FW_DIR, d))], reverse=True)


def download_release(rel, progress=None):
    dest = os.path.join(FW_DIR, rel["tag"])
    os.makedirs(dest, exist_ok=True)
    files = []
    for a in rel["assets"]:
        path = os.path.join(dest, a["name"])
        if not (os.path.exists(path) and os.path.getsize(path) == a["size"]):
            req = urllib.request.Request(a["url"], headers={"User-Agent": "ZYHT32-IDE"})
            with urllib.request.urlopen(req, timeout=60) as r, open(path + ".part", "wb") as f:
                total = int(r.headers.get("Content-Length") or a["size"] or 1); got = 0
                while True:
                    chunk = r.read(65536)
                    if not chunk:
                        break
                    f.write(chunk); got += len(chunk)
                    if progress:
                        progress(a["name"], got / max(1, total))
            os.replace(path + ".part", path)
        files.append(path)
    return files


# ------------------------------------------------------------------ arduino-cli
def arduino_cli():
    return shutil.which("arduino-cli") or shutil.which("arduino-cli.exe")


def setup_cmds():
    cli = arduino_cli() or "arduino-cli"
    return [[cli, "core", "update-index", "--additional-urls", ESP32_JSON],
            [cli, "core", "install", "esp32:esp32", "--additional-urls", ESP32_JSON],
            [cli, "lib", "install"] + LIBS]


def compile_cmd(fqbn_s, sketch_dir, out_dir, flags=None):
    cmd = [arduino_cli() or "arduino-cli", "compile", "--fqbn", fqbn_s, "--output-dir", out_dir]
    if flags:   # banderas de «Mi ZYHT32» (-DZYHT32_FEATURE_x=1…); se SUMAN a las del núcleo ESP32
        f = " ".join(flags)
        cmd += ["--build-property", "compiler.cpp.extra_flags=" + f, "--build-property", "compiler.c.extra_flags=" + f]
    return cmd + [sketch_dir]


def upload_cmd(fqbn_s, port, sketch_dir):
    return [arduino_cli() or "arduino-cli", "upload", "-p", port, "--fqbn", fqbn_s, sketch_dir]


# ------------------------------------------------------------------ ejecutar con salida en vivo
def run_stream(cmd, on_line, cwd=None):
    try:
        p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=cwd,
                             text=True, encoding="utf-8", errors="replace", bufsize=1)
    except FileNotFoundError:
        on_line(f"No se encontró: {cmd[0]}")
        return 127
    for line in p.stdout:
        on_line(line.rstrip("\n"))
    return p.wait()


SKETCH_TEMPLATE = """// Programa para ZYHT32 (ESP32-S3) — ZYHT32 IDE · ZYH Studios
#include <Arduino.h>

void setup() {
  Serial.begin(115200);
  delay(300);
  Serial.println("Hola desde mi ZYHT32!");
  Serial.printf("PSRAM libre: %u bytes\\n", ESP.getFreePsram());
}

void loop() {
  Serial.println(millis());
  delay(1000);
}
"""


# ------------------------------------------------------------------ última versión con .bin
def latest_release(repo):
    rels = [r for r in releases(repo) if r["assets"]]
    stable = [r for r in rels if not r["pre"]]
    return (stable or rels or [None])[0]


# ------------------------------------------------------------------ códigos OFICIALES (código fuente de GitHub)
import re, time, shutil, zipfile
SRC_DIR = os.path.join(HOME, "oficiales")
CUSTOM_DIR = os.path.join(HOME, "personalizadas")
SRC_EXT = (".ino", ".cpp", ".c", ".h", ".hpp", ".csv", ".json", ".txt", ".md", ".zs", ".zyht32", ".dvr")
FEATURES = {"WIFI": "WiFi", "SD": "Tarjeta SD", "USB_OTG": "USB OTG (teclado, mouse, SD)", "IA_GEMINI": "IA Gemini",
            "TERMINAL": "Terminal", "AUDIO": "Altavoz y micrófono", "BLE": "Bluetooth BLE"}


def safe_name(s):
    return re.sub(r"[^A-Za-z0-9._-]+", "_", str(s)).strip("._") or "x"


def _unzip_safe(zpath, dest):
    """Extrae un ZIP impidiendo rutas que salgan de la carpeta destino."""
    base = os.path.realpath(dest)
    with zipfile.ZipFile(zpath) as z:
        for n in z.namelist():
            t = os.path.realpath(os.path.join(base, n))
            if t != base and not t.startswith(base + os.sep):
                raise ValueError("ZIP con rutas inseguras: " + n)
        z.extractall(base)


def download_source(repo, ref="main", progress=None):
    """Descarga el código oficial (zipball de GitHub) y lo deja en oficiales/<ref>."""
    os.makedirs(SRC_DIR, exist_ok=True)
    dest = os.path.join(SRC_DIR, safe_name(ref))
    tmpz = dest + ".zip.part"; tmpd = dest + ".tmp"
    req = urllib.request.Request(f"{API}/repos/{repo}/zipball/{ref}", headers={"User-Agent": "ZYHT32-IDE"})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmpz, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0); got = 0
        while True:
            c = r.read(65536)
            if not c:
                break
            f.write(c); got += len(c)
            if progress:
                progress(ref, got / total if total else 0.5)
    shutil.rmtree(tmpd, ignore_errors=True); os.makedirs(tmpd)
    _unzip_safe(tmpz, tmpd); os.remove(tmpz)
    items = os.listdir(tmpd)
    root = os.path.join(tmpd, items[0]) if len(items) == 1 and os.path.isdir(os.path.join(tmpd, items[0])) else tmpd
    shutil.rmtree(dest, ignore_errors=True); shutil.move(root, dest); shutil.rmtree(tmpd, ignore_errors=True)
    return dest


def import_local_source(path):
    """Importa una carpeta o un .zip con el código oficial que ya tengas."""
    os.makedirs(SRC_DIR, exist_ok=True)
    name = safe_name(os.path.splitext(os.path.basename(path.rstrip("/\\")))[0])
    dest = os.path.join(SRC_DIR, name); shutil.rmtree(dest, ignore_errors=True)
    if os.path.isdir(path):
        shutil.copytree(path, dest, ignore=shutil.ignore_patterns(".git", "build"))
    else:
        os.makedirs(dest); _unzip_safe(path, dest)
    return dest


def list_sources():
    return sorted([d for d in os.listdir(SRC_DIR) if os.path.isdir(os.path.join(SRC_DIR, d))], reverse=True) if os.path.isdir(SRC_DIR) else []


def source_files(root, limit=600):
    out = []
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in (".git", "build", "node_modules")]
        for f in sorted(fn):
            if f.lower().endswith(SRC_EXT):
                out.append(os.path.relpath(os.path.join(dp, f), root))
                if len(out) >= limit:
                    return out
    return sorted(out)


# ------------------------------------------------------------------ MI ZYHT32 (versión personalizada)
def custom_header(cfg):
    q = lambda x: str(x).replace("\\", "").replace('"', "'")
    lines = ["// Generado por ZYHT32 IDE — no lo edites a mano (se rehace al compilar)", "#pragma once",
             "#define ZYHT32_CUSTOM 1", f'#define ZYHT32_CUSTOM_NAME "{q(cfg["name"])}"',
             f'#define ZYHT32_CUSTOM_VERSION "{q(cfg["version"])}"', f'#define ZYHT32_CUSTOM_BASE "{q(cfg.get("base", ""))}"']
    for k in FEATURES:
        lines.append(f"#define ZYHT32_FEATURE_{k} {1 if cfg['features'].get(k, True) else 0}")
    return "\n".join(lines) + "\n"


def custom_flags(cfg):
    return ["-DZYHT32_CUSTOM=1"] + [f"-DZYHT32_FEATURE_{k}={1 if cfg['features'].get(k, True) else 0}" for k in FEATURES]


def custom_sketch(root):
    """Carpeta del sketch principal dentro del proyecto (la que tiene el .ino)."""
    best = None
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d not in (".git", "build")]
        inos = [f for f in fn if f.endswith(".ino")]
        if inos:
            if os.path.basename(dp) + ".ino" in inos:
                return dp
            best = best or dp
    return best


def save_custom(root, cfg):
    with open(os.path.join(root, "zyht32_custom.json"), "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=1)
    sk = custom_sketch(root)
    if sk:
        with open(os.path.join(sk, "zyht32_custom.h"), "w", encoding="utf-8") as f:
            f.write(custom_header(cfg))
    return sk


def create_custom(name, version, features, base_dir=None):
    os.makedirs(CUSTOM_DIR, exist_ok=True)
    root = os.path.join(CUSTOM_DIR, safe_name(name))
    if os.path.exists(root):
        raise FileExistsError(f"Ya existe una versión llamada «{name}».")
    if base_dir:
        shutil.copytree(base_dir, root, ignore=shutil.ignore_patterns(".git", "build"))
    else:
        sk = os.path.join(root, safe_name(name)); os.makedirs(sk)
        with open(os.path.join(sk, safe_name(name) + ".ino"), "w", encoding="utf-8") as f:
            f.write(SKETCH_TEMPLATE)
    cfg = {"name": name, "version": version, "base": os.path.basename(base_dir) if base_dir else "(vacío)",
           "features": {k: bool(features.get(k, True)) for k in FEATURES}, "created": time.strftime("%Y-%m-%d %H:%M")}
    sk = save_custom(root, cfg)
    return root, cfg, sk


def list_custom():
    if not os.path.isdir(CUSTOM_DIR):
        return []
    return sorted(d for d in os.listdir(CUSTOM_DIR) if os.path.isfile(os.path.join(CUSTOM_DIR, d, "zyht32_custom.json")))


def load_custom(name):
    root = os.path.join(CUSTOM_DIR, name)
    with open(os.path.join(root, "zyht32_custom.json"), encoding="utf-8") as f:
        return root, json.load(f)


def custom_for_path(path):
    """Si el archivo está dentro de una versión personalizada devuelve (raíz, cfg)."""
    p = os.path.realpath(path); base = os.path.realpath(CUSTOM_DIR)
    if not p.startswith(base + os.sep):
        return None
    root = os.path.join(base, p[len(base) + 1:].split(os.sep)[0])
    try:
        return load_custom(os.path.basename(root))
    except Exception:
        return None
