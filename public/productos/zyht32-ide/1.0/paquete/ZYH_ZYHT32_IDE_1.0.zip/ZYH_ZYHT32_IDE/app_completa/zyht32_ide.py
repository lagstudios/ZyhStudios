# -*- coding: utf-8 -*-
"""ZYHT32 IDE · ZYH Studios
Entorno especializado para programar y actualizar tu ZYHT32 (ESP32):
  • Placa y puerto: puerto que detecta el sistema, detección de chip/flash/PSRAM,
    eliges particiones (o las haces a tu medida), PSRAM y velocidad.
  • Sistema (OS): descarga automática de la última versión del ZYHT32 OS (o eliges otra) y flasheo.
  • Mi ZYHT32: importa los códigos OFICIALES y crea tu propia versión del OS (funciones a tu gusto).
  • Programar: editor + compilar/subir con arduino-cli usando la config de la placa.
  • ZVID: convierte MP4 a video para la pantalla del ZYHT32.
  • Consola: salida en vivo y monitor serie.
"""
import os, sys, queue, threading, tempfile, time

_HERE = os.path.dirname(os.path.abspath(__file__))
for cand in (os.path.join(_HERE, "..", "..", "_core"), os.path.join(_HERE, "..", "_core")):
    if os.path.isdir(cand):
        sys.path.insert(0, os.path.abspath(cand)); break
sys.path.insert(0, _HERE)
import ide_core as I        # noqa
import zvid_core as Z       # noqa

ACCENT = "#ff5c8a"; VERSION = "1.0"


def main():
    import zyh_terms; zyh_terms.require("ZYHT32 IDE", ACCENT)   # términos: si no se aceptan, la app se cierra
    import customtkinter as ctk
    from tkinter import filedialog, messagebox
    import tkinter as tk
    import zyh_ui as U

    S = I.load_settings()
    sh = U.ZYHShell("ZYHT32 IDE", "zyht32_ide", plan_label="Gratis", accent=ACCENT, size=(1040, 720))
    acc = sh.ui["accent"]
    logq = queue.Queue()
    uiq = queue.Queue()      # los hilos NO tocan Tk: piden cambios de interfaz por esta cola

    def ui(fn):
        uiq.put(fn)
    st = {"ports": [], "busy": False, "serial": None, "rels": [], "src": None, "file": None}

    tabs = ctk.CTkTabview(sh.content, fg_color="#15112a", segmented_button_selected_color=acc,
                          segmented_button_selected_hover_color=U._lighten(acc, .1))
    tabs.pack(fill="both", expand=True, padx=4, pady=4)
    t_board, t_os, t_my, t_code, t_zvid, t_con = (tabs.add(n) for n in ("Placa y puerto", "Sistema (OS)", "Mi ZYHT32", "Programar", "ZVID", "Consola"))

    def log(line):
        logq.put(str(line))

    def busy_run(title, fn):
        if st["busy"]:
            messagebox.showinfo("ZYHT32 IDE", "Espera a que termine la tarea actual."); return
        st["busy"] = True; log(f"── {title} ──")

        def w():
            try:
                fn()
            except Exception as e:
                log(f"Error: {e}")
            finally:
                st["busy"] = False; log("── listo ──")
        threading.Thread(target=w, daemon=True).start()

    def lbl(parent, text, **kw):
        return ctk.CTkLabel(parent, text=text, anchor="w", **kw)

    # =============================================================== PLACA Y PUERTO
    left = ctk.CTkFrame(t_board, fg_color="transparent"); left.pack(side="left", fill="both", expand=True, padx=(8, 4), pady=8)
    right = ctk.CTkFrame(t_board, fg_color="#1b1530", corner_radius=12, width=330); right.pack(side="right", fill="y", padx=(4, 8), pady=8)

    lbl(left, "Puerto (lo detecta el sistema)", font=U.accent_font(13)).pack(fill="x")
    prow = ctk.CTkFrame(left, fg_color="transparent"); prow.pack(fill="x", pady=(2, 0))
    port_var = ctk.StringVar(value="")
    port_menu = ctk.CTkOptionMenu(prow, variable=port_var, values=["(buscando…)"], width=330, fg_color="#26203f",
                                  button_color=acc, button_hover_color=U._lighten(acc, .1))
    port_menu.pack(side="left")
    U.GlowButton(prow, accent=acc, text="Detectar placa", command=lambda: detect()).pack(side="left", padx=8)
    kern_lbl = lbl(left, "", text_color="#9a93b8", font=U.accent_font(11, False)); kern_lbl.pack(fill="x", pady=(2, 8))

    grid = ctk.CTkFrame(left, fg_color="transparent"); grid.pack(fill="x")
    chip_var = ctk.StringVar(value=S["chip"]); flash_var = ctk.StringVar(value=S["flash"])
    psram_var = ctk.StringVar(value=S["psram"]); part_var = ctk.StringVar(value=S["partition"]); baud_var = ctk.StringVar(value=S["baud"])
    for i, (t, var, vals) in enumerate([("ESP / chip", chip_var, list(I.CHIPS)), ("Memoria flash", flash_var, I.FLASH_SIZES),
                                        ("Velocidad (baudios)", baud_var, I.BAUDS)]):
        lbl(grid, t).grid(row=0, column=i, sticky="w", padx=4)
        ctk.CTkOptionMenu(grid, variable=var, values=vals, width=170, fg_color="#26203f", button_color=acc,
                          command=lambda *_: refresh_parts()).grid(row=1, column=i, padx=4, pady=(0, 8))
    lbl(left, "PSRAM").pack(fill="x")
    ctk.CTkSegmentedButton(left, values=list(I.PSRAM_MODES), variable=psram_var, selected_color=acc,
                           selected_hover_color=U._lighten(acc, .1), command=lambda *_: refresh_parts()).pack(anchor="w", pady=(0, 8))
    lbl(left, "Particiones (cómo se reparte la memoria flash)").pack(fill="x")
    ctk.CTkOptionMenu(left, variable=part_var, values=list(I.PARTITION_PRESETS), width=420, fg_color="#26203f",
                      button_color=acc, command=lambda *_: refresh_parts()).pack(anchor="w")
    custom = ctk.CTkFrame(left, fg_color="transparent"); custom.pack(fill="x", pady=4)
    app_lbl = lbl(custom, ""); app_lbl.pack(fill="x")
    app_slider = ctk.CTkSlider(custom, from_=1, to=12, number_of_steps=44, progress_color=acc, button_color=acc,
                               command=lambda v: refresh_parts())
    app_slider.set(S["custom_app_mb"]); app_slider.pack(fill="x")
    ota_sw = ctk.CTkSwitch(custom, text="2 ranuras OTA (actualizar sin cable)", progress_color=acc, command=lambda: refresh_parts())
    ota_sw.select() if S["custom_ota"] else ota_sw.deselect(); ota_sw.pack(anchor="w", pady=4)
    map_canvas = tk.Canvas(left, height=46, bg="#0b0814", highlightthickness=0); map_canvas.pack(fill="x", pady=(6, 2))
    part_info = lbl(left, "", text_color="#c9c3e6", font=U.accent_font(11, False)); part_info.pack(fill="x")
    fqbn_lbl = lbl(left, "", text_color="#9a93b8", font=("DejaVu Sans Mono", 10)); fqbn_lbl.pack(fill="x", pady=(4, 0))

    lbl(right, "Tu ZYHT32", font=U.accent_font(15), text_color=acc).pack(fill="x", padx=14, pady=(14, 4))
    board_info = lbl(right, "Conecta la placa por USB y pulsa\n«Detectar placa».", justify="left",
                     text_color="#eae6ff", font=U.accent_font(12, False)); board_info.pack(fill="x", padx=14)
    lbl(right, "\nModelo del ZYHT32 OS:\nESP32-S3 N16R8\n16 MB flash · 8 MB PSRAM OPI", justify="left",
        text_color="#9a93b8", font=U.accent_font(11, False)).pack(fill="x", padx=14)
    U.GlowButton(right, accent="#26203f", text_color="#eae6ff", text="Usar config del ZYHT32 OS",
                 command=lambda: use_zyht32()).pack(fill="x", padx=14, pady=(14, 4))
    U.GlowButton(right, accent="#26203f", text_color="#eae6ff", text="Guardar partitions.csv…",
                 command=lambda: save_csv()).pack(fill="x", padx=14, pady=4)

    COLORS = {"app": acc, "data": "#38d6ff", "nvs": "#ffd23f", "ota": "#9b6cff", "coredump": "#8bf5a2"}

    def current_csv():
        try:
            return I.preset_csv(part_var.get(), int(flash_var.get().replace("MB", "")), app_slider.get(), bool(ota_sw.get()))
        except ValueError as e:
            part_info.configure(text=str(e), text_color="#ff5468"); return None

    def refresh_parts(*_):
        is_custom = part_var.get() == "Personalizada"
        for w in custom.winfo_children():
            w.configure(state="normal" if is_custom else "disabled") if hasattr(w, "configure") and not isinstance(w, ctk.CTkLabel) else None
        app_lbl.configure(text=f"Tamaño de cada app: {app_slider.get():.2f} MB" if is_custom else "Tamaño de app: según el esquema elegido")
        csv = current_csv()
        map_canvas.delete("all")
        W = max(map_canvas.winfo_width(), 560)
        if csv:
            parts = I.parse_partitions(csv); total = sum(p["size"] for p in parts) + 0x9000
            x = W * 0x9000 / total
            for p in parts:
                w = W * p["size"] / total
                col = COLORS["app"] if p["type"] == "app" else COLORS.get(p["sub"], COLORS["data"])
                map_canvas.create_rectangle(x, 6, x + w, 40, fill=col, outline="#0b0814", width=2)
                if w > 60:
                    map_canvas.create_text(x + w / 2, 23, text=f"{p['name']} {p['size']/1048576:.1f}MB", fill="#0b0814",
                                           font=("DejaVu Sans", 9, "bold"))
                x += w
            apps = [p for p in parts if p["type"] == "app"]; data = [p for p in parts if p["sub"] in ("spiffs", "fat")]
            part_info.configure(text_color="#c9c3e6", text=f"App: {apps[0]['size']/1048576:.2f} MB × {len(apps)}   ·   "
                                f"Datos (/flash): {sum(d['size'] for d in data)/1048576:.2f} MB")
        else:
            map_canvas.create_text(W / 2, 23, text="Esquema estándar del core ESP32", fill="#9a93b8")
            part_info.configure(text_color="#c9c3e6", text="Se usa el esquema del core al compilar.")
        fqbn_lbl.configure(text="FQBN: " + I.fqbn(chip_var.get(), flash_var.get(), psram_var.get(), part_var.get()))
        S.update(chip=chip_var.get(), flash=flash_var.get(), psram=psram_var.get(), partition=part_var.get(),
                 custom_app_mb=round(app_slider.get(), 2), custom_ota=bool(ota_sw.get()), baud=baud_var.get())
        try: I.save_settings(S)
        except Exception: pass

    def use_zyht32():
        chip_var.set("ESP32-S3"); flash_var.set("16MB"); psram_var.set("OPI")
        part_var.set("ZYHT32 OS · 2×4 MB app + 7.9 MB /flash"); refresh_parts()

    def save_csv():
        csv = current_csv()
        if not csv:
            messagebox.showinfo("Particiones", "Este esquema es estándar del core; no necesita archivo."); return
        p = filedialog.asksaveasfilename(defaultextension=".csv", initialfile="partitions.csv")
        if p:
            open(p, "w").write(csv); log(f"Guardado: {p}")

    def sel_port():
        lab = port_var.get()
        for p in st["ports"]:
            if I.port_label(p) == lab:
                return p
        return None

    def poll_ports():
        ports = I.list_ports()
        ports.sort(key=lambda p: (p["vidpid"] == "", p["device"]))
        old = {p["device"] for p in st["ports"]}
        new = [p for p in ports if p["device"] not in old and p["vidpid"]]
        st["ports"] = ports
        labels = [I.port_label(p) for p in ports] or ["(ningún puerto)"]
        port_menu.configure(values=labels)
        if new:
            port_var.set(I.port_label(new[0])); log(f"Conectado: {I.port_label(new[0])}")
        elif port_var.get() not in labels:
            pick = next((I.port_label(p) for p in ports if p["device"] == S.get("port")), labels[0])
            port_var.set(pick)
        p = sel_port()
        kern_lbl.configure(text=(f"Kernel: {p['device']}  {('· ' + p['byid']) if p['byid'] else ''}  {('· USB ' + p['vidpid']) if p['vidpid'] else '· puerto del sistema'}"
                                 if p else "Conecta tu ZYHT32 por USB…"))
        if p:
            S["port"] = p["device"]
        sh.root.after(2500, poll_ports)

    def detect():
        p = sel_port()
        if not p:
            messagebox.showinfo("ZYHT32 IDE", "No hay puerto. Conecta la placa por USB."); return
        out = []

        def job():
            I.run_stream(I.detect_cmd(p["device"]), lambda l: (out.append(l), log(l)))
            info = I.parse_detect("\n".join(out))
            if info:
                def apply():
                    if info.get("chip") in I.CHIPS: chip_var.set(info["chip"])
                    if info.get("flash") in I.FLASH_SIZES: flash_var.set(info["flash"])
                    if info.get("psram"): psram_var.set(info["psram"])
                    board_info.configure(text=f"Chip: {info.get('chip','?')}\nFlash: {info.get('flash','?')}\n"
                                              f"PSRAM: {info.get('psram_size','no')}\nMAC: {info.get('mac','—')}")
                    refresh_parts()
                ui(apply)
            else:
                log("No se pudo leer la placa. Mantén BOOT, pulsa RESET, suelta BOOT y vuelve a intentar.")
        busy_run("Detectar placa", job)

    # =============================================================== SISTEMA (OS)
    lbl(t_os, "Repositorio del ZYHT32 OS en GitHub", font=U.accent_font(13)).pack(fill="x", padx=12, pady=(10, 0))
    rrow = ctk.CTkFrame(t_os, fg_color="transparent"); rrow.pack(fill="x", padx=12)
    repo_e = ctk.CTkEntry(rrow, width=360); repo_e.insert(0, S["repo"]); repo_e.pack(side="left")
    U.GlowButton(rrow, accent=acc, text="Buscar versiones", command=lambda: fetch()).pack(side="left", padx=8)
    auto_sw = ctk.CTkSwitch(t_os, text="Descargar automáticamente la última versión", progress_color=acc)
    auto_sw.select() if S["auto_update"] else auto_sw.deselect(); auto_sw.pack(anchor="w", padx=12, pady=8)
    lbl(t_os, "Versión").pack(fill="x", padx=12)
    ver_var = ctk.StringVar(value="(sin buscar)")
    ver_menu = ctk.CTkOptionMenu(t_os, variable=ver_var, values=["(sin buscar)"], width=420, fg_color="#26203f", button_color=acc)
    ver_menu.pack(anchor="w", padx=12)
    os_info = lbl(t_os, "", text_color="#9a93b8", font=U.accent_font(11, False), justify="left"); os_info.pack(fill="x", padx=12, pady=6)
    os_prog = ctk.CTkProgressBar(t_os, progress_color=acc); os_prog.set(0); os_prog.pack(fill="x", padx=12)
    orow = ctk.CTkFrame(t_os, fg_color="transparent"); orow.pack(fill="x", padx=12, pady=10)
    U.GlowButton(orow, accent="#25d366", text_color="#0b0814", text="⚡ Instalar la última versión", command=lambda: install_latest()).pack(side="left", padx=(0, 8))
    U.GlowButton(orow, accent=acc, text="Descargar", command=lambda: download()).pack(side="left", padx=(0, 8))
    U.GlowButton(orow, accent="#38d6ff", text="Flashear al ZYHT32", command=lambda: flash_selected()).pack(side="left", padx=8)
    U.GlowButton(orow, accent="#26203f", text_color="#eae6ff", text="Usar .bin local…", command=lambda: flash_local()).pack(side="left", padx=8)
    lbl(t_os, "Para flashear: mantén BOOT, pulsa RESET y suelta BOOT si la placa no entra sola en modo descarga.",
        text_color="#9a93b8", font=U.accent_font(11, False)).pack(fill="x", padx=12)

    def rel_by_label(lab):
        for r in st["rels"]:
            if lab.startswith(r["tag"]):
                return r
        return None

    def show_cache():
        c = I.cached_versions()
        os_info.configure(text=("En este equipo: " + ", ".join(c)) if c else "Aún no hay versiones descargadas.")

    def fetch(auto=False):
        S["repo"] = repo_e.get().strip(); S["auto_update"] = bool(auto_sw.get()); I.save_settings(S)

        def job():
            try:
                rels = I.releases(S["repo"])
            except Exception as e:
                log(f"No pude consultar GitHub ({e}). Revisa el repositorio o tu internet.")
                ui(show_cache); return
            st["rels"] = rels
            labels = [f"{r['tag']} · {r['date']}" + (" (última)" if i == 0 else "") + (" [beta]" if r["pre"] else "")
                      for i, r in enumerate(rels)] or ["(sin versiones publicadas)"]
            def apply():
                ver_menu.configure(values=labels); ver_var.set(labels[0]); show_cache()
                if auto and rels and rels[0]["tag"] not in I.cached_versions():
                    log(f"Nueva versión {rels[0]['tag']}: descargando…"); download()
            ui(apply)
            log(f"{len(rels)} versiones encontradas.")
        busy_run("Buscar versiones", job)

    def download():
        r = rel_by_label(ver_var.get())
        if not r:
            messagebox.showinfo("ZYHT32 IDE", "Primero busca versiones."); return
        def job():
            files = I.download_release(r, progress=lambda n, f: ui(lambda: os_prog.set(f)))
            for f in files: log(f"Descargado: {f}")
            ui(show_cache)
        busy_run(f"Descargar {r['tag']}", job)

    def do_flash(files):
        p = sel_port()
        if not p:
            messagebox.showinfo("ZYHT32 IDE", "Conecta la placa y elige el puerto."); return
        cmd = I.flash_cmd(chip_var.get(), p["device"], baud_var.get(), flash_var.get(), files)
        tabs.set("Consola")
        busy_run("Flashear", lambda: log("Resultado: " + ("OK ✓" if I.run_stream(cmd, log) == 0 else "falló")))

    def flash_selected():
        r = rel_by_label(ver_var.get())
        tag = r["tag"] if r else (I.cached_versions() or [None])[0]
        if not tag:
            messagebox.showinfo("ZYHT32 IDE", "Descarga una versión primero."); return
        d = os.path.join(I.FW_DIR, tag); bins = sorted(f for f in os.listdir(d) if f.endswith(".bin"))
        if not bins:
            messagebox.showinfo("ZYHT32 IDE", "Esa versión no tiene .bin descargados."); return
        do_flash([(I.guess_offset(b), os.path.join(d, b)) for b in bins])

    def install_latest():
        p = sel_port()
        if not p:
            messagebox.showinfo("ZYHT32 IDE", "Conecta la placa y elige el puerto en «Placa y puerto»."); return
        S["repo"] = repo_e.get().strip(); I.save_settings(S); tabs.set("Consola")

        def job():
            rel = I.latest_release(S["repo"])
            if not rel:
                log("Ese repositorio no tiene versiones con archivos .bin publicados. Revisa el nombre del repositorio."); return
            log(f"Última versión: {rel['tag']} ({rel['date']})")
            files = I.download_release(rel, progress=lambda n, f: ui(lambda: os_prog.set(f)))
            ui(show_cache)
            cmd = I.flash_cmd(chip_var.get(), p["device"], baud_var.get(), flash_var.get(), [(I.guess_offset(f), f) for f in files])
            log("Resultado: " + ("OK ✓ — tu ZYHT32 ya tiene " + rel["tag"] if I.run_stream(cmd, log) == 0 else "falló (revisa el modo descarga: BOOT + RESET)"))
        busy_run("Instalar la última versión", job)

    def flash_local():
        p = filedialog.askopenfilename(filetypes=[("Firmware", "*.bin")])
        if p:
            do_flash([(I.guess_offset(p), p)])

    # =============================================================== MI ZYHT32
    mcol_l = ctk.CTkScrollableFrame(t_my, fg_color="#1b1530", corner_radius=12); mcol_l.pack(side="left", fill="both", expand=True, padx=(8, 4), pady=8)
    mcol_r = ctk.CTkScrollableFrame(t_my, fg_color="#1b1530", corner_radius=12); mcol_r.pack(side="right", fill="both", expand=True, padx=(4, 8), pady=8)

    # ---- izquierda: códigos oficiales
    lbl(mcol_l, "1 · Códigos oficiales del ZYHT32", font=U.accent_font(14)).pack(fill="x", padx=12, pady=(10, 0))
    lbl(mcol_l, "Importa el código fuente oficial (del repositorio que pusiste en «Sistema (OS)») para leerlo, usarlo de ejemplo o partir de él para tu versión.",
        text_color="#9a93b8", wraplength=420, justify="left", font=U.accent_font(11, False)).pack(fill="x", padx=12)
    ref_var = ctk.StringVar(value="main")
    ref_menu = ctk.CTkOptionMenu(mcol_l, variable=ref_var, values=["main"], width=260, fg_color="#26203f", button_color=acc); ref_menu.pack(anchor="w", padx=12, pady=(8, 2))
    srow = ctk.CTkFrame(mcol_l, fg_color="transparent"); srow.pack(fill="x", padx=12, pady=2)
    src_var = ctk.StringVar(value="(ninguno importado)")
    src_menu = ctk.CTkOptionMenu(mcol_l, variable=src_var, values=["(ninguno importado)"], width=260, fg_color="#26203f", button_color=acc,
                                 command=lambda _v: refresh_src_files())
    file_var = ctk.StringVar(value="(elige un código importado)")
    file_menu = ctk.CTkOptionMenu(mcol_l, variable=file_var, values=["(elige un código importado)"], width=420, fg_color="#26203f", button_color=acc)
    base_var = ctk.StringVar(value="(proyecto vacío)")

    def refresh_sources(select=None):
        names = I.list_sources(); vals = names or ["(ninguno importado)"]
        src_menu.configure(values=vals); src_var.set(select if select in names else vals[0])
        base_menu.configure(values=["(proyecto vacío)"] + names)
        refresh_src_files()

    def refresh_src_files():
        n = src_var.get()
        if n in I.list_sources():
            fl = I.source_files(os.path.join(I.SRC_DIR, n)) or ["(sin archivos de código)"]
        else:
            fl = ["(elige un código importado)"]
        file_menu.configure(values=fl); file_var.set(fl[0])

    def refresh_refs():
        tags_ = [r["tag"] for r in st["rels"]]
        ref_menu.configure(values=["main"] + tags_)

    def import_github():
        S["repo"] = repo_e.get().strip(); I.save_settings(S); ref = ref_var.get()

        def job():
            if not st["rels"]:
                try:
                    st["rels"] = I.releases(S["repo"]); ui(refresh_refs)
                except Exception:
                    pass
            d = I.download_source(S["repo"], ref, progress=lambda n, f: ui(lambda: my_prog.set(f)))
            log(f"Código oficial «{ref}» importado en {d}")
            ui(lambda: refresh_sources(os.path.basename(d)))
        busy_run(f"Importar código oficial {ref}", job)

    def import_local():
        p = filedialog.askopenfilename(filetypes=[("ZIP del código oficial", "*.zip")]) or filedialog.askdirectory(title="…o elige la carpeta")
        if p:
            try:
                d = I.import_local_source(p); log(f"Importado: {d}"); refresh_sources(os.path.basename(d))
            except Exception as e:
                messagebox.showerror("ZYHT32 IDE", str(e))

    def open_official():
        n, f = src_var.get(), file_var.get()
        p = os.path.join(I.SRC_DIR, n, f)
        if os.path.isfile(p):
            open_path(p); tabs.set("Programar")

    def open_folder(path):
        if not os.path.isdir(path):
            return
        import subprocess
        try:
            if sys.platform.startswith("win"):
                os.startfile(path)        # noqa
            else:
                subprocess.Popen(["open" if sys.platform == "darwin" else "xdg-open", path])
        except Exception as e:
            log(f"No pude abrir la carpeta: {e}")

    U.GlowButton(srow, accent=acc, text="Importar de GitHub", command=import_github).pack(side="left")
    U.GlowButton(srow, accent="#26203f", text_color="#eae6ff", text="Importar ZIP/carpeta…", command=import_local).pack(side="left", padx=8)
    my_prog = ctk.CTkProgressBar(mcol_l, progress_color=acc); my_prog.set(0); my_prog.pack(fill="x", padx=12, pady=6)
    lbl(mcol_l, "Códigos importados").pack(fill="x", padx=12); src_menu.pack(anchor="w", padx=12)
    lbl(mcol_l, "Archivo").pack(fill="x", padx=12, pady=(8, 0)); file_menu.pack(anchor="w", padx=12)
    brow = ctk.CTkFrame(mcol_l, fg_color="transparent"); brow.pack(fill="x", padx=12, pady=8)
    U.GlowButton(brow, accent="#38d6ff", text_color="#0b0814", text="Abrir en el editor", command=open_official).pack(side="left")
    U.GlowButton(brow, accent="#26203f", text_color="#eae6ff", text="Abrir carpeta", command=lambda: open_folder(os.path.join(I.SRC_DIR, src_var.get()))).pack(side="left", padx=8)

    # ---- derecha: mi versión
    lbl(mcol_r, "2 · Mi versión del ZYHT32", font=U.accent_font(14)).pack(fill="x", padx=12, pady=(10, 0))
    lbl(mcol_r, "Parte de un código oficial (o de cero), activa o apaga funciones y compílala con tu placa. El IDE genera zyht32_custom.h y pasa las banderas -DZYHT32_FEATURE_… para que el código las use con #if.",
        text_color="#9a93b8", wraplength=420, justify="left", font=U.accent_font(11, False)).pack(fill="x", padx=12)
    lbl(mcol_r, "Nombre de tu versión").pack(fill="x", padx=12, pady=(8, 0))
    name_e = ctk.CTkEntry(mcol_r, width=300); name_e.insert(0, "Mi ZYHT32"); name_e.pack(anchor="w", padx=12)
    lbl(mcol_r, "Versión").pack(fill="x", padx=12, pady=(6, 0))
    ver_e = ctk.CTkEntry(mcol_r, width=140); ver_e.insert(0, "1.0-mia"); ver_e.pack(anchor="w", padx=12)
    lbl(mcol_r, "Partir de").pack(fill="x", padx=12, pady=(6, 0))
    base_menu = ctk.CTkOptionMenu(mcol_r, variable=base_var, values=["(proyecto vacío)"], width=260, fg_color="#26203f", button_color=acc); base_menu.pack(anchor="w", padx=12)
    lbl(mcol_r, "Funciones").pack(fill="x", padx=12, pady=(8, 0))
    feat_sw = {}
    for k, nm in I.FEATURES.items():
        sw = ctk.CTkSwitch(mcol_r, text=nm, progress_color=acc); sw.select(); sw.pack(anchor="w", padx=18, pady=1); feat_sw[k] = sw
    cur_var = ctk.StringVar(value="(sin versiones)")
    cur_menu = ctk.CTkOptionMenu(mcol_r, variable=cur_var, values=["(sin versiones)"], width=260, fg_color="#26203f", button_color=acc, command=lambda _v: load_custom_ui())

    def feats():
        return {k: bool(sw.get()) for k, sw in feat_sw.items()}

    def refresh_custom(select=None):
        names = I.list_custom(); vals = names or ["(sin versiones)"]
        cur_menu.configure(values=vals); cur_var.set(select if select in names else vals[0])

    def load_custom_ui():
        n = cur_var.get()
        if n not in I.list_custom():
            return
        root, cfg = I.load_custom(n)
        for k, sw in feat_sw.items():
            (sw.select() if cfg["features"].get(k, True) else sw.deselect())
        name_e.delete(0, "end"); name_e.insert(0, cfg["name"]); ver_e.delete(0, "end"); ver_e.insert(0, cfg["version"])

    def create_my():
        nm = name_e.get().strip()
        if not nm:
            messagebox.showinfo("ZYHT32 IDE", "Ponle un nombre a tu versión."); return
        b = base_var.get(); base_dir = os.path.join(I.SRC_DIR, b) if b in I.list_sources() else None
        try:
            root, cfg, sk = I.create_custom(nm, ver_e.get().strip() or "1.0", feats(), base_dir)
        except FileExistsError as e:
            messagebox.showinfo("ZYHT32 IDE", str(e)); return
        log(f"Versión «{nm}» creada en {root}"); refresh_custom(os.path.basename(root))

    def save_my():
        n = cur_var.get()
        if n not in I.list_custom():
            messagebox.showinfo("ZYHT32 IDE", "Primero crea o elige una versión."); return
        root, cfg = I.load_custom(n)
        cfg["features"] = feats(); cfg["version"] = ver_e.get().strip() or cfg["version"]; I.save_custom(root, cfg); log(f"Guardado: {cfg['name']} {cfg['version']}")

    def open_my():
        n = cur_var.get()
        if n not in I.list_custom():
            return None
        root, cfg = I.load_custom(n); sk = I.custom_sketch(root)
        ino = next((f for f in sorted(os.listdir(sk)) if f.endswith(".ino")), None) if sk else None
        if not ino:
            messagebox.showinfo("ZYHT32 IDE", "Esa versión no tiene un .ino."); return None
        save_my(); p = os.path.join(sk, ino); open_path(p); return p

    def build_my(upload):
        if open_my():
            build(upload)

    mrow = ctk.CTkFrame(mcol_r, fg_color="transparent"); mrow.pack(fill="x", padx=12, pady=8)
    U.GlowButton(mrow, accent=acc, text="Crear mi versión", command=create_my).pack(side="left")
    lbl(mcol_r, "Mis versiones").pack(fill="x", padx=12, pady=(6, 0)); cur_menu.pack(anchor="w", padx=12)
    mrow2 = ctk.CTkFrame(mcol_r, fg_color="transparent"); mrow2.pack(fill="x", padx=12, pady=8)
    U.GlowButton(mrow2, accent="#26203f", text_color="#eae6ff", text="Guardar funciones", command=save_my).pack(side="left")
    U.GlowButton(mrow2, accent="#38d6ff", text_color="#0b0814", text="Editar", command=lambda: (open_my() and tabs.set("Programar"))).pack(side="left", padx=6)
    U.GlowButton(mrow2, accent="#26203f", text_color="#eae6ff", text="Carpeta",
                 command=lambda: cur_var.get() in I.list_custom() and open_folder(I.load_custom(cur_var.get())[0])).pack(side="left")
    mrow3 = ctk.CTkFrame(mcol_r, fg_color="transparent"); mrow3.pack(fill="x", padx=12, pady=(0, 12))
    U.GlowButton(mrow3, accent="#38d6ff", text_color="#0b0814", text="Compilar mi versión", command=lambda: build_my(False)).pack(side="left")
    U.GlowButton(mrow3, accent="#25d366", text_color="#0b0814", text="Compilar y subir", command=lambda: build_my(True)).pack(side="left", padx=6)
    refresh_sources(); refresh_custom()

    # =============================================================== PROGRAMAR
    crow = ctk.CTkFrame(t_code, fg_color="transparent"); crow.pack(fill="x", padx=8, pady=6)
    editor = ctk.CTkTextbox(t_code, font=("DejaVu Sans Mono", 13), fg_color="#0b0814", wrap="none")
    editor.pack(fill="both", expand=True, padx=8, pady=(0, 8)); editor.insert("1.0", I.SKETCH_TEMPLATE)
    file_lbl = lbl(crow, "sin guardar", text_color="#9a93b8")

    def new_sk():
        editor.delete("1.0", "end"); editor.insert("1.0", I.SKETCH_TEMPLATE); st["file"] = None; file_lbl.configure(text="sin guardar")

    def open_path(p):
        editor.delete("1.0", "end"); editor.insert("1.0", open(p, encoding="utf-8", errors="replace").read())
        st["file"] = p; file_lbl.configure(text=p)

    def open_sk():
        p = filedialog.askopenfilename(filetypes=[("Sketch", "*.ino *.cpp *.h *.zs"), ("Todos", "*.*")])
        if p:
            open_path(p)

    def save_sk():
        p = st["file"] or filedialog.asksaveasfilename(defaultextension=".ino", initialfile="mi_zyht32.ino")
        if p:
            open(p, "w", encoding="utf-8").write(editor.get("1.0", "end-1c")); st["file"] = p; file_lbl.configure(text=p)
        return p

    def build(upload):
        if not I.arduino_cli():
            messagebox.showinfo("Falta arduino-cli", "Instala arduino-cli (https://arduino.github.io/arduino-cli/) y pulsa «Preparar entorno»."); return
        p = save_sk()
        if not p:
            return
        sk = os.path.dirname(p)
        if os.path.splitext(os.path.basename(p))[0] != os.path.basename(sk):   # arduino-cli exige carpeta = nombre
            sk = os.path.join(tempfile.gettempdir(), "zyht32_build", os.path.splitext(os.path.basename(p))[0]); os.makedirs(sk, exist_ok=True)
            open(os.path.join(sk, os.path.basename(sk) + ".ino"), "w", encoding="utf-8").write(editor.get("1.0", "end-1c"))
        csv = current_csv()
        if csv:
            open(os.path.join(sk, "partitions.csv"), "w").write(csv)
        fq = I.fqbn(chip_var.get(), flash_var.get(), psram_var.get(), part_var.get())
        out = os.path.join(sk, "build"); port = sel_port()
        flags = None; cu = I.custom_for_path(p)
        if cu:                       # el archivo es de «Mi ZYHT32»: se regenera el .h y se pasan las funciones
            I.save_custom(*cu); flags = I.custom_flags(cu[1]); log(f"Versión personalizada: {cu[1]['name']} {cu[1]['version']}")
        tabs.set("Consola")

        def job():
            if I.run_stream(I.compile_cmd(fq, sk, out, flags), log) != 0:
                log("Compilación con errores."); return
            log("Compilado ✓")
            if upload:
                if not port:
                    log("Sin puerto para subir."); return
                log("Subido ✓" if I.run_stream(I.upload_cmd(fq, port["device"], sk), log) == 0 else "Fallo al subir.")
        busy_run("Compilar y subir" if upload else "Compilar", job)

    for t, f, c in [("Nuevo", new_sk, "#26203f"), ("Abrir", open_sk, "#26203f"), ("Guardar", save_sk, "#26203f"),
                    ("Compilar", lambda: build(False), "#38d6ff"), ("Compilar y subir", lambda: build(True), acc)]:
        U.GlowButton(crow, accent=c, text_color="#0b0814" if c != "#26203f" else "#eae6ff", text=t, command=f).pack(side="left", padx=3)
    U.GlowButton(crow, accent="#26203f", text_color="#eae6ff", text="Preparar entorno",
                 command=lambda: busy_run("Preparar entorno", lambda: [I.run_stream(c, log) for c in I.setup_cmds()])).pack(side="left", padx=3)
    file_lbl.pack(side="left", padx=8)

    # =============================================================== ZVID
    lbl(t_zvid, "Convierte un MP4 a .zvid para reproducirlo en la pantalla del ZYHT32 (128×160).",
        font=U.accent_font(13)).pack(fill="x", padx=12, pady=(12, 6))
    zsrc = lbl(t_zvid, "Ningún video elegido", text_color="#9a93b8"); zsrc.pack(fill="x", padx=12)
    zrow = ctk.CTkFrame(t_zvid, fg_color="transparent"); zrow.pack(fill="x", padx=12, pady=8)
    zw, zh, zf = (ctk.CTkEntry(zrow, width=70) for _ in range(3))
    for e, v, n in ((zw, "128", "Ancho"), (zh, "160", "Alto"), (zf, "12", "FPS")):
        lbl(zrow, n).pack(side="left", padx=(8, 2)); e.insert(0, v); e.pack(side="left")

    def zpick():
        p = filedialog.askopenfilename(filetypes=[("Video", "*.mp4 *.mov *.mkv *.webm *.avi")])
        if p:
            st["src"] = p; zsrc.configure(text=p)

    def zconv():
        if not st["src"]:
            messagebox.showinfo("ZVID", "Elige un video."); return
        out = filedialog.asksaveasfilename(defaultextension=".zvid", initialfile=os.path.splitext(os.path.basename(st["src"]))[0] + ".zvid")
        if out:
            busy_run("Convertir a ZVID", lambda: log("ZVID: " + str(Z.encode(st["src"], out, int(zw.get()), int(zh.get()), int(zf.get())))))
    zb = ctk.CTkFrame(t_zvid, fg_color="transparent"); zb.pack(fill="x", padx=12)
    U.GlowButton(zb, accent="#26203f", text_color="#eae6ff", text="Elegir video", command=zpick).pack(side="left", padx=(0, 8))
    U.GlowButton(zb, accent=acc, text="Convertir a .zvid", command=zconv).pack(side="left")

    # =============================================================== CONSOLA
    con = ctk.CTkTextbox(t_con, font=("DejaVu Sans Mono", 12), fg_color="#05030c")
    con.pack(fill="both", expand=True, padx=8, pady=(8, 4))
    srow = ctk.CTkFrame(t_con, fg_color="transparent"); srow.pack(fill="x", padx=8, pady=(0, 8))
    send_e = ctk.CTkEntry(srow, placeholder_text="Enviar al ZYHT32 (monitor serie)…"); send_e.pack(side="left", fill="x", expand=True)

    def mon_toggle():
        if st["serial"]:
            try: st["serial"].close()
            except Exception: pass
            st["serial"] = None; mon_btn.configure(text="Abrir monitor serie"); log("Monitor cerrado."); return
        p = sel_port()
        if not p:
            log("Sin puerto."); return
        try:
            import serial
            ser = serial.Serial(p["device"], 115200, timeout=0.2); st["serial"] = ser
        except Exception as e:
            log(f"No se pudo abrir {p['device']}: {e}"); return
        mon_btn.configure(text="Cerrar monitor"); log(f"Monitor serie en {p['device']} (115200)")

        def reader():
            buf = b""
            while st["serial"] is ser:
                try:
                    buf += ser.read(256)
                except Exception:
                    break
                while b"\n" in buf:
                    ln, buf = buf.split(b"\n", 1); log(ln.decode("utf-8", "replace").rstrip())
        threading.Thread(target=reader, daemon=True).start()

    def send():
        if st["serial"] and send_e.get():
            st["serial"].write((send_e.get() + "\n").encode()); send_e.delete(0, "end")
    send_e.bind("<Return>", lambda e: send())
    mon_btn = U.GlowButton(srow, accent=acc, text="Abrir monitor serie", command=mon_toggle); mon_btn.pack(side="left", padx=6)
    U.GlowButton(srow, accent="#26203f", text_color="#eae6ff", text="Limpiar", command=lambda: con.delete("1.0", "end")).pack(side="left")

    def drain():
        for _ in range(200):
            try:
                fn = uiq.get_nowait()
            except queue.Empty:
                break
            try:
                fn()
            except Exception as e:
                logq.put(f"Error de interfaz: {e}")
        n = 0
        while not logq.empty() and n < 200:
            con.insert("end", logq.get() + "\n"); n += 1
        if n:
            con.see("end")
        sh.root.after(80, drain)

    sh.root.after(300, refresh_parts)
    sh.root.after(400, poll_ports)
    sh.root.after(100, drain)
    sh.root.after(800, show_cache)
    if S["auto_update"]:
        sh.root.after(1500, lambda: fetch(auto=True))
    log(f"ZYHT32 IDE {VERSION} lista. Conecta tu ZYHT32 por USB.")
    sh.run()


if __name__ == "__main__":
    main()
