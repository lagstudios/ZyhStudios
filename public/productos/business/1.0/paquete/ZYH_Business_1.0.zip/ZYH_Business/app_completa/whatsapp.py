# -*- coding: utf-8 -*-
"""ZYH Business — conector de WhatsApp Business (API oficial / Cloud API de Meta).

Recibe mensajes (texto e IMÁGENES) por un webhook y responde con la API Graph. Necesita:
    - token de acceso permanente
    - phone_number_id  (de tu número de WhatsApp Business)
    - verify_token     (una palabra que tú inventas)
    - app_secret       (opcional pero recomendado: comprueba que el mensaje viene de Meta)

No usa librerías no oficiales: es la vía legal de Meta, el número no se arriesga.
"""
import json, hmac, hashlib, threading, urllib.request, urllib.parse
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

GRAPH = "https://graph.facebook.com"      # sin versión fija: Meta usa la vigente de tu app (no caduca)
MAX_MEDIA = 5 * 1024 * 1024


class Config:
    def __init__(self, token="", phone_number_id="", verify_token="zyh", business_name="mi negocio",
                 gemini_key="", app_secret=""):
        self.token = token
        self.phone_number_id = phone_number_id
        self.verify_token = verify_token
        self.business_name = business_name
        self.gemini_key = gemini_key
        self.app_secret = app_secret


def send_message(cfg: Config, to: str, text: str):
    """Envía un texto por la API oficial. Devuelve (ok, detalle)."""
    url = f"{GRAPH}/{cfg.phone_number_id}/messages"
    payload = {"messaging_product": "whatsapp", "to": to, "type": "text", "text": {"body": text[:4000]}}
    req = urllib.request.Request(url, data=json.dumps(payload).encode(),
                                 headers={"Authorization": f"Bearer {cfg.token}", "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            return True, r.read().decode()
    except urllib.error.HTTPError as e:
        try:
            return False, json.loads(e.read().decode()).get("error", {}).get("message", str(e))
        except Exception:
            return False, str(e)
    except Exception as e:
        return False, str(e)


def download_media(cfg: Config, media_id: str):
    """Descarga una imagen que envió el cliente. Devuelve (bytes, mime) o None."""
    try:
        req = urllib.request.Request(f"{GRAPH}/{media_id}", headers={"Authorization": f"Bearer {cfg.token}"})
        with urllib.request.urlopen(req, timeout=15) as r:
            info = json.loads(r.read().decode())
        if int(info.get("file_size", 0) or 0) > MAX_MEDIA:
            return None
        req = urllib.request.Request(info["url"], headers={"Authorization": f"Bearer {cfg.token}"})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = r.read(MAX_MEDIA + 1)
        if len(data) > MAX_MEDIA:
            return None
        return data, info.get("mime_type", "image/jpeg")
    except Exception:
        return None


def parse_incoming(body: dict):
    """Extrae los mensajes de un webhook: [{"id","from","name","type","text","media_id"}]."""
    out = []
    try:
        for entry in body.get("entry", []):
            for ch in entry.get("changes", []):
                val = ch.get("value", {})
                names = {c.get("wa_id"): (c.get("profile") or {}).get("name", "") for c in val.get("contacts", [])}
                for msg in val.get("messages", []):
                    t = msg.get("type")
                    base = {"id": msg.get("id", ""), "from": msg["from"], "name": names.get(msg["from"], ""), "type": t,
                            "text": "", "media_id": ""}
                    if t == "text":
                        base["text"] = msg["text"]["body"]; out.append(base)
                    elif t == "image":
                        base["text"] = msg["image"].get("caption", ""); base["media_id"] = msg["image"]["id"]; out.append(base)
                    elif t in ("audio", "video", "document", "sticker", "location"):
                        base["text"] = ""; out.append(base)
    except Exception:
        pass
    return out


def valid_signature(app_secret: str, raw: bytes, header: str):
    if not app_secret:
        return True                      # sin app_secret no se puede comprobar (se recomienda configurarlo)
    want = "sha256=" + hmac.new(app_secret.encode(), raw, hashlib.sha256).hexdigest()
    return hmac.compare_digest(want, header or "")


def make_handler(cfg: Config, on_message):
    """on_message(phone, text, image, name) -> texto de respuesta (image = (bytes, mime) o None)."""
    seen, seen_lock = [], threading.Lock()

    def is_new(mid):
        with seen_lock:
            if mid and mid in seen:
                return False             # Meta reintenta: no responder dos veces lo mismo
            seen.append(mid); del seen[:-500]
            return True

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _ok(self, code=200, body=b""):
            self.send_response(code); self.send_header("Content-Length", str(len(body))); self.end_headers()
            if body:
                self.wfile.write(body)

        def do_GET(self):  # verificación del webhook (Meta)
            q = urllib.parse.parse_qs(urllib.parse.urlparse(self.path).query)
            if (q.get("hub.mode", [""])[0] == "subscribe" and
                    hmac.compare_digest(q.get("hub.verify_token", [""])[0], cfg.verify_token)):
                self._ok(200, q.get("hub.challenge", [""])[0].encode())
            else:
                self._ok(403)

        def do_POST(self):
            try:
                n = int(self.headers.get("Content-Length", 0))
            except ValueError:
                n = 0
            if n <= 0 or n > 2 * 1024 * 1024:
                return self._ok(400)
            raw = self.rfile.read(n)
            if not valid_signature(cfg.app_secret, raw, self.headers.get("X-Hub-Signature-256", "")):
                return self._ok(403)
            try:
                body = json.loads(raw or b"{}")
            except Exception:
                return self._ok(400)
            self._ok(200)                               # responder rápido a Meta
            for m in parse_incoming(body):
                if not is_new(m["id"]):
                    continue
                try:
                    if m["type"] == "image":
                        img = download_media(cfg, m["media_id"])
                        reply = on_message(m["from"], m["text"], img, m["name"])
                    elif m["type"] == "text":
                        reply = on_message(m["from"], m["text"], None, m["name"])
                    else:
                        reply = "Por ahora entiendo texto e imágenes 🙂 ¿Me escribes qué producto buscas?"
                    if reply:
                        send_message(cfg, m["from"], reply)
                except Exception:
                    pass
    return H


def serve(cfg: Config, on_message, port=8088):
    httpd = ThreadingHTTPServer(("0.0.0.0", port), make_handler(cfg, on_message))
    return httpd  # el llamador hace httpd.serve_forever() en un hilo
