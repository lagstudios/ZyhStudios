#!/usr/bin/env python3
"""ZYH_BUSINESS 2.1 — suite empresarial ligera con servidor LAN/WLAN y chat TLS.
Python 3.10+, CustomTkinter y SQLite. Un solo código para Windows 10/11 y Linux.
No borra mensajes del chat. Los mensajes privados pueden archivarse por conversación.

Novedades 2.1 (sin eliminar funciones de la 2.0; misma base .zyhdb y mismo protocolo):
- Windows: el certificado TLS se crea con Python (cryptography); ya no hace falta OpenSSL.
- Conexión SQLite reutilizada por hilo (menos apertura/cierre en cada operación).
- Resumen calculado en una sola consulta.
- Listas largas por páginas con buscador y exportación a CSV.
- Chat: una consulta menos cada 2,2 s.
- Protección contra fuerza bruta en el inicio de sesión remoto.
- Corrección: la bandeja privada usaba una variable de otra ventana Tk.
"""
from __future__ import annotations
import os, sys, ssl, socket, struct, threading, hashlib, secrets, subprocess, csv, shutil, time
import sqlite3
import json, queue
import zyh_ext, barcode_scan
from pathlib import Path
from datetime import datetime, date, timedelta, timedelta, timezone
from decimal import Decimal, InvalidOperation
import tkinter as tk
from tkinter import filedialog, messagebox, colorchooser

# --- ZYH: núcleo de licencias (verificación oculta; la app solo pregunta) ---
for _ZC in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_core"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "_core")):
    if os.path.isdir(os.path.join(_ZC, "zyhcore")):
        sys.path.insert(0, os.path.abspath(_ZC)); break
try:
    from zyhcore import guard as _zyh_guard
except Exception:
    _zyh_guard = None
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

try:
    import customtkinter as ctk
except ImportError:
    print("Falta CustomTkinter. Instálalo con: python -m pip install -r requirements.txt")
    if os.name != "nt": print("En Linux también: sudo apt install python3-tk")
    raise

APP_NAME = "ZYH_BUSINESS"
APP_VERSION = "2.2.0 Bridged Local"
LOCAL_EDITION = True          # edicion local: un solo PC, sin servidor de red
IS_WINDOWS = os.name == "nt"
PLATFORM_LABEL = "Windows" if IS_WINDOWS else "Linux"
PAGE_SIZE = 60          # filas que se dibujan por página en las listas
LOGIN_MAX_FAILS = 5     # intentos fallidos por IP antes de bloquear
LOGIN_LOCK_SECONDS = 60
PORT_DEFAULT = 8765
DATA_DIR = Path.home() / ".zyh_business"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "empresa.zyhdb"
CERT_PATH = DATA_DIR / "servidor.zyhcert"
KEY_PATH = DATA_DIR / "servidor.zyhkey"
CONFIG_PATH = DATA_DIR / "apariencia.zyhcfg"
TRUST_DIR = DATA_DIR / "huellas"
TRUST_DIR.mkdir(parents=True, exist_ok=True)
MAX_FRAME = 2 * 1024 * 1024
PBKDF2_ROUNDS = 260_000

# ---------------- ZYH Bridger: planes (vista) ----------------
# PRECIOS DE EJEMPLO: cambialos aqui (un solo lugar). "days" = duracion del plan al pagar.
BRIDGER_PLANS = [
    {"id": "gratis", "name": "Gratis", "price": "$0 COP", "days": 0, "guests": 4,
     "features": ["Codigo de emparejamiento de 10 min",
                  "Puente Minecraft Java en LAN", "Soporte comunitario"]},
    {"id": "pro", "name": "Pro", "price": "$15.000 COP / mes", "days": 30, "guests": 16,
     "features": ["Salas con 5 intentos por equipo",
                  "Puerto LAN y direccion copiables", "Actualizaciones incluidas"]},
    {"id": "team", "name": "Team", "price": "$30.000 COP / mes", "days": 30, "guests": 16,
     "features": ["Todo lo de Pro", "Varios mundos en la misma PC",
                  "Historial de conexiones", "Soporte prioritario"]},
]

def fit_window(win, width, height, min_w=640, min_h=480, center=True):
    """Ajusta la ventana a la pantalla: nunca mas grande que ella, centrada, y F11 = pantalla completa."""
    try:
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w = max(320, min(width, int(sw * 0.94)))
        h = max(260, min(height, int(sh * 0.90)))
        win.minsize(min(min_w, w), min(min_h, h))
        x, y = max(0, (sw - w) // 2), max(0, (sh - h) // 3)
        win.geometry(f"{w}x{h}+{x}+{y}")
        if win.master is None and not getattr(win, "_fit_f11", False):
            win._fit_f11 = True
            win.bind("<F11>", lambda e: win.attributes("-fullscreen", not win.attributes("-fullscreen")))
            win.bind("<Escape>", lambda e: win.attributes("-fullscreen", False))
    except Exception:
        pass


def fmt_countdown(sec):
    sec = int(sec)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return f"{d} d  {h:02d}:{m:02d}:{s:02d}"

ROLE_RANK = {"Empleado": 1, "Supervisor": 2, "Administrador": 3, "Jefe": 4}


def now(): return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def clean(s, limit=20000): return str(s or "").replace("\x00", "").replace("\x1e", " ").replace("\x1f", " ")[:limit]
def as_money(v):
    try: return "$" + f"{float(v):,.2f}"
    except (ValueError, TypeError): return "$0.00"
def parse_amount(v, label="Valor"):
    v = str(v).strip().replace("$", "").replace(" ", "")
    if "," in v and "." not in v: v = v.replace(",", ".")
    try: n = Decimal(v)
    except InvalidOperation: raise ValueError(f"{label}: escribe un número válido.")
    if not n.is_finite() or n < 0: raise ValueError(f"{label}: debe ser cero o mayor.")
    return float(n.quantize(Decimal("0.01")))
def parse_int(v, label, minimum=0):
    try: n = int(str(v).strip())
    except ValueError: raise ValueError(f"{label}: debe ser un número entero.")
    if n < minimum: raise ValueError(f"{label}: mínimo {minimum}.")
    return n

def pack_fields(fields):
    """Paquetes ZYH-WIRE1: número de campos + longitud y UTF-8 de cada campo. Sin JSON/pickle."""
    fields = [clean(x, MAX_FRAME) for x in fields]
    if len(fields) > 256: raise ValueError("Demasiados campos")
    out = bytearray(struct.pack("!H", len(fields)))
    for field in fields:
        b = field.encode("utf-8")
        if len(b) > MAX_FRAME: raise ValueError("Campo demasiado grande")
        out.extend(struct.pack("!I", len(b))); out.extend(b)
    if len(out) > MAX_FRAME: raise ValueError("Paquete demasiado grande")
    return bytes(out)

def unpack_fields(data):
    if len(data) < 2: raise ValueError("Paquete ZYH incompleto")
    count = struct.unpack("!H", data[:2])[0]; pos = 2; out = []
    if count > 256: raise ValueError("Paquete ZYH inválido")
    for _ in range(count):
        if pos + 4 > len(data): raise ValueError("Campo ZYH incompleto")
        size = struct.unpack("!I", data[pos:pos+4])[0]; pos += 4
        if size > MAX_FRAME or pos + size > len(data): raise ValueError("Longitud ZYH inválida")
        out.append(data[pos:pos+size].decode("utf-8", errors="replace")); pos += size
    if pos != len(data): raise ValueError("Datos sobrantes en paquete ZYH")
    return out

def recv_exact(sock, size):
    chunks = bytearray()
    while len(chunks) < size:
        data = sock.recv(size - len(chunks))
        if not data: raise ConnectionError("El servidor cerró la conexión")
        chunks.extend(data)
    return bytes(chunks)
def send_packet(sock, fields):
    data = pack_fields(fields)
    sock.sendall(struct.pack("!I", len(data)) + data)
def recv_packet(sock):
    size = struct.unpack("!I", recv_exact(sock, 4))[0]
    if size < 2 or size > MAX_FRAME: raise ValueError("Tamaño de paquete fuera de límites")
    return unpack_fields(recv_exact(sock, size))

def hash_password(password, salt=None):
    salt = salt or secrets.token_bytes(16)
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS)
    return salt.hex(), digest.hex()
def verify_password(password, salt_hex, hash_hex):
    try: salt = bytes.fromhex(salt_hex)
    except ValueError: return False
    candidate = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, PBKDF2_ROUNDS).hex()
    return secrets.compare_digest(candidate, hash_hex)

def _certificate_with_cryptography():
    """Crea el certificado autofirmado en Python puro (Windows y Linux, sin OpenSSL)."""
    from cryptography import x509
    from cryptography.x509.oid import NameOID
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import rsa
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    name = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, "ZYH_BUSINESS_LAN")])
    start = datetime.now(timezone.utc) - timedelta(minutes=5)
    cert = (x509.CertificateBuilder().subject_name(name).issuer_name(name).public_key(key.public_key())
            .serial_number(x509.random_serial_number()).not_valid_before(start)
            .not_valid_after(start + timedelta(days=1825))
            .add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=True)
            .sign(key, hashes.SHA256()))
    KEY_PATH.write_bytes(key.private_bytes(serialization.Encoding.PEM, serialization.PrivateFormat.TraditionalOpenSSL,
                                           serialization.NoEncryption()))
    CERT_PATH.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

def ensure_certificate():
    if CERT_PATH.exists() and KEY_PATH.exists(): return
    try:
        _certificate_with_cryptography()
    except ImportError:
        if not shutil.which("openssl"):
            raise RuntimeError("Falta el paquete 'cryptography' (pip install -r requirements.txt) u OpenSSL para activar el servidor TLS.")
        cmd = ["openssl", "req", "-x509", "-newkey", "rsa:2048", "-nodes", "-keyout", str(KEY_PATH),
               "-out", str(CERT_PATH), "-days", "1825", "-subj", "/CN=ZYH_BUSINESS_LAN"]
        done = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=35,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        if done.returncode != 0: raise RuntimeError("No se pudo crear el certificado TLS: " + done.stderr.decode(errors="replace")[-500:])
    try: os.chmod(KEY_PATH, 0o600)
    except OSError: pass

def certificate_fingerprint():
    pem = CERT_PATH.read_bytes()
    der = ssl.PEM_cert_to_DER_cert(pem.decode("ascii"))
    return hashlib.sha256(der).hexdigest().upper()
def format_fingerprint(fp): return ":".join(fp[i:i+2] for i in range(0, len(fp), 2))
def bridger_plan_get():
    conn = db_connect(); r = conn.execute("SELECT value FROM zyh_settings WHERE key='bridger_plan'").fetchone(); conn.close()
    if not r: return None
    try: return json.loads(r[0])
    except Exception: return None
def bridger_plan_set(pid, days, paid_at):
    conn = db_connect()
    conn.execute("INSERT OR REPLACE INTO zyh_settings(key,value) VALUES('bridger_plan',?)", (json.dumps({"plan": pid, "days": days, "paid_at": paid_at}),))
    conn.commit(); conn.close()
def bridger_remaining(cur):
    paid = datetime.strptime(cur["paid_at"], "%Y-%m-%d %H:%M:%S"); total = timedelta(days=int(cur["days"]))
    end = paid + total
    left = max(0.0, (end - datetime.now()).total_seconds())
    return left, max(1.0, total.total_seconds()), end

def trust_path(host, port):
    safe = "".join(c if c.isalnum() or c in ".-_" else "_" for c in host)
    return TRUST_DIR / f"{safe}_{port}.zyhtrust"

def initialize_schema(path=DB_PATH):
    conn = sqlite3.connect(str(path), timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS customers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, document TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS suppliers(id INTEGER PRIMARY KEY, name TEXT NOT NULL, document TEXT NOT NULL DEFAULT '', phone TEXT NOT NULL DEFAULT '', email TEXT NOT NULL DEFAULT '', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, sku TEXT NOT NULL UNIQUE, name TEXT NOT NULL, quantity INTEGER NOT NULL DEFAULT 0 CHECK(quantity>=0), min_stock INTEGER NOT NULL DEFAULT 0 CHECK(min_stock>=0), cost REAL NOT NULL DEFAULT 0 CHECK(cost>=0), price REAL NOT NULL DEFAULT 0 CHECK(price>=0), supplier_id INTEGER REFERENCES suppliers(id) ON DELETE SET NULL, notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY, customer_id INTEGER REFERENCES customers(id) ON DELETE SET NULL, total REAL NOT NULL CHECK(total>=0), status TEXT NOT NULL DEFAULT 'Pagada', created_at TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS sale_items(id INTEGER PRIMARY KEY, sale_id INTEGER NOT NULL REFERENCES sales(id) ON DELETE CASCADE, product_id INTEGER REFERENCES products(id) ON DELETE SET NULL, product_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0), unit_price REAL NOT NULL CHECK(unit_price>=0), subtotal REAL NOT NULL CHECK(subtotal>=0));
    CREATE TABLE IF NOT EXISTS expenses(id INTEGER PRIMARY KEY, expense_date TEXT NOT NULL, category TEXT NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL CHECK(amount>=0), notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS quotes(id INTEGER PRIMARY KEY, customer TEXT NOT NULL, description TEXT NOT NULL, amount REAL NOT NULL CHECK(amount>=0), status TEXT NOT NULL DEFAULT 'Borrador', valid_until TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '');
    CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY, title TEXT NOT NULL, due_date TEXT NOT NULL DEFAULT '', status TEXT NOT NULL DEFAULT 'Pendiente', priority TEXT NOT NULL DEFAULT 'Normal', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS documents(id INTEGER PRIMARY KEY, name TEXT NOT NULL, path TEXT NOT NULL, category TEXT NOT NULL DEFAULT 'General', notes TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY, action TEXT NOT NULL, detail TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS zyh_users(username TEXT PRIMARY KEY, role TEXT NOT NULL, salt TEXT NOT NULL, password_hash TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS zyh_chat(id INTEGER PRIMARY KEY, kind TEXT NOT NULL CHECK(kind IN ('public','private')), sender TEXT NOT NULL, recipient TEXT NOT NULL DEFAULT '', body TEXT NOT NULL, created_at TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS zyh_archives(username TEXT NOT NULL, peer TEXT NOT NULL, archived_at TEXT NOT NULL, PRIMARY KEY(username,peer));
    CREATE TABLE IF NOT EXISTS zyh_settings(key TEXT PRIMARY KEY, value TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS ai_orders(id INTEGER PRIMARY KEY, phone TEXT NOT NULL, product_id INTEGER, product_name TEXT NOT NULL, quantity INTEGER NOT NULL CHECK(quantity>0), unit_price REAL NOT NULL, total REAL NOT NULL, status TEXT NOT NULL DEFAULT 'pendiente', created_by TEXT NOT NULL, created_at TEXT NOT NULL, decided_by TEXT NOT NULL DEFAULT '', decided_at TEXT NOT NULL DEFAULT '', note TEXT NOT NULL DEFAULT '', sale_id INTEGER, sent INTEGER NOT NULL DEFAULT 0, send_detail TEXT NOT NULL DEFAULT '');
    CREATE INDEX IF NOT EXISTS idx_zyh_chat_kind_id ON zyh_chat(kind,id);
    CREATE INDEX IF NOT EXISTS idx_zyh_chat_private ON zyh_chat(sender,recipient,id);
    """)
    cols = [r[1] for r in conn.execute("PRAGMA table_info(activity)").fetchall()]
    if "username" not in cols:
        conn.execute("ALTER TABLE activity ADD COLUMN username TEXT NOT NULL DEFAULT 'Sistema'")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_zyh_activity_user ON activity(username,id)")
    conn.commit(); conn.close()

def db_connect(path=DB_PATH):
    conn = sqlite3.connect(str(path), timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA busy_timeout=10000")
    return conn

_thread_db = threading.local()
def db_cached(path=DB_PATH):
    """Una conexión SQLite reutilizable por hilo (SQLite no comparte conexiones entre hilos)."""
    cache = getattr(_thread_db, "conns", None)
    if cache is None: cache = _thread_db.conns = {}
    key = str(path); conn = cache.get(key)
    if conn is None:
        conn = db_connect(path); cache[key] = conn
    return conn

def add_activity(conn, user, action, detail):
    conn.execute("INSERT INTO activity(action,detail,created_at,username) VALUES(?,?,?,?)", (clean(action,100), clean(detail,700), now(), user))

def get_boss(conn):
    row = conn.execute("SELECT value FROM zyh_settings WHERE key='boss_username'").fetchone()
    if row: return row[0]
    row = conn.execute("SELECT username FROM zyh_users WHERE role='Jefe' AND active=1 ORDER BY created_at LIMIT 1").fetchone()
    return row[0] if row else ""

def authenticate(path, username, password):
    conn = db_cached(path)
    try:
        row = conn.execute("SELECT username,role,salt,password_hash,active FROM zyh_users WHERE username=? COLLATE NOCASE", (username.strip(),)).fetchone()
        if not row or not row["active"] or not verify_password(password, row["salt"], row["password_hash"]):
            return None
        name, role = row["username"], row["role"]
        add_activity(conn, name, "Inicio de sesión", "Acceso autenticado")
        conn.commit()
        return name, role, get_boss(conn)
    except Exception:
        conn.rollback(); raise

def rows_to_fields(rows, fields):
    out = [str(len(rows))]
    for row in rows:
        for field in fields: out.append("" if row[field] is None else str(row[field]))
    return out

def require_role(role, minimum):
    if ROLE_RANK.get(role,0) < ROLE_RANK[minimum]: raise PermissionError(f"Esta acción requiere rol {minimum} o superior.")
def dispatch(path, username, action, args):
    conn = db_cached(path)
    try:
        userrow = conn.execute("SELECT role,active FROM zyh_users WHERE username=?", (username,)).fetchone()
        if not userrow or not userrow["active"]: raise PermissionError("Cuenta inactiva.")
        role = userrow["role"]; boss = get_boss(conn)
        a = list(args)
        def arg(i, default=""): return a[i] if i < len(a) else default
        result = []
        if action == "PING": result = [APP_NAME, APP_VERSION, boss]
        elif action == "NAVIGATE":
            add_activity(conn, username, "Abrió sección", clean(arg(0),100)); result=["OK"]
        elif action == "DASHBOARD":
            row = conn.execute("""SELECT (SELECT COUNT(*) FROM customers),(SELECT COUNT(*) FROM products),
                (SELECT COALESCE(SUM(total),0) FROM sales),(SELECT COALESCE(SUM(amount),0) FROM expenses),
                (SELECT COUNT(*) FROM quotes WHERE status NOT IN ('Aceptada','Rechazada')),
                (SELECT COUNT(*) FROM tasks WHERE status!='Completada'),
                (SELECT COUNT(*) FROM products WHERE quantity<=min_stock)""").fetchone()
            result = [str(v) for v in row]
        elif action == "LIST_CUSTOMERS":
            rows=conn.execute("SELECT id,name,document,phone,email,notes,created_at FROM customers ORDER BY name LIMIT 2000").fetchall()
            result=rows_to_fields(rows,["id","name","document","phone","email","notes","created_at"])
        elif action == "SAVE_CUSTOMER":
            require_role(role,"Supervisor")
            rid=arg(0); name=clean(arg(1),160)
            if not name: raise ValueError("El nombre del cliente es obligatorio.")
            vals=(name,clean(arg(2),100),clean(arg(3),100),clean(arg(4),180),clean(arg(5),1000))
            if rid:
                conn.execute("UPDATE customers SET name=?,document=?,phone=?,email=?,notes=? WHERE id=?", vals+(parse_int(rid,"ID",1),))
                detail=f"Cliente editado: {name}"
            else:
                conn.execute("INSERT INTO customers(name,document,phone,email,notes,created_at) VALUES(?,?,?,?,?,?)", vals+(now(),))
                detail=f"Cliente creado: {name}"
            add_activity(conn,username,"Gestión de clientes",detail); result=["Guardado"]
        elif action == "DELETE_CUSTOMER":
            require_role(role,"Administrador")
            rid=parse_int(arg(0),"ID",1)
            conn.execute("DELETE FROM customers WHERE id=?",(rid,)); add_activity(conn,username,"Gestión de clientes",f"Eliminó cliente ID {rid}"); result=["Eliminado"]
        elif action == "LIST_PRODUCTS":
            rows=conn.execute("SELECT id,sku,name,quantity,min_stock,cost,price,notes FROM products ORDER BY name LIMIT 2000").fetchall()
            result=rows_to_fields(rows,["id","sku","name","quantity","min_stock","cost","price","notes"])
        elif action == "SAVE_PRODUCT":
            require_role(role,"Supervisor")
            rid=arg(0); sku=clean(arg(1),80); name=clean(arg(2),160)
            if not sku or not name: raise ValueError("SKU y nombre son obligatorios.")
            qty=parse_int(arg(3),"Cantidad"); minimum=parse_int(arg(4),"Stock mínimo")
            cost=parse_amount(arg(5),"Costo"); price=parse_amount(arg(6),"Precio"); notes=clean(arg(7),1000)
            if rid:
                conn.execute("UPDATE products SET sku=?,name=?,quantity=?,min_stock=?,cost=?,price=?,notes=? WHERE id=?",(sku,name,qty,minimum,cost,price,notes,parse_int(rid,"ID",1)))
                detail=f"Producto editado: {sku} {name}"
            else:
                conn.execute("INSERT INTO products(sku,name,quantity,min_stock,cost,price,notes,created_at) VALUES(?,?,?,?,?,?,?,?)",(sku,name,qty,minimum,cost,price,notes,now()))
                detail=f"Producto creado: {sku} {name}"
            add_activity(conn,username,"Inventario",detail); result=["Guardado"]
        elif action == "DELETE_PRODUCT":
            require_role(role,"Administrador"); rid=parse_int(arg(0),"ID",1)
            conn.execute("DELETE FROM products WHERE id=?",(rid,)); add_activity(conn,username,"Inventario",f"Eliminó producto ID {rid}"); result=["Eliminado"]
        elif action == "LIST_SALES":
            rows=conn.execute("SELECT s.id,COALESCE(c.name,'Venta general') customer,s.total,s.status,s.created_at,s.notes,COALESCE((SELECT group_concat(si.product_name||' x'||si.quantity, ', ') FROM sale_items si WHERE si.sale_id=s.id),'') items FROM sales s LEFT JOIN customers c ON c.id=s.customer_id ORDER BY s.id DESC LIMIT 1000").fetchall()
            result=rows_to_fields(rows,["id","customer","total","status","created_at","notes","items"])
        elif action == "CREATE_SALE":
            require_role(role,"Empleado")
            customer_id=arg(0); product_id=parse_int(arg(1),"Producto",1); qty=parse_int(arg(2),"Cantidad",1); notes=clean(arg(3),1000)
            prow=conn.execute("SELECT id,name,quantity,price FROM products WHERE id=?",(product_id,)).fetchone()
            if not prow: raise ValueError("Ese producto no existe.")
            if prow["quantity"] < qty: raise ValueError("No hay suficiente inventario.")
            if customer_id:
                cid=parse_int(customer_id,"Cliente",1)
                if not conn.execute("SELECT id FROM customers WHERE id=?",(cid,)).fetchone(): raise ValueError("Cliente no encontrado.")
            else: cid=None
            price=float(prow["price"]); subtotal=round(price*qty,2)
            cur=conn.execute("INSERT INTO sales(customer_id,total,status,created_at,notes) VALUES(?,?,?,?,?)",(cid,subtotal,"Pagada",now(),notes))
            sale_id=cur.lastrowid
            conn.execute("INSERT INTO sale_items(sale_id,product_id,product_name,quantity,unit_price,subtotal) VALUES(?,?,?,?,?,?)",(sale_id,product_id,prow["name"],qty,price,subtotal))
            conn.execute("UPDATE products SET quantity=quantity-? WHERE id=?",(qty,product_id))
            add_activity(conn,username,"Ventas",f"Venta #{sale_id}: {prow['name']} x{qty} = {as_money(subtotal)}"); result=[str(sale_id),as_money(subtotal)]
        elif action == "LIST_EXPENSES":
            rows=conn.execute("SELECT id,expense_date,category,description,amount,notes FROM expenses ORDER BY id DESC LIMIT 1000").fetchall()
            result=rows_to_fields(rows,["id","expense_date","category","description","amount","notes"])
        elif action == "SAVE_EXPENSE":
            require_role(role,"Supervisor")
            category=clean(arg(0),100); desc=clean(arg(1),200); amount=parse_amount(arg(2),"Valor"); expense_date=clean(arg(3),30) or date.today().isoformat(); notes=clean(arg(4),1000)
            if not category or not desc: raise ValueError("Categoría y descripción son obligatorias.")
            conn.execute("INSERT INTO expenses(expense_date,category,description,amount,notes,created_at) VALUES(?,?,?,?,?,?)",(expense_date,category,desc,amount,notes,now()))
            add_activity(conn,username,"Gastos",f"Registró gasto: {desc} ({as_money(amount)})"); result=["Guardado"]
        elif action == "LIST_QUOTES":
            rows=conn.execute("SELECT id,customer,description,amount,status,valid_until,created_at,notes FROM quotes ORDER BY id DESC LIMIT 1000").fetchall()
            result=rows_to_fields(rows,["id","customer","description","amount","status","valid_until","created_at","notes"])
        elif action == "SAVE_QUOTE":
            require_role(role,"Supervisor")
            customer=clean(arg(0),160); desc=clean(arg(1),300); amount=parse_amount(arg(2),"Valor"); status=arg(3) if arg(3) in ("Borrador","Enviada","Aceptada","Rechazada") else "Borrador"; valid=clean(arg(4),30); notes=clean(arg(5),1000)
            if not customer or not desc: raise ValueError("Cliente y descripción son obligatorios.")
            conn.execute("INSERT INTO quotes(customer,description,amount,status,valid_until,created_at,notes) VALUES(?,?,?,?,?,?,?)",(customer,desc,amount,status,valid,now(),notes))
            add_activity(conn,username,"Cotizaciones",f"Cotización a {customer}: {as_money(amount)}"); result=["Guardado"]
        elif action == "LIST_TASKS":
            rows=conn.execute("SELECT id,title,due_date,status,priority,notes,created_at FROM tasks ORDER BY CASE status WHEN 'Completada' THEN 1 ELSE 0 END,id DESC LIMIT 1000").fetchall()
            result=rows_to_fields(rows,["id","title","due_date","status","priority","notes","created_at"])
        elif action == "SAVE_TASK":
            require_role(role,"Empleado")
            title=clean(arg(0),240); due=clean(arg(1),30); priority=arg(2) if arg(2) in ("Baja","Normal","Alta","Urgente") else "Normal"; notes=clean(arg(3),1000)
            if not title: raise ValueError("El título es obligatorio.")
            conn.execute("INSERT INTO tasks(title,due_date,status,priority,notes,created_at) VALUES(?,?, 'Pendiente',?,?,?)",(title,due,priority,notes,now()))
            add_activity(conn,username,"Tareas",f"Creó tarea: {title}"); result=["Guardado"]
        elif action == "TASK_DONE":
            rid=parse_int(arg(0),"ID",1); conn.execute("UPDATE tasks SET status='Completada' WHERE id=?",(rid,)); add_activity(conn,username,"Tareas",f"Marcó como completada tarea ID {rid}"); result=["Actualizada"]
        elif action == "LIST_USERS":
            require_role(role,"Administrador")
            rows=conn.execute("SELECT username,role,active,created_at FROM zyh_users ORDER BY CASE role WHEN 'Jefe' THEN 4 WHEN 'Administrador' THEN 3 WHEN 'Supervisor' THEN 2 ELSE 1 END DESC,username").fetchall()
            result=rows_to_fields(rows,["username","role","active","created_at"])
        elif action == "CREATE_USER":
            require_role(role,"Administrador")
            new=clean(arg(0),64); newrole=arg(1); password=arg(2)
            if not re_username(new): raise ValueError("Usuario: usa 3–32 caracteres (letras, números, punto, guion o guion bajo).")
            if newrole not in ROLE_RANK: raise ValueError("Rol no válido.")
            if ROLE_RANK[newrole] >= ROLE_RANK[role]: raise PermissionError("No puedes crear una cuenta con tu mismo rango o superior.")
            if len(password)<8: raise ValueError("La contraseña debe tener al menos 8 caracteres.")
            salt,pwh=hash_password(password)
            conn.execute("INSERT INTO zyh_users(username,role,salt,password_hash,active,created_at) VALUES(?,?,?,?,1,?)",(new,newrole,salt,pwh,now()))
            add_activity(conn,username,"Usuarios",f"Creó cuenta {new} con rol {newrole}"); result=["Creado"]
        elif action == "USER_ACTIVE":
            require_role(role,"Administrador"); target=clean(arg(0),64); active=parse_int(arg(1),"Estado",0)
            targetrow=conn.execute("SELECT role FROM zyh_users WHERE username=?",(target,)).fetchone()
            if not targetrow: raise ValueError("Usuario no encontrado.")
            if target == boss or target == username: raise PermissionError("No puedes desactivar la cuenta del jefe ni tu propia cuenta.")
            if ROLE_RANK[role] <= ROLE_RANK[targetrow["role"]]: raise PermissionError("Solo puedes gestionar usuarios de rango inferior.")
            conn.execute("UPDATE zyh_users SET active=? WHERE username=?",(1 if active else 0,target))
            add_activity(conn,username,"Usuarios",f"{'Activó' if active else 'Desactivó'} cuenta {target}"); result=["Actualizado"]
        elif action == "RESET_PASSWORD":
            require_role(role,"Administrador"); target=clean(arg(0),64); password=arg(1)
            targetrow=conn.execute("SELECT role FROM zyh_users WHERE username=?",(target,)).fetchone()
            if not targetrow: raise ValueError("Usuario no encontrado.")
            if target == boss or target == username: raise PermissionError("Usa Cambiar contraseña para tu propia cuenta; la cuenta principal no se restablece desde aquí.")
            if ROLE_RANK[role] <= ROLE_RANK[targetrow["role"]]: raise PermissionError("Solo puedes restablecer contraseñas de rango inferior.")
            if len(password)<8: raise ValueError("Mínimo 8 caracteres.")
            salt,pwh=hash_password(password); conn.execute("UPDATE zyh_users SET salt=?,password_hash=? WHERE username=?",(salt,pwh,target))
            add_activity(conn,username,"Usuarios",f"Restableció contraseña de {target}"); result=["Restablecida"]
        elif action == "CHANGE_PASSWORD":
            old=arg(0); new=arg(1)
            row=conn.execute("SELECT salt,password_hash FROM zyh_users WHERE username=?",(username,)).fetchone()
            if not verify_password(old,row["salt"],row["password_hash"]): raise PermissionError("La contraseña actual no coincide.")
            if len(new)<8: raise ValueError("La nueva contraseña debe tener al menos 8 caracteres.")
            salt,pwh=hash_password(new); conn.execute("UPDATE zyh_users SET salt=?,password_hash=? WHERE username=?",(salt,pwh,username))
            add_activity(conn,username,"Seguridad","Cambió su contraseña"); result=["Actualizada"]
        elif action == "LIST_ACTIVITY":
            full = ROLE_RANK[role] >= ROLE_RANK["Jefe"]
            sql="SELECT id,username,action,detail,created_at FROM activity" + ("" if full else " WHERE username=?") + " ORDER BY id DESC LIMIT 500"
            rows=conn.execute(sql,() if full else (username,)).fetchall()
            result=rows_to_fields(rows,["id","username","action","detail","created_at"])
        elif action == "CHAT_PUBLIC":
            last=parse_int(arg(0,"0"),"ID de mensaje",0)
            if last == 0:
                rows=conn.execute("SELECT id,sender,body,created_at FROM zyh_chat WHERE kind='public' ORDER BY id DESC LIMIT 120").fetchall()[::-1]
            else: rows=conn.execute("SELECT id,sender,body,created_at FROM zyh_chat WHERE kind='public' AND id>? ORDER BY id LIMIT 120",(last,)).fetchall()
            result=rows_to_fields(rows,["id","sender","body","created_at"])
        elif action == "CHAT_SEND_PUBLIC":
            body=clean(arg(0),6000).strip()
            if not body: raise ValueError("El mensaje está vacío.")
            if len(body)>6000: raise ValueError("Máximo 6000 caracteres.")
            conn.execute("INSERT INTO zyh_chat(kind,sender,recipient,body,created_at) VALUES('public',?,'',?,?)",(username,body,now()))
            add_activity(conn,username,"Chat público","Envió un mensaje al chat general"); result=["Enviado"]
        elif action == "LIST_PEERS":
            rows=conn.execute("SELECT username,role,active FROM zyh_users WHERE username<>? ORDER BY username",(username,)).fetchall()
            result=rows_to_fields(rows,["username","role","active"])
        elif action == "PRIVATE_STATUS":
            peer=clean(arg(0),64)
            validate_peer(conn,username,boss,role,peer)
            row=conn.execute("SELECT 1 FROM zyh_archives WHERE username=? AND peer=?",(username,peer)).fetchone()
            result=["1" if row else "0"]
        elif action == "CHAT_PRIVATE":
            peer=clean(arg(0),64); last=parse_int(arg(1,"0"),"ID",0)
            validate_peer(conn,username,boss,role,peer)
            where="((sender=? AND recipient=?) OR (sender=? AND recipient=?))"; params=(peer,username,username,peer)
            if last:
                rows=conn.execute(f"SELECT id,sender,recipient,body,created_at FROM zyh_chat WHERE kind='private' AND {where} AND id>? ORDER BY id LIMIT 120",params+(last,)).fetchall()
            else:
                rows=conn.execute(f"SELECT id,sender,recipient,body,created_at FROM zyh_chat WHERE kind='private' AND {where} ORDER BY id DESC LIMIT 120",params).fetchall()[::-1]
            result=rows_to_fields(rows,["id","sender","recipient","body","created_at"])
        elif action == "CHAT_SEND_PRIVATE":
            peer=clean(arg(0),64); body=clean(arg(1),6000).strip()
            validate_peer(conn,username,boss,role,peer)
            if not body: raise ValueError("El mensaje está vacío.")
            recipient=peer
            conn.execute("INSERT INTO zyh_chat(kind,sender,recipient,body,created_at) VALUES('private',?,?,?,?)",(username,recipient,body,now()))
            add_activity(conn,username,"Mensaje privado",f"Conversación privada con {peer}"); result=["Enviado"]
        elif action == "ARCHIVE_PRIVATE":
            peer=clean(arg(0),64); flag=arg(1,"1"); validate_peer(conn,username,boss,role,peer)
            store_peer=peer
            if flag == "1": conn.execute("INSERT OR REPLACE INTO zyh_archives(username,peer,archived_at) VALUES(?,?,?)",(username,store_peer,now()))
            else: conn.execute("DELETE FROM zyh_archives WHERE username=? AND peer=?",(username,store_peer))
            add_activity(conn,username,"Chat privado",f"{'Archivó' if flag=='1' else 'Restauró'} conversación con {store_peer}"); result=["Actualizado"]
        elif action == "AI_ORDER_ADD":
            require_role(role,"Supervisor")
            phone=clean(arg(0),40); product_id=parse_int(arg(1),"Producto",1); qty=parse_int(arg(2),"Cantidad",1)
            prow=conn.execute("SELECT id,name,quantity,price FROM products WHERE id=?",(product_id,)).fetchone()
            if not prow: raise ValueError("Ese producto no existe.")
            mine=conn.execute("SELECT id,quantity FROM ai_orders WHERE status='pendiente' AND phone=? AND product_id=?",(phone,product_id)).fetchone()
            reserved=conn.execute("SELECT COALESCE(SUM(quantity),0) FROM ai_orders WHERE status='pendiente' AND product_id=? AND id<>?",(product_id,mine["id"] if mine else 0)).fetchone()[0]
            available=int(prow["quantity"])-int(reserved)          # existencias reales menos lo ya apartado en otros pedidos
            if qty>available: result=["NO",str(max(available,0)),prow["name"]]
            else:
                price=float(prow["price"]); total=round(price*qty,2)
                if mine:
                    conn.execute("UPDATE ai_orders SET quantity=?,unit_price=?,total=?,created_at=? WHERE id=?",(qty,price,total,now(),mine["id"])); oid=mine["id"]
                else:
                    oid=conn.execute("INSERT INTO ai_orders(phone,product_id,product_name,quantity,unit_price,total,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)",(phone,product_id,prow["name"],qty,price,total,username,now())).lastrowid
                msg=f"🛒 Pedido #{oid} por WhatsApp (+{phone}): {qty} × {prow['name']} = {as_money(total)}. Cliente anotado, esperando aprobación de compra en IA WhatsApp → Pedidos."
                for u in conn.execute("SELECT username,role FROM zyh_users WHERE active=1 AND username<>?",(username,)).fetchall():
                    if ROLE_RANK.get(u["role"],0)>=ROLE_RANK["Supervisor"]:
                        conn.execute("INSERT INTO zyh_chat(kind,sender,recipient,body,created_at) VALUES('private',?,?,?,?)",(username,u["username"],msg,now()))
                add_activity(conn,username,"IA WhatsApp",f"Pedido #{oid} anotado: {prow['name']} x{qty} para +{phone}")
                result=["OK",str(oid),prow["name"],str(qty),as_money(total),str(available-qty)]
        elif action == "AI_ORDERS":
            require_role(role,"Supervisor")
            where="WHERE status<>'pendiente' AND sent=0" if arg(0)=="porenviar" else ""
            rows=conn.execute(f"SELECT id,phone,product_name,quantity,total,status,created_at,decided_by,note,sent,send_detail FROM ai_orders {where} ORDER BY (status='pendiente') DESC,id DESC LIMIT 200").fetchall()
            result=rows_to_fields(rows,["id","phone","product_name","quantity","total","status","created_at","decided_by","note","sent","send_detail"])
        elif action == "AI_ORDER_DECIDE":
            require_role(role,"Supervisor")
            oid=parse_int(arg(0),"Pedido",1); approve=arg(1)=="1"; note=clean(arg(2),300)
            o=conn.execute("SELECT * FROM ai_orders WHERE id=?",(oid,)).fetchone()
            if not o: raise ValueError("Ese pedido no existe.")
            if o["status"]!="pendiente": raise ValueError("Ese pedido ya fue decidido.")
            if not approve:
                conn.execute("UPDATE ai_orders SET status='rechazado',decided_by=?,decided_at=?,note=? WHERE id=?",(username,now(),note,oid)); result=["RECHAZADO"]
            else:
                prow=conn.execute("SELECT id,name,quantity,price FROM products WHERE id=?",(o["product_id"],)).fetchone()
                have=int(prow["quantity"]) if prow else 0
                if have<o["quantity"]:       # el stock se vuelve a confirmar al aprobar
                    conn.execute("UPDATE ai_orders SET status='sin_stock',decided_by=?,decided_at=?,note=? WHERE id=?",(username,now(),f"Quedan {have}",oid)); result=["SIN_STOCK",str(have)]
                else:
                    cur=conn.execute("INSERT INTO sales(customer_id,total,status,created_at,notes) VALUES(NULL,?,?,?,?)",(o["total"],"Por cobrar",now(),f"Pedido WhatsApp #{oid} · +{o['phone']} · aprobó {username}"))
                    conn.execute("INSERT INTO sale_items(sale_id,product_id,product_name,quantity,unit_price,subtotal) VALUES(?,?,?,?,?,?)",(cur.lastrowid,o["product_id"],o["product_name"],o["quantity"],o["unit_price"],o["total"]))
                    conn.execute("UPDATE products SET quantity=quantity-? WHERE id=?",(o["quantity"],o["product_id"]))
                    conn.execute("UPDATE ai_orders SET status='aprobado',decided_by=?,decided_at=?,note=?,sale_id=? WHERE id=?",(username,now(),note,cur.lastrowid,oid)); result=["APROBADO",str(cur.lastrowid)]
            add_activity(conn,username,"IA WhatsApp",f"Pedido #{oid}: {result[0].lower()}")
        elif action == "AI_ORDER_SENT":
            require_role(role,"Supervisor")
            oid=parse_int(arg(0),"Pedido",1); state=parse_int(arg(1),"Estado",0)
            conn.execute("UPDATE ai_orders SET sent=?,send_detail=? WHERE id=?",(state,clean(arg(2),300),oid)); result=["OK"]
        elif action == "BACKUP":
            require_role(role,"Administrador"); result=["OK"]
        elif action == "LOGOUT":
            add_activity(conn,username,"Cierre de sesión","Sesión finalizada"); result=["OK"]
        else: raise ValueError("Operación ZYH desconocida.")
        conn.commit()
        return result
    except Exception:
        conn.rollback(); raise

def re_username(username):
    import re
    return bool(re.fullmatch(r"[A-Za-z0-9_.-]{3,32}", username))
def validate_peer(conn, username, boss, role, peer):
    if not peer or not conn.execute("SELECT username FROM zyh_users WHERE username=? AND active=1",(peer,)).fetchone():
        raise ValueError("Conversación no disponible.")
    if peer == username: raise PermissionError("Elige a otra persona para chatear.")

class LocalSession:
    def __init__(self, username, role, boss, path=DB_PATH): self.username,self.role,self.boss,self.path=username,role,boss,path
    def rpc(self, action, *args):
        try: return dispatch(self.path,self.username,action,args)
        except Exception as exc: raise RuntimeError(str(exc))
    def close(self):
        try: self.rpc("LOGOUT")
        except Exception: pass

class RemoteSession:
    def __init__(self, sock, username, role, boss): self.sock,self.username,self.role,self.boss=sock,username,role,boss; self.lock=threading.Lock()
    @classmethod
    def connect(cls, host, port, username, password, parent):
        raw=socket.create_connection((host,port),timeout=8)
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT); ctx.minimum_version=ssl.TLSVersion.TLSv1_2; ctx.check_hostname=False; ctx.verify_mode=ssl.CERT_NONE
        try: secure=ctx.wrap_socket(raw,server_hostname="ZYH_BUSINESS")
        except Exception: raw.close(); raise
        cert=secure.getpeercert(binary_form=True); fp=hashlib.sha256(cert).hexdigest().upper(); p=trust_path(host,port)
        saved=p.read_text(encoding="ascii").strip().upper() if p.exists() else ""
        if saved and not secrets.compare_digest(saved,fp):
            secure.close(); raise RuntimeError("La huella TLS del servidor cambió. Conexión bloqueada por seguridad; verifica con el jefe antes de borrar el archivo .zyhtrust.")
        if not saved:
            message=(f"Primera conexión a {host}:{port}.\n\nHuella SHA-256 del servidor:\n{format_fingerprint(fp)}\n\nCompara este código con el mostrado por el jefe por otro medio. Solo acepta si coincide.\n\n¿Coincide y confías en este servidor?")
            if not messagebox.askyesno("Verificar servidor ZYH",message,parent=parent): secure.close(); raise RuntimeError("No se confió en el servidor; no se enviaron las credenciales.")
            p.write_text(fp,encoding="ascii")
        secure.settimeout(10)
        send_packet(secure,["LOGIN",username,password])
        try: reply=recv_packet(secure)
        except Exception: secure.close(); raise
        if not reply or reply[0] != "OK":
            secure.close(); raise RuntimeError(reply[1] if len(reply)>1 else "Inicio de sesión rechazado")
        return cls(secure,username,reply[1],reply[2] if len(reply)>2 else "")
    def rpc(self, action, *args):
        with self.lock:
            try:
                send_packet(self.sock,[action,*args]); reply=recv_packet(self.sock)
            except Exception as exc: raise RuntimeError(f"Conexión perdida: {exc}")
            if not reply: raise RuntimeError("Respuesta vacía del servidor")
            if reply[0] != "OK": raise RuntimeError(reply[1] if len(reply)>1 else "Error del servidor")
            return reply[1:]
    def close(self):
        try: self.rpc("LOGOUT")
        except Exception: pass
        try: self.sock.close()
        except Exception: pass

class NetworkServer:
    def __init__(self, path=DB_PATH, port=PORT_DEFAULT):
        self.path=path; self.port=port; self.running=False; self.sock=None; self.thread=None
        self.fail_lock=threading.Lock(); self.failures={}  # ip -> (fallos, bloqueado_hasta)
    def _login_blocked(self, ip):
        with self.fail_lock:
            count, until = self.failures.get(ip, (0, 0.0))
            return until > time.monotonic()
    def _login_result(self, ip, ok):
        with self.fail_lock:
            if ok: self.failures.pop(ip, None); return
            count, until = self.failures.get(ip, (0, 0.0)); count += 1
            self.failures[ip] = (0, time.monotonic() + LOGIN_LOCK_SECONDS) if count >= LOGIN_MAX_FAILS else (count, until)
    def start(self):
        ensure_certificate()
        ctx=ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER); ctx.minimum_version=ssl.TLSVersion.TLSv1_2
        ctx.load_cert_chain(str(CERT_PATH),str(KEY_PATH))
        sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM); sock.setsockopt(socket.SOL_SOCKET,socket.SO_REUSEADDR,1)
        sock.bind(("0.0.0.0",self.port)); sock.listen(32); sock.settimeout(1)
        self.sock=sock; self.ctx=ctx; self.running=True
        self.thread=threading.Thread(target=self._accept_loop,daemon=True,name="ZYH-TLS-Server"); self.thread.start()
    def _accept_loop(self):
        while self.running:
            try: raw,_=self.sock.accept()
            except socket.timeout: continue
            except OSError: break
            threading.Thread(target=self._client,args=(raw,),daemon=True).start()
    def _client(self, raw):
        secure=None; username=None
        try:
            try: ip=raw.getpeername()[0]
            except OSError: ip="?"
            raw.settimeout(15)  # el saludo TLS no puede quedarse colgado
            secure=self.ctx.wrap_socket(raw,server_side=True); secure.settimeout(60)
            first=recv_packet(secure)
            if len(first)<3 or first[0] != "LOGIN": send_packet(secure,["ERR","Primero debes iniciar sesión."]); return
            if self._login_blocked(ip):
                send_packet(secure,["ERR",f"Demasiados intentos fallidos desde {ip}. Espera {LOGIN_LOCK_SECONDS} segundos."]); return
            auth=authenticate(self.path,first[1],first[2])
            self._login_result(ip, bool(auth))
            if not auth: send_packet(secure,["ERR","Usuario o contraseña incorrectos, o cuenta desactivada."]); return
            username,role,boss=auth; send_packet(secure,["OK",role,boss])
            while self.running:
                try: req=recv_packet(secure)
                except socket.timeout: continue
                if not req: break
                action,*args=req
                try: answer=dispatch(self.path,username,action,args); send_packet(secure,["OK",*answer])
                except Exception as exc: send_packet(secure,["ERR",clean(str(exc),1000)])
        except (ConnectionError, OSError, ssl.SSLError, ValueError): pass
        finally:
            try:
                if secure: secure.close()
                else: raw.close()
            except Exception: pass
    def stop(self):
        self.running=False
        try: self.sock.close()
        except Exception: pass

def lan_ip():
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    try: s.connect(("192.0.2.1",80)); ip=s.getsockname()[0]
    except OSError: ip="127.0.0.1"
    finally: s.close()
    return ip

def read_config():
    result={"theme":"dark","accent":"#1f6aa5","wallpaper":""}
    if CONFIG_PATH.exists():
        for line in CONFIG_PATH.read_text(encoding="utf-8",errors="ignore").splitlines():
            if "=" in line:
                k,v=line.split("=",1)
                if k in result: result[k]=v
    return result
def write_config(config):
    # Formato key=value propio ZYH; no JSON.
    CONFIG_PATH.write_text("\n".join(f"{k}={str(v).replace(chr(10),' ')}" for k,v in config.items())+"\n",encoding="utf-8")

try: ctk.set_appearance_mode(read_config().get("theme","dark") if read_config().get("theme") in ("dark","light") else "dark")
except Exception: ctk.set_appearance_mode("dark")
ctk.set_default_color_theme("blue")

class ConnectionWindow(ctk.CTk):
    def __init__(self):
        super().__init__(); self.title(f"{APP_NAME} {APP_VERSION} · {PLATFORM_LABEL}"); fit_window(self,610,660,520,520); self.resizable(False,False)
        self.configure(fg_color="#0d1421")
        initialize_schema()
        self.server=None; self.session=None
        self._center()
        ctk.CTkLabel(self,text="ZYH_BUSINESS",font=ctk.CTkFont(size=31,weight="bold"),text_color="#8bf5a2").pack(pady=(27,2))
        ctk.CTkLabel(self,text="Suite empresarial segura para LAN / WLAN",text_color="#a7b5c9").pack(pady=(0,18))
        self.tabs=ctk.CTkTabview(self,width=550,height=500); self.tabs.pack(padx=20,pady=8,fill="both",expand=True)
        self.tabs.add("Servidor / local")
        self.tab_local=self.tabs.tab("Servidor / local")
        if not LOCAL_EDITION:
            self.tabs.add("Conectar a empresa"); self.tab_connect=self.tabs.tab("Conectar a empresa")
        users=db_connect(); count=users.execute("SELECT COUNT(*) FROM zyh_users").fetchone()[0]; users.close()
        if count==0: self.build_setup()
        else: self.build_local_login()
        if not LOCAL_EDITION: self.build_remote_login()
        ctk.CTkLabel(self,text="Chat general permanente · Privados archivables · Roles jerárquicos",text_color="#8b9bb0",font=ctk.CTkFont(size=11)).pack(pady=(0,12))
    def _start_server(self):
        if LOCAL_EDITION: return None
        ensure_certificate(); srv = NetworkServer(); srv.start(); return srv
    def _center(self):
        self.update_idletasks(); fit_window(self,610,660,520,520)
    def clear_tab(self,tab):
        for w in tab.winfo_children(): w.destroy()
    def build_setup(self):
        t=self.tab_local
        ctk.CTkLabel(t,text="Crear el servidor principal",font=ctk.CTkFont(size=20,weight="bold")).pack(pady=(10,12))
        ctk.CTkLabel(t,text="Este equipo alojará los datos compartidos. Los otros equipos se conectan por la IP de la red.",wraplength=480).pack(pady=(0,12))
        self.company=ctk.CTkEntry(t,placeholder_text="Nombre de la empresa"); self.company.pack(fill="x",padx=32,pady=5); self.company.insert(0,"Mi empresa")
        self.user=ctk.CTkEntry(t,placeholder_text="Usuario jefe (3–32 caracteres)"); self.user.pack(fill="x",padx=32,pady=5)
        self.pw=ctk.CTkEntry(t,placeholder_text="Contraseña (mínimo 8 caracteres)",show="●"); self.pw.pack(fill="x",padx=32,pady=5)
        self.pw2=ctk.CTkEntry(t,placeholder_text="Repite la contraseña",show="●"); self.pw2.pack(fill="x",padx=32,pady=5)
        ctk.CTkButton(t,text="Crear empresa y arrancar servidor",height=42,command=self.create_server).pack(fill="x",padx=32,pady=14)
        ctk.CTkLabel(t,text="El servidor debe permanecer abierto mientras los demás equipos lo usan.",text_color="#a7b5c9",wraplength=460).pack(pady=6)
    def build_local_login(self):
        t=self.tab_local
        ctk.CTkLabel(t,text="Iniciar sesión en este equipo",font=ctk.CTkFont(size=20,weight="bold")).pack(pady=(14,14))
        self.local_user=ctk.CTkEntry(t,placeholder_text="Usuario"); self.local_user.pack(fill="x",padx=32,pady=6)
        self.local_pw=ctk.CTkEntry(t,placeholder_text="Contraseña",show="●"); self.local_pw.pack(fill="x",padx=32,pady=6)
        self.local_pw.bind("<Return>",lambda _e:self.login_local())
        ctk.CTkButton(t,text="Entrar y activar servidor LAN/WLAN",height=42,command=self.login_local).pack(fill="x",padx=32,pady=14)
    def build_remote_login(self):
        t=self.tab_connect
        ctk.CTkLabel(t,text="Conectarse a la empresa",font=ctk.CTkFont(size=20,weight="bold")).pack(pady=(10,12))
        ctk.CTkLabel(t,text="Usa la IP que aparece en el equipo del jefe. Ambos deben estar en la misma LAN/WLAN.",wraplength=480).pack(pady=(0,9))
        self.host=ctk.CTkEntry(t,placeholder_text="IP o nombre del servidor, ej. 192.168.1.20"); self.host.pack(fill="x",padx=32,pady=5)
        self.port=ctk.CTkEntry(t,placeholder_text=f"Puerto (predeterminado {PORT_DEFAULT})"); self.port.pack(fill="x",padx=32,pady=5); self.port.insert(0,str(PORT_DEFAULT))
        self.remote_user=ctk.CTkEntry(t,placeholder_text="Tu usuario"); self.remote_user.pack(fill="x",padx=32,pady=5)
        self.remote_pw=ctk.CTkEntry(t,placeholder_text="Tu contraseña",show="●"); self.remote_pw.pack(fill="x",padx=32,pady=5)
        self.remote_pw.bind("<Return>",lambda _e:self.login_remote())
        ctk.CTkButton(t,text="Conectar con TLS",height=42,command=self.login_remote).pack(fill="x",padx=32,pady=14)
        ctk.CTkLabel(t,text="Primera conexión: compara la huella SHA-256 con la que muestra el jefe.",text_color="#a7b5c9",wraplength=460).pack(pady=6)
    def create_server(self):
        company=clean(self.company.get(),150).strip(); user=clean(self.user.get(),32).strip(); pw=self.pw.get(); pw2=self.pw2.get()
        if not company: messagebox.showerror("Empresa","Escribe el nombre de la empresa.",parent=self); return
        if not re_username(user): messagebox.showerror("Usuario","Usa 3–32 caracteres: letras, números, punto, guion o guion bajo.",parent=self); return
        if len(pw)<8: messagebox.showerror("Contraseña","Usa al menos 8 caracteres.",parent=self); return
        if pw!=pw2: messagebox.showerror("Contraseña","Las contraseñas no coinciden.",parent=self); return
        try:
            salt,pwh=hash_password(pw); conn=db_connect()
            if conn.execute("SELECT COUNT(*) FROM zyh_users").fetchone()[0]: conn.close(); raise RuntimeError("Ya existe una empresa configurada en este equipo.")
            conn.execute("INSERT INTO zyh_users(username,role,salt,password_hash,active,created_at) VALUES(?, 'Jefe',?,?,1,?)",(user,salt,pwh,now()))
            conn.execute("INSERT OR REPLACE INTO zyh_settings(key,value) VALUES('boss_username',?)",(user,))
            conn.execute("INSERT OR REPLACE INTO zyh_settings(key,value) VALUES('company_name',?)",(company,)); conn.commit(); conn.close()
            self.server=self._start_server()
            self.launch(LocalSession(user,"Jefe",user))
        except Exception as exc: messagebox.showerror("No se pudo crear el servidor",str(exc),parent=self)
    def login_local(self):
        user=self.local_user.get().strip(); pw=self.local_pw.get()
        try:
            auth=authenticate(DB_PATH,user,pw)
            if not auth: raise RuntimeError("Usuario o contraseña incorrectos, o cuenta desactivada.")
            name,role,boss=auth; self.server=self._start_server()
            self.launch(LocalSession(name,role,boss))
        except Exception as exc: messagebox.showerror("Inicio de sesión",str(exc),parent=self)
    def login_remote(self):
        host=self.host.get().strip(); user=self.remote_user.get().strip(); pw=self.remote_pw.get()
        try:
            port=parse_int(self.port.get(),"Puerto",1)
            if port>65535: raise ValueError("El puerto debe ser máximo 65535.")
            if not host: raise ValueError("Escribe la IP o el nombre del servidor.")
            session=RemoteSession.connect(host,port,user,pw,self)
            self.launch(session)
        except Exception as exc: messagebox.showerror("Conexión ZYH",str(exc),parent=self)
    def export_backup(self):
        p=filedialog.asksaveasfilename(parent=self,title="Guardar copia de seguridad",defaultextension=".zyhbak",filetypes=[("Respaldo ZYH","*.zyhbak")])
        if not p:return
        try:
            src=db_connect(); dst=sqlite3.connect(p); src.backup(dst); dst.close(); src.close(); messagebox.showinfo("Respaldo","Copia .zyhbak creada.",parent=self)
        except Exception as exc: messagebox.showerror("Respaldo",str(exc),parent=self)
    def launch(self,session):
        self.session=session; self.withdraw(); app=BusinessApp(session,self.server,self); app.mainloop()

class BusinessApp(ctk.CTk):
    def __init__(self, session, server, gate):
        super().__init__(); self.session=session; self.server=server; self.gate=gate; self.role=session.role; self.username=session.username; self.boss=session.boss
        self.app_config=read_config(); self.title(f"ZYH_BUSINESS {APP_VERSION} — {self.username} ({self.role})"); fit_window(self,1320,820,900,560)
        self.current_page="Resumen"; self._poll_id=None; self.public_last=0; self.private_last={}; self.public_labels=[]; self.private_labels=[]; self.peer=""; self.show_archived=False; self.wall_image=None; self.wall_path=self.app_config.get("wallpaper","")
        self._ui_queue=queue.Queue()
        self.colors={"dark":"#101827","accent":"#1f6aa5","light":"#e9eef5"}; self._load_wallpaper(); self._build_shell(); self.show_page("Resumen")
        self._poll_id=self.after(2200,self._poll)
        self.protocol("WM_DELETE_WINDOW",self.close_app)
    def _load_wallpaper(self):
        self.wall_image=None
        p=Path(self.wall_path) if self.wall_path else None
        if p and p.is_file():
            try:
                from PIL import Image
                im=Image.open(p); im.thumbnail((1400,900)); self.wall_image=ctk.CTkImage(light_image=im,dark_image=im,size=im.size)
            except Exception: self.wall_image=None
    def _build_shell(self):
        self.grid_columnconfigure(1,weight=1); self.grid_rowconfigure(0,weight=1)
        self.sidebar=ctk.CTkFrame(self,width=210,corner_radius=0,fg_color="#0b1220"); self.sidebar.grid(row=0,column=0,sticky="nsew"); self.sidebar.grid_rowconfigure(20,weight=1)
        ctk.CTkLabel(self.sidebar,text="ZYH",font=ctk.CTkFont(size=29,weight="bold"),text_color="#8bf5a2").grid(row=0,column=0,padx=16,pady=(18,0),sticky="w")
        ctk.CTkLabel(self.sidebar,text="BUSINESS",font=ctk.CTkFont(size=13,weight="bold"),text_color="#bac6d8").grid(row=1,column=0,padx=18,pady=(0,16),sticky="w")
        all_items=[("Resumen","house"),("Clientes","users"),("Inventario","package"),("Ventas","shopping-cart"),("Gastos","wallet"),("Cotizaciones","file-text"),("Tareas","check-square"),("Chat LAN/WLAN","messages"),("Usuarios","user-cog"),("Auditoría","activity"),("IA WhatsApp","bot"),("Tipo de negocio","briefcase"),("Planes","ticket"),("Apariencia","palette")]
        self.ext=zyh_ext.load_active(DATA_DIR); self._nav_btns={}
        allowed=[]
        for title,_ in all_items:
            if title=="Usuarios" and ROLE_RANK[self.role]<ROLE_RANK["Administrador"]: continue
            if title=="Auditoría" and ROLE_RANK[self.role]<ROLE_RANK["Jefe"]: continue
            allowed.append(title)
        for i,(title,_) in enumerate(all_items,2):
            if title not in allowed: continue
            btn=ctk.CTkButton(self.sidebar,text=self.L(title),anchor="w",height=38,corner_radius=8,fg_color="transparent",hover_color="#1c2b42",command=lambda p=title:self.show_page(p))
            btn.grid(row=i,column=0,sticky="ew",padx=10,pady=3); self._nav_btns[title]=btn
        ctk.CTkLabel(self.sidebar,text=f"{self.username}\n{self.role}",justify="left",text_color="#a8b8cd").grid(row=20,column=0,sticky="sw",padx=15,pady=12)
        self.page_host=ctk.CTkFrame(self,corner_radius=0,fg_color="transparent"); self.page_host.grid(row=0,column=1,sticky="nsew"); self.page_host.grid_rowconfigure(0,weight=1); self.page_host.grid_columnconfigure(0,weight=1)
        self.status=ctk.CTkLabel(self,text=f"Conectado · Usuario: {self.username} · Servidor: {self.boss}",anchor="w",height=25,fg_color="#0b1220",text_color="#b7c4d7")
        self.status.grid(row=1,column=0,columnspan=2,sticky="ew")
    def _page(self,title):
        for w in self.page_host.winfo_children(): w.destroy()
        self.page=ctk.CTkFrame(self.page_host,corner_radius=0,fg_color="transparent"); self.page.grid(row=0,column=0,sticky="nsew")
        if self.wall_image:
            bg=ctk.CTkLabel(self.page,text="",image=self.wall_image); bg.place(relx=0,rely=0,relwidth=1,relheight=1); bg.lower()
        head=ctk.CTkFrame(self.page,fg_color="#101827",corner_radius=10); head.pack(fill="x",padx=18,pady=(16,10))
        ctk.CTkLabel(head,text=self.L(title),font=ctk.CTkFont(size=25,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=16,pady=12)
        body=ctk.CTkFrame(self.page,fg_color="transparent"); body.pack(fill="both",expand=True,padx=18,pady=(0,14))
        try:self.session.rpc("NAVIGATE",title)
        except Exception as exc:self._set_status(str(exc))
        # 2.0 guardaba el título visible ("Chat LAN / WLAN") y el chat comparaba con "Chat LAN/WLAN",
        # así que nunca mostraba mensajes. Ahora se guarda la clave del menú.
        self.current_page=getattr(self,"_pending_page",None) or title
        return body
    def _set_status(self,text):
        try:self.status.configure(text=clean(text,220))
        except Exception:pass
    def _rows(self,data,width):
        if not data: return []
        n=int(data[0]); vals=data[1:]; return [vals[i*width:(i+1)*width] for i in range(n) if len(vals)>=(i+1)*width]
    def _button(self,parent,text,command,color=None):return ctk.CTkButton(parent,text=text,command=command,fg_color=color or self.app_config.get("accent","#1f6aa5"),height=34)
    def show_page(self,title):
        self._pending_page=title
        if title not in ("Resumen","Planes","Apariencia") and not (_zyh_guard and _zyh_guard.require("business")):
            self._no_plan_notice=True; title="Planes"; self._pending_page=title
        try:
            if title=="Resumen": self.show_dashboard()
            elif title=="Clientes": self.show_customers()
            elif title=="Inventario": self.show_products()
            elif title=="Ventas": self.show_sales()
            elif title=="Gastos": self.show_expenses()
            elif title=="Cotizaciones": self.show_quotes()
            elif title=="Tareas": self.show_tasks()
            elif title=="Chat LAN/WLAN": self.show_chat()
            elif title=="Usuarios": self.show_users()
            elif title=="Auditoría": self.show_activity()
            elif title=="IA WhatsApp": self.show_ai()
            elif title=="Tipo de negocio": self.show_business_type()
            elif title in ("Planes","Planes Bridger","Planes ZYH Bridger"): self.show_business_plans()
            elif title=="Apariencia": self.show_appearance()
        except Exception as exc: messagebox.showerror("ZYH_BUSINESS",str(exc),parent=self)
    def show_dashboard(self):
        b=self._page("Resumen empresarial")
        data=self.session.rpc("DASHBOARD")
        actions=ctk.CTkFrame(b,fg_color="transparent"); actions.pack(fill="x",pady=(0,5))
        ctk.CTkButton(actions,text="Exportar informe .zyhrpt",command=self.export_report).pack(side="left",padx=(0,8),pady=3)
        if self.server and ROLE_RANK[self.role]>=ROLE_RANK["Administrador"]:
            ctk.CTkButton(actions,text="Crear respaldo .zyhbak",fg_color="#52647a",command=self.backup_database).pack(side="left",pady=3)
        labels=[("Clientes",data[0]),("Productos",data[1]),("Ventas",as_money(data[2])),("Gastos",as_money(data[3])),("Cotizaciones abiertas",data[4]),("Tareas pendientes",data[5]),("Productos bajo mínimo",data[6])]
        grid=ctk.CTkFrame(b,fg_color="transparent"); grid.pack(fill="x",pady=6)
        for i,(label,value) in enumerate(labels):
            card=ctk.CTkFrame(grid,corner_radius=12,fg_color="#172235"); card.grid(row=i//3,column=i%3,sticky="ew",padx=5,pady=5)
            ctk.CTkLabel(card,text=label,text_color="#b6c4d8").pack(anchor="w",padx=16,pady=(12,2))
            ctk.CTkLabel(card,text=str(value),font=ctk.CTkFont(size=23,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=16,pady=(0,13))
        for i in range(3):grid.grid_columnconfigure(i,weight=1)
        info=ctk.CTkFrame(b,corner_radius=12,fg_color="#111d2e"); info.pack(fill="both",expand=True,pady=8)
        ctk.CTkLabel(info,text="Servidor y seguridad",font=ctk.CTkFont(size=18,weight="bold")).pack(anchor="w",padx=18,pady=(15,7))
        if LOCAL_EDITION: details="Edición local: los datos viven solo en este equipo. No hay servidor de red ni conexiones externas."
        elif self.server:
            try: fp=format_fingerprint(certificate_fingerprint())
            except Exception: fp="No disponible"
            details=f"Servidor activo en 0.0.0.0:{self.server.port}\nIP LAN/WLAN de este equipo: {lan_ip()}\nHuella TLS SHA-256 (comparte con los empleados por otro medio):\n{fp}"
        else: details=f"Cliente conectado al servidor de {self.boss}.\nEl tráfico de red usa TLS. El protocolo ZYH es el formato de paquetes, no un cifrado casero."
        ctk.CTkLabel(info,text=details,justify="left",wraplength=850).pack(anchor="w",padx=18,pady=5)
        ctk.CTkButton(info,text="Cambiar mi contraseña",command=self.change_password).pack(anchor="w",padx=18,pady=10)
        ctk.CTkLabel(info,text="Los registros de auditoría guardan acciones dentro de la app; no graban pantalla ni teclas.",text_color="#a7b5c9",wraplength=900).pack(anchor="w",padx=18,pady=(0,15))
    def export_report(self):
        path=filedialog.asksaveasfilename(parent=self,title="Guardar informe ZYH",defaultextension=".zyhrpt",filetypes=[("Informe ZYH","*.zyhrpt")])
        if not path:return
        try:
            d=self.session.rpc("DASHBOARD")
            lines=["ZYH_BUSINESS — INFORME EMPRESARIAL",f"Generado: {now()}",f"Usuario: {self.username} ({self.role})","", "RESUMEN",
                   f"Clientes: {d[0]}",f"Productos: {d[1]}",f"Ventas registradas: {as_money(d[2])}",f"Gastos registrados: {as_money(d[3])}",
                   f"Cotizaciones abiertas: {d[4]}",f"Tareas pendientes: {d[5]}",f"Productos bajo stock mínimo: {d[6]}","",
                   "Nota: informe generado por ZYH_BUSINESS; validar los datos con los registros originales."]
            Path(path).write_text("\n".join(lines)+"\n",encoding="utf-8")
            self._set_status(f"Informe guardado: {path}");messagebox.showinfo("Informe","Informe .zyhrpt exportado.",parent=self)
        except Exception as exc:messagebox.showerror("Informe",str(exc),parent=self)
    def backup_database(self):
        if not self.server or ROLE_RANK[self.role]<ROLE_RANK["Administrador"]:
            messagebox.showerror("Respaldo","El respaldo de la base central solo está disponible para administradores en el equipo servidor.",parent=self);return
        path=filedialog.asksaveasfilename(parent=self,title="Guardar respaldo de empresa",defaultextension=".zyhbak",filetypes=[("Respaldo ZYH","*.zyhbak")])
        if not path:return
        try:
            src=db_connect(self.server.path);dst=sqlite3.connect(path);src.backup(dst);dst.close();src.close()
            self._set_status("Respaldo .zyhbak creado");messagebox.showinfo("Respaldo","Base central respaldada correctamente.",parent=self)
        except Exception as exc:messagebox.showerror("Respaldo",str(exc),parent=self)
    def form(self,title,fields,on_save):
        win=ctk.CTkToplevel(self); win.title(title); fit_window(win,560,min(680,160+len(fields)*64),420,300); win.resizable(False,True); win.transient(self); win.grab_set()
        frame=ctk.CTkScrollableFrame(win,fg_color="transparent"); frame.pack(fill="both",expand=True,padx=18,pady=14); entries={}
        for label,key,default,*extra in fields:
            ctk.CTkLabel(frame,text=label,anchor="w").pack(fill="x",pady=(7,2))
            kind=extra[0] if extra else "entry"; opts=extra[1] if len(extra)>1 else []
            if kind=="combo":
                w=ctk.CTkComboBox(frame,values=opts); w.pack(fill="x"); w.set(default or (opts[0] if opts else ""))
            elif kind=="text":
                w=ctk.CTkTextbox(frame,height=85); w.pack(fill="x"); w.insert("1.0",str(default or ""))
            else:
                secret = ("password" in key.lower()) or key.lower() in ("old", "new")
                w=ctk.CTkEntry(frame, show="●" if secret else ""); w.pack(fill="x"); w.insert(0,str(default or ""))
            entries[key]=(w,kind)
        def save():
            values={k:(w.get("1.0","end-1c").strip() if knd=="text" else w.get().strip()) for k,(w,knd) in entries.items()}
            try: on_save(values); win.destroy(); self._set_status(f"{title}: guardado")
            except Exception as exc: messagebox.showerror("No se pudo guardar",str(exc),parent=win)
        ctk.CTkButton(frame,text="Guardar",command=save,height=38).pack(fill="x",pady=16)
    def list_page(self,title,load,display,add=None,edit=None,extra_actions=None,headers=None,add_label="＋ Nuevo",page_name=None,extra_top=None):
        """Lista optimizada: dibuja PAGE_SIZE filas por vez, con buscador y exportación CSV."""
        page_name=page_name or title
        b=self._page(title); top=ctk.CTkFrame(b,fg_color="#111d2e",corner_radius=10); top.pack(fill="x",pady=(0,8))
        if add: self._button(top,add_label,add).pack(side="left",padx=10,pady=8)
        self._button(top,"↻ Actualizar",lambda:self.show_page(page_name)).pack(side="left",padx=4,pady=8)
        if extra_top: extra_top(top)
        search=ctk.CTkEntry(top,placeholder_text="Buscar…",width=220); search.pack(side="left",padx=10,pady=8)
        self._button(top,"Exportar CSV",lambda:self._export_csv(title,state["filtered"],headers),color="#52647a").pack(side="left",padx=4,pady=8)
        count_lbl=ctk.CTkLabel(top,text="",text_color="#a7b5c9"); count_lbl.pack(side="right",padx=12)
        scroll=ctk.CTkScrollableFrame(b,fg_color="#111d2e",corner_radius=10); scroll.pack(fill="both",expand=True)
        rows=load(); state={"rows":rows,"filtered":rows,"shown":0,"more":None,"job":None}
        def render(reset=False):
            if reset:
                for w in scroll.winfo_children(): w.destroy()
                state["shown"]=0; state["more"]=None
            if state["more"] is not None: state["more"].destroy(); state["more"]=None
            data=state["filtered"]
            if not data:
                ctk.CTkLabel(scroll,text="Todavía no hay registros." if not state["rows"] else "Sin resultados para esa búsqueda.",text_color="#b0bfd2").pack(pady=22)
            for row in data[state["shown"]:state["shown"]+PAGE_SIZE]:
                item=ctk.CTkFrame(scroll,fg_color="#1a2940",corner_radius=8); item.pack(fill="x",padx=7,pady=5)
                ctk.CTkLabel(item,text=display(row),justify="left",anchor="w",wraplength=830).pack(side="left",fill="x",expand=True,padx=12,pady=11)
                if edit:self._button(item,"Editar",lambda r=row:edit(r)).pack(side="right",padx=8,pady=7)
                if extra_actions: extra_actions(item,row)
            state["shown"]=min(len(data),state["shown"]+PAGE_SIZE)
            if state["shown"]<len(data):
                state["more"]=ctk.CTkButton(scroll,text=f"Mostrar {min(PAGE_SIZE,len(data)-state['shown'])} más",fg_color="#52647a",command=render)
                state["more"].pack(pady=10)
            count_lbl.configure(text=f"Mostrando {state['shown']} de {len(data)}"+(f" (total {len(state['rows'])})" if len(data)!=len(state["rows"]) else ""))
        def apply_filter():
            state["job"]=None; q=search.get().strip().lower()
            state["filtered"]=[r for r in state["rows"] if q in " ".join(map(str,r)).lower()] if q else state["rows"]
            render(reset=True)
        def on_key(_e=None):
            if state["job"]: self.after_cancel(state["job"])
            state["job"]=self.after(250,apply_filter)
        search.bind("<KeyRelease>",on_key)
        render(reset=True)
    def _export_csv(self,title,rows,headers=None):
        if not rows: messagebox.showinfo("Exportar CSV","No hay filas para exportar.",parent=self); return
        name="".join(c if c.isalnum() else "_" for c in title.lower()).strip("_") or "lista"
        path=filedialog.asksaveasfilename(parent=self,title="Exportar a CSV",defaultextension=".csv",initialfile=f"zyh_{name}_{date.today().isoformat()}.csv",filetypes=[("CSV (Excel, LibreOffice)","*.csv")])
        if not path: return
        try:
            with open(path,"w",newline="",encoding="utf-8-sig") as f:  # utf-8-sig: Excel en Windows reconoce las tildes
                w=csv.writer(f,delimiter=";")
                if headers: w.writerow(headers)
                w.writerows(rows)
            self._set_status(f"CSV exportado: {path}"); messagebox.showinfo("Exportar CSV",f"{len(rows)} fila(s) exportadas.",parent=self)
        except Exception as exc: messagebox.showerror("Exportar CSV",str(exc),parent=self)
    def show_customers(self):
        fields=[("ID","id",""),("Nombre / empresa","name",""),("Documento NIT / ID","document",""),("Teléfono","phone",""),("Correo","email",""),("Notas","notes","")]
        def rows():return self._rows(self.session.rpc("LIST_CUSTOMERS"),7)
        def save(v):self.session.rpc("SAVE_CUSTOMER",v["id"],v["name"],v["document"],v["phone"],v["email"],v["notes"]);self.show_customers()
        def add():self.form("Nuevo cliente",fields[1:],save)
        def edit(r):self.form("Editar cliente",[(x[0],x[1],r[i]) for i,x in enumerate(fields)],save)
        def confirm_delete(r):
            if ROLE_RANK[self.role]>=ROLE_RANK["Administrador"] and messagebox.askyesno("Eliminar cliente",f"¿Eliminar cliente {r[1]}?",parent=self):
                try:self.session.rpc("DELETE_CUSTOMER",r[0]);self.show_customers()
                except Exception as e:messagebox.showerror("Clientes",str(e),parent=self)
        def delete(item,r):
            # 2.0 preguntaba al dibujar cada fila; ahora es un botón que pregunta al pulsarlo.
            self._button(item,"Eliminar",lambda row=r:confirm_delete(row),color="#8f2d2d").pack(side="right",padx=4,pady=7)
        can_edit=ROLE_RANK[self.role]>=ROLE_RANK["Supervisor"]
        self.list_page("Clientes",rows,lambda r:f"#{r[0]} · {r[1]}  |  {r[2]}  |  {r[3]}\n{r[4]}  {r[5]}",add if can_edit else None,edit if can_edit else None,delete if ROLE_RANK[self.role]>=ROLE_RANK["Administrador"] else None,
                       headers=["ID","Nombre","Documento","Teléfono","Correo","Notas","Creado"])
    def show_products(self):
        fields=[("ID","id",""),("SKU","sku",""),("Nombre","name",""),("Cantidad","quantity","0"),("Stock mínimo","minimum","0"),("Costo unitario","cost","0"),("Precio de venta","price","0"),("Notas","notes","")]
        def rows():return self._rows(self.session.rpc("LIST_PRODUCTS"),8)
        def save(v):self.session.rpc("SAVE_PRODUCT",v["id"],v["sku"],v["name"],v["quantity"],v["minimum"],v["cost"],v["price"],v["notes"]);self.show_products()
        def add():self.form("Nuevo producto",fields[1:],save)
        def edit(r):self.form("Editar producto",[(x[0],x[1],r[i]) for i,x in enumerate(fields)],save)
        def confirm_delete(r):
            if messagebox.askyesno("Eliminar producto",f"¿Eliminar {r[2]}?",parent=self):
                try:self.session.rpc("DELETE_PRODUCT",r[0]);self.show_products()
                except Exception as e:messagebox.showerror("Inventario",str(e),parent=self)
        def delete(item,r):
            self._button(item,"Eliminar",lambda row=r:confirm_delete(row),color="#8f2d2d").pack(side="right",padx=4,pady=7)
        extra=delete if ROLE_RANK[self.role]>=ROLE_RANK["Administrador"] else None
        can_edit=ROLE_RANK[self.role]>=ROLE_RANK["Supervisor"]
        self.list_page("Inventario",rows,lambda r:f"#{r[0]} · {r[1]} — {r[2]}\nExistencias: {r[3]} (mín. {r[4]}) | costo {as_money(r[5])} | venta {as_money(r[6])}"+("   ⚠ STOCK BAJO" if int(r[3])<=int(r[4]) else ""),add if can_edit else None,edit if can_edit else None,extra,
                       headers=["ID","SKU","Nombre","Cantidad","Stock mínimo","Costo","Precio","Notas"],
                       extra_top=lambda top:self._button(top,"▮▮ Escanear código",self.scan_inventory,color="#0f766e").pack(side="left",padx=4,pady=8))
    def show_sales(self):
        self.list_page("Ventas",lambda:self._rows(self.session.rpc("LIST_SALES"),7),
                       lambda r:f"Venta #{r[0]} · {r[1]} · {as_money(r[2])} · {r[3]}\n{r[4]} · {r[6]}\n{r[5]}",
                       self.new_sale,add_label="＋ Registrar venta",headers=["Venta","Cliente","Total","Estado","Fecha","Notas","Productos"],
                       extra_top=lambda top:self._button(top,"▮▮ Vender escaneando",self.scan_sale,color="#0f766e").pack(side="left",padx=4,pady=8))
    def new_sale(self):
        products=self._rows(self.session.rpc("LIST_PRODUCTS"),8); customers=self._rows(self.session.rpc("LIST_CUSTOMERS"),7)
        if not products:messagebox.showinfo("Ventas","Primero registra productos en Inventario.",parent=self);return
        p_opts=[f"{p[0]} | {p[1]} | {p[2]} | stock={p[3]} | precio={as_money(p[6])}" for p in products]
        c_opts=["0 | Venta general"]+[f"{c[0]} | {c[1]}" for c in customers]
        def save(v):
            pid=v["product"].split(" | ")[0]; cid=v["customer"].split(" | ")[0]
            self.session.rpc("CREATE_SALE","" if cid=="0" else cid,pid,v["quantity"],v["notes"]);self.show_sales()
        self.form("Registrar venta",[("Producto","product",p_opts[0],"combo",p_opts),("Cliente","customer",c_opts[0],"combo",c_opts),("Cantidad","quantity","1"),("Notas","notes","")],save)
    def show_expenses(self):
        fields=[("Categoría","category",self.ext_cats()[0],"combo",self.ext_cats()),("Descripción","description",""),("Valor","amount","0"),("Fecha AAAA-MM-DD","date",date.today().isoformat()),("Notas","notes","")]
        def rows():return self._rows(self.session.rpc("LIST_EXPENSES"),6)
        def add():self.form("Registrar gasto",fields,lambda v:(self.session.rpc("SAVE_EXPENSE",v["category"],v["description"],v["amount"],v["date"],v["notes"]),self.show_expenses()))
        self.list_page("Gastos",rows,lambda r:f"#{r[0]} · {r[1]} · {r[2]} · {r[3]}\n{as_money(r[4])} · {r[5]}",add if ROLE_RANK[self.role]>=ROLE_RANK["Supervisor"] else None,
                       headers=["ID","Fecha","Categoría","Descripción","Valor","Notas"])
    def show_quotes(self):
        fields=[("Cliente","customer",""),("Descripción","description",""),("Valor","amount","0"),("Estado","status","Borrador","combo",["Borrador","Enviada","Aceptada","Rechazada"]),("Válida hasta","valid_until",""),("Notas","notes","")]
        def rows():return self._rows(self.session.rpc("LIST_QUOTES"),8)
        def add():self.form("Nueva cotización",fields,lambda v:(self.session.rpc("SAVE_QUOTE",v["customer"],v["description"],v["amount"],v["status"],v["valid_until"],v["notes"]),self.show_quotes()))
        self.list_page("Cotizaciones",rows,lambda r:f"#{r[0]} · {r[1]} · {as_money(r[3])} · {r[4]}\n{r[2]} · válida hasta {r[5]}\n{r[7]}",add if ROLE_RANK[self.role]>=ROLE_RANK["Supervisor"] else None,
                       headers=["ID","Cliente","Descripción","Valor","Estado","Válida hasta","Creada","Notas"])
    def show_tasks(self):
        fields=[("Título","title",""),("Fecha límite AAAA-MM-DD","due_date",""),("Prioridad","priority","Normal","combo",["Baja","Normal","Alta","Urgente"]),("Notas","notes","")]
        def rows():return self._rows(self.session.rpc("LIST_TASKS"),7)
        def add():self.form("Nueva tarea",fields,lambda v:(self.session.rpc("SAVE_TASK",v["title"],v["due_date"],v["priority"],v["notes"]),self.show_tasks()))
        def mark(item,r):
            if r[3]!="Completada":
                ctk.CTkButton(item,text="Completar",width=100,command=lambda rid=r[0]:(self.session.rpc("TASK_DONE",rid),self.show_tasks())).pack(side="right",padx=8,pady=7)
        self.list_page("Tareas",rows,lambda r:f"#{r[0]} · {r[1]} · {r[3]} · prioridad {r[4]}\nVence: {r[2]} · {r[5]}",add,extra_actions=mark,
                       headers=["ID","Título","Vence","Estado","Prioridad","Notas","Creada"])
    def show_chat(self):
        b=self._page("Chat LAN / WLAN")
        note=ctk.CTkFrame(b,fg_color="#111d2e",corner_radius=10);note.pack(fill="x",pady=(0,8))
        ctk.CTkLabel(note,text=("Chat general: permanente, no se puede borrar ni archivar.  En Chats privados eliges a la persona (jefe, supervisor, compañero…) y solo ustedes dos ven la conversación; puede archivarse, nunca borrarse." if self.username==self.boss else "Chat general: permanente, no se puede borrar ni archivar.  En Chats privados eliges con quién hablar; solo ustedes dos ven la conversación y puedes archivarla, sin borrar mensajes."),wraplength=950,justify="left").pack(anchor="w",padx=14,pady=9)
        tabs=ctk.CTkTabview(b);tabs.pack(fill="both",expand=True)
        pub_name="Chat general"; priv_name="Chats privados"
        tabs.add(pub_name); tabs.add(priv_name); pub=tabs.tab(pub_name); priv=tabs.tab(priv_name)
        self._build_public_chat(pub);self._build_private_chat(priv)
    def _build_public_chat(self, parent):
        self.public_panel=ctk.CTkScrollableFrame(parent,fg_color="#111d2e",corner_radius=10);self.public_panel.pack(fill="both",expand=True,pady=(0,8))
        entryrow=ctk.CTkFrame(parent,fg_color="transparent");entryrow.pack(fill="x")
        self.public_entry=ctk.CTkEntry(entryrow,placeholder_text="Escribe un mensaje para toda la empresa…",height=40);self.public_entry.pack(side="left",fill="x",expand=True,padx=(0,8));self.public_entry.bind("<Return>",lambda _e:self.send_public())
        ctk.CTkButton(entryrow,text="Enviar",width=100,command=self.send_public).pack(side="right")
        self.public_last=0;self.public_labels=[];self.refresh_public(initial=True)
    def _add_chat_card(self,panel,row,private=False):
        if private: mid,sender,recipient,body,created=row
        else: mid,sender,body,created=row
        card=ctk.CTkFrame(panel,fg_color="#1a2940",corner_radius=8);card.pack(fill="x",padx=5,pady=4)
        title=f"{sender} · {created}"+(f" → {recipient}" if private and sender==self.username else "")
        ctk.CTkLabel(card,text=title,text_color="#8bf5a2",font=ctk.CTkFont(size=12,weight="bold"),anchor="w").pack(fill="x",padx=10,pady=(7,0))
        ctk.CTkLabel(card,text=body,justify="left",anchor="w",wraplength=880).pack(fill="x",padx=10,pady=(3,8))
        return card
    def refresh_public(self,initial=False):
        if not hasattr(self,"public_panel") or self.current_page!="Chat LAN/WLAN":return
        try:
            rows=self._rows(self.session.rpc("CHAT_PUBLIC",0 if initial else self.public_last),4)
            if initial:
                for r in rows[-120:]:
                    self._add_chat_card(self.public_panel,r)
                if rows: self.public_last=max(int(r[0]) for r in rows)
            else:
                for r in rows:
                    if int(r[0])>self.public_last:self._add_chat_card(self.public_panel,r);self.public_last=int(r[0])
            kids=self.public_panel.winfo_children()
            for w in kids[:-250]:w.destroy()
            if rows:self.public_panel._parent_canvas.yview_moveto(1.0)
        except Exception as exc:self._set_status(f"Chat: {exc}")
    def send_public(self):
        body=self.public_entry.get().strip()
        if not body:return
        try:self.session.rpc("CHAT_SEND_PUBLIC",body);self.public_entry.delete(0,"end");self.refresh_public()
        except Exception as exc:messagebox.showerror("Chat",str(exc),parent=self)
    def _build_private_chat(self,parent):
        toolbar=ctk.CTkFrame(parent,fg_color="#111d2e",corner_radius=10);toolbar.pack(fill="x",pady=(0,8))
        peers=self._rows(self.session.rpc("LIST_PEERS"),3);self.peer_roles={r[0]:r[1] for r in peers}
        active=[r[0] for r in peers if r[2]=="1"]
        self.peer_var=tk.StringVar(master=self,value=active[0] if active else "");opts=active
        ctk.CTkLabel(toolbar,text="Chat con:").pack(side="left",padx=(10,4),pady=8)
        self.peer_box=ctk.CTkComboBox(toolbar,values=opts,variable=self.peer_var,width=210,command=lambda _v:self.load_private(reset=True));self.peer_box.pack(side="left",padx=4,pady=8)
        self.archive_toggle=ctk.CTkButton(toolbar,text="Ver archivados",width=120,command=self.toggle_archived);self.archive_toggle.pack(side="left",padx=5,pady=8)
        self.archive_btn=ctk.CTkButton(toolbar,text="Archivar conversación",width=170,command=self.archive_current);self.archive_btn.pack(side="left",padx=5,pady=8)
        self.private_panel=ctk.CTkScrollableFrame(parent,fg_color="#111d2e",corner_radius=10);self.private_panel.pack(fill="both",expand=True,pady=(0,8))
        row=ctk.CTkFrame(parent,fg_color="transparent");row.pack(fill="x")
        self.private_entry=ctk.CTkEntry(row,placeholder_text="Mensaje privado…",height=40);self.private_entry.pack(side="left",fill="x",expand=True,padx=(0,8));self.private_entry.bind("<Return>",lambda _e:self.send_private())
        ctk.CTkButton(row,text="Enviar privado",width=130,command=self.send_private).pack(side="right")
        self.private_last={}; self._private_status_peer=None; self._private_status=False; self.load_private(reset=True)
    def toggle_archived(self):
        self.show_archived=not self.show_archived
        self.archive_toggle.configure(text="Ver activos" if self.show_archived else "Ver archivados")
        self.rebuild_peers()
    def rebuild_peers(self):
        peers=self._rows(self.session.rpc("LIST_PEERS"),3); valid=[]
        for r in peers:
            if r[2]!="1":continue
            archived=self.session.rpc("PRIVATE_STATUS",r[0])[0]=="1"
            if archived==self.show_archived:valid.append(r[0])
        self.peer_box.configure(values=valid)
        if self.peer_var.get() not in valid:self.peer_var.set(valid[0] if valid else "")
        self.load_private(reset=True)
    def load_private(self,reset=False):
        if not hasattr(self,"private_panel") or self.current_page!="Chat LAN/WLAN":return
        peer=self.peer_var.get().strip()
        if not peer:
            for w in self.private_panel.winfo_children():w.destroy()
            self._set_status("No hay conversaciones en esta vista.");return
        try:
            # El estado archivado solo cambia por acciones de este usuario: se consulta al reiniciar la vista.
            if reset or self._private_status_peer!=peer:
                self._private_status=self.session.rpc("PRIVATE_STATUS",peer)[0]=="1"; self._private_status_peer=peer
            status=self._private_status
            if status!=self.show_archived:
                for w in self.private_panel.winfo_children():w.destroy()
                self.archive_btn.configure(text="Restaurar conversación" if status else "Archivar conversación")
                return
            self.archive_btn.configure(text="Restaurar conversación" if status else "Archivar conversación")
            if reset:
                for w in self.private_panel.winfo_children():w.destroy()
                self.private_last[peer]=0
                rows=self._rows(self.session.rpc("CHAT_PRIVATE",peer,0),5)
            else:
                rows=self._rows(self.session.rpc("CHAT_PRIVATE",peer,self.private_last.get(peer,0)),5)
            for r in rows:
                self._add_chat_card(self.private_panel,r,private=True);self.private_last[peer]=max(self.private_last.get(peer,0),int(r[0]))
            kids=self.private_panel.winfo_children()
            for w in kids[:-250]:w.destroy()
            if rows:self.private_panel._parent_canvas.yview_moveto(1.0)
        except Exception as exc:self._set_status(f"Privado: {exc}")
    def send_private(self):
        peer=self.peer_var.get().strip();body=self.private_entry.get().strip()
        if not peer:messagebox.showinfo("Privado","No hay una conversación disponible.",parent=self);return
        if not body:return
        try:self.session.rpc("CHAT_SEND_PRIVATE",peer,body);self.private_entry.delete(0,"end");self.load_private()
        except Exception as exc:messagebox.showerror("Privado",str(exc),parent=self)
    def archive_current(self):
        peer=self.peer_var.get().strip()
        if not peer:return
        try:
            status=self.session.rpc("PRIVATE_STATUS",peer)[0]=="1"
            self.session.rpc("ARCHIVE_PRIVATE",peer,"0" if status else "1")
            self.rebuild_peers()
        except Exception as exc:messagebox.showerror("Privado",str(exc),parent=self)
    def show_users(self):
        b=self._page("Usuarios y jerarquía")
        top=ctk.CTkFrame(b,fg_color="#111d2e",corner_radius=10);top.pack(fill="x",pady=(0,8))
        ctk.CTkButton(top,text="＋ Crear usuario",command=self.create_user).pack(side="left",padx=10,pady=8)
        ctk.CTkButton(top,text="Cambiar mi contraseña",command=self.change_password).pack(side="left",pady=8)
        scroll=ctk.CTkScrollableFrame(b,fg_color="#111d2e",corner_radius=10);scroll.pack(fill="both",expand=True)
        for r in self._rows(self.session.rpc("LIST_USERS"),4):
            card=ctk.CTkFrame(scroll,fg_color="#1a2940",corner_radius=8);card.pack(fill="x",padx=6,pady=4)
            ctk.CTkLabel(card,text=f"{r[0]} · {r[1]} · {'Activo' if r[2]=='1' else 'Desactivado'} · desde {r[3]}",anchor="w").pack(side="left",fill="x",expand=True,padx=12,pady=10)
            if r[0]!=self.username and ROLE_RANK[self.role]>ROLE_RANK.get(r[1],0):
                ctk.CTkButton(card,text="Activar" if r[2]!="1" else "Desactivar",width=100,command=lambda name=r[0],active=r[2]:(self.session.rpc("USER_ACTIVE",name,"1" if active!="1" else "0"),self.show_users())).pack(side="right",padx=8,pady=6)
                ctk.CTkButton(card,text="Restablecer clave",width=125,command=lambda name=r[0]:self.reset_password(name)).pack(side="right",padx=4,pady=6)
        ctk.CTkLabel(b,text="Jerarquía: Jefe > Administrador > Supervisor > Empleado. No se pueden crear usuarios del mismo rango o superior.",wraplength=950,text_color="#a7b5c9").pack(anchor="w",pady=6)
    def create_user(self):
        options=[r for r in ("Administrador","Supervisor","Empleado") if ROLE_RANK[r] < ROLE_RANK[self.role]]
        fields=[("Nombre de usuario","username",""),("Rol","role",options[0],"combo",options),("Contraseña inicial (10+ caracteres)","password","")]
        def save(v):self.session.rpc("CREATE_USER",v["username"],v["role"],v["password"]);self.show_users()
        self.form("Crear usuario",fields,save)
    def reset_password(self,username):
        self.form(f"Restablecer contraseña: {username}",[("Nueva contraseña (10+ caracteres)","password","")],lambda v:(self.session.rpc("RESET_PASSWORD",username,v["password"]),messagebox.showinfo("Usuarios","Contraseña restablecida.",parent=self)))
    def change_password(self):
        self.form("Cambiar mi contraseña",[("Contraseña actual","old",""),("Nueva contraseña (10+ caracteres)","new","")],lambda v:(self.session.rpc("CHANGE_PASSWORD",v["old"],v["new"]),messagebox.showinfo("Seguridad","Contraseña actualizada.",parent=self)))
    def show_activity(self):
        self.list_page("Auditoría de actividad",lambda:self._rows(self.session.rpc("LIST_ACTIVITY"),5),
                       lambda r:f"{r[4]} · {r[1]} · {r[2]}\n{r[3]}",page_name="Auditoría",headers=["ID","Usuario","Acción","Detalle","Fecha"])
        ctk.CTkLabel(self.page,text="El jefe puede revisar eventos registrados por la app: inicios de sesión, cambios de datos y acciones de chat. No es un monitor de pantalla ni registra teclas.",wraplength=980,justify="left",text_color="#a7b5c9").pack(anchor="w",padx=18,pady=(0,10))
    def show_bridger_plans(self):
        b=self._page("Planes ZYH Bridger")
        cur=bridger_plan_get()
        top=ctk.CTkFrame(b,corner_radius=12,fg_color="#111d2e"); top.pack(fill="x",pady=(0,10))
        if cur and cur.get("days"):
            name=next((x["name"] for x in BRIDGER_PLANS if x["id"]==cur["plan"]),cur["plan"])
            ctk.CTkLabel(top,text=f"Plan activo: {name}",font=ctk.CTkFont(size=17,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=16,pady=(12,2))
            self.bp_cd=ctk.CTkLabel(top,text="",font=ctk.CTkFont(size=24,weight="bold"),text_color="#e6f0fa"); self.bp_cd.pack(anchor="w",padx=16)
            self.bp_bar=ctk.CTkProgressBar(top,height=10); self.bp_bar.pack(fill="x",padx=16,pady=(6,4))
            self.bp_info=ctk.CTkLabel(top,text="",text_color="#a7b5c9"); self.bp_info.pack(anchor="w",padx=16,pady=(0,12))
            self._bp_tick(cur)
        else:
            ctk.CTkLabel(top,text="Sin plan activo. El jefe registra el pago de un plan para empezar la cuenta regresiva.",text_color="#a7b5c9",wraplength=820).pack(anchor="w",padx=16,pady=14)
        cards=ctk.CTkFrame(b,fg_color="transparent"); cards.pack(fill="both",expand=True)
        is_boss=ROLE_RANK[self.role]>=ROLE_RANK["Jefe"]
        for i,pl in enumerate(BRIDGER_PLANS):
            cards.grid_columnconfigure(i,weight=1)
            card=ctk.CTkFrame(cards,corner_radius=12,fg_color="#172235"); card.grid(row=0,column=i,sticky="nsew",padx=6,pady=6)
            ctk.CTkLabel(card,text=pl["name"],font=ctk.CTkFont(size=20,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=14,pady=(14,2))
            ctk.CTkLabel(card,text=pl["price"],font=ctk.CTkFont(size=16,weight="bold"),text_color="#e6f0fa").pack(anchor="w",padx=14)
            ctk.CTkLabel(card,text=f"Hasta {pl['guests']} invitados por sala",text_color="#b6c4d8").pack(anchor="w",padx=14,pady=(2,8))
            ctk.CTkLabel(card,text="\n".join("• "+f for f in pl["features"]),justify="left",wraplength=260,text_color="#a7b5c9").pack(anchor="w",padx=14,pady=4)
            if is_boss and pl["days"]>0:
                ctk.CTkButton(card,text="Registrar pago de este plan",height=34,command=lambda pid=pl["id"]:self.bridger_register(pid)).pack(fill="x",padx=14,pady=(12,14))
    def _bp_tick(self,cur):
        try:
            if not self.bp_cd.winfo_exists(): return
            left,total,end=bridger_remaining(cur)
            self.bp_cd.configure(text=("Plan finalizado" if left<=0 else "Quedan "+fmt_countdown(left)))
            self.bp_bar.set(min(1.0,max(0.0,1-left/total)))
            self.bp_info.configure(text=f"Pago registrado: {cur['paid_at']} · Termina: {end:%Y-%m-%d %H:%M}")
            if left>0: self.after(1000,lambda:self._bp_tick(cur))
        except Exception: return
    def bridger_register(self,pid):
        pl=next(x for x in BRIDGER_PLANS if x["id"]==pid)
        if not messagebox.askyesno("Registrar pago",f"Registrar el pago del plan {pl['name']} ({pl['price']}) desde hoy, por {pl['days']} días?\n\nSolo registra un pago que ya recibiste.",parent=self): return
        bridger_plan_set(pid,pl["days"],now())
        self.show_page("Planes ZYH Bridger")
    # ------------------------------------------------ Planes de ZYH Business
    def _zyh_account_row(self,parent):
        """Entrar con la cuenta ZYH: así se activa aquí el plan comprado en la web."""
        row=ctk.CTkFrame(parent,fg_color="transparent"); row.pack(fill="x",padx=16,pady=(0,12))
        try:
            import zyh_account_ui as AU
            u=AU.current_username()
        except Exception as exc:
            ctk.CTkLabel(row,text=f"Cuenta ZYH no disponible: {exc}",text_color="#a7b5c9").pack(anchor="w"); return
        ctk.CTkLabel(row,text=(f"Cuenta ZYH: {u}" if u else "Sin cuenta ZYH en este equipo"),text_color="#8bf5a2" if u else "#a7b5c9").pack(side="left",padx=(0,10))
        def open_acc():
            AU.open_dialog(self,"business",on_done=lambda:self.after(100,lambda:self.show_page("Planes")))
        ctk.CTkButton(row,text="Mi cuenta ZYH" if u else "Entrar con cuenta ZYH",height=32,command=open_acc).pack(side="left")

    def show_business_plans(self):
        b=self._page("Planes ZYH Business")
        ent=_zyh_guard.require("business") if _zyh_guard else None
        top=ctk.CTkFrame(b,corner_radius=12,fg_color="#111d2e"); top.pack(fill="x",pady=(0,10))
        if getattr(self,"_no_plan_notice",False) and not ent:
            ctk.CTkLabel(top,text="Necesitas un plan activo para usar esa sección.",text_color="#ffb86b",font=ctk.CTkFont(size=14,weight="bold")).pack(anchor="w",padx=16,pady=(12,0))
        self._no_plan_notice=False
        if ent:
            ctk.CTkLabel(top,text=f"Plan activo: {ent.label}",font=ctk.CTkFont(size=17,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=16,pady=(12,2))
            devs=ent.devices if ent.devices<900 else "ilimitados"
            ctk.CTkLabel(top,text=f"Quedan {ent.days_left} días · hasta {devs} dispositivos",font=ctk.CTkFont(size=22,weight="bold"),text_color="#e6f0fa").pack(anchor="w",padx=16,pady=(0,12))
        else:
            ctk.CTkLabel(top,text="Sin plan activo. Paga tu plan por PayPal; se activa en este equipo cuando ZYH Studios verifique el pago.",text_color="#a7b5c9",wraplength=820).pack(anchor="w",padx=16,pady=14)
        self._zyh_account_row(top)
        cards=ctk.CTkFrame(b,fg_color="transparent"); cards.pack(fill="both",expand=True)
        feats={"pro":["Gestión completa","IA de WhatsApp básica (80 msj/día)","De 1 a 4 dispositivos"],
               "vpro":["Todo lo de Pro","IA de WhatsApp completa","De 5 a 9 dispositivos"],
               "vpro_plus":["Todo lo de V-Pro","Soporte prioritario","10 o más dispositivos"]}
        for i,pl in enumerate(_zyh_guard.plan_catalog("business") if _zyh_guard else []):
            cards.grid_columnconfigure(i,weight=1)
            card=ctk.CTkFrame(cards,corner_radius=12,fg_color="#172235"); card.grid(row=0,column=i,sticky="nsew",padx=6,pady=6)
            ctk.CTkLabel(card,text=pl["label"],font=ctk.CTkFont(size=20,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=14,pady=(14,2))
            ctk.CTkLabel(card,text=f"US${pl['usd']} / mes",font=ctk.CTkFont(size=16,weight="bold"),text_color="#e6f0fa").pack(anchor="w",padx=14)
            ctk.CTkLabel(card,text=f"Dispositivo extra: US${pl['extra_usd']:.0f}",text_color="#b6c4d8").pack(anchor="w",padx=14,pady=(2,8))
            ctk.CTkLabel(card,text="\n".join("• "+f for f in feats.get(pl["id"],[])),justify="left",wraplength=260,text_color="#a7b5c9").pack(anchor="w",padx=14,pady=4)
            ctk.CTkButton(card,text="Pagar con PayPal",height=34,command=lambda p=pl:messagebox.showinfo("Pagar plan",f"Plan {p['label']} (US${p['usd']}/mes).\n\nPaga con PayPal en la web de ZyhStudios (sección Productos).\nTu plan se activa en tu cuenta ZYH y en este equipo cuando se verifique el pago.",parent=self)).pack(fill="x",padx=14,pady=(12,14))

    # ------------------------------------------------ IA de WhatsApp (API oficial)
    def _ai_cfg_path(self): return str(DATA_DIR/"ia_whatsapp.zyhd")
    def _ai_load(self):
        d={"business_name":"","token":"","phone_number_id":"","verify_token":"zyh","app_secret":"","gemini_key":"","model":"gemini-3.6-flash","port":8088,"nequi_numero":"","nequi_nombre":"","banco_nombre":"","banco_tipo":"","banco_numero":"","banco_titular":"","pago_nota":""}
        try:
            from zyhcore import store
            d.update(store.load(self._ai_cfg_path(),{}) or {})
        except Exception: pass
        return d
    def _ai_save(self,d):
        try:
            from zyhcore import store
            store.save(self._ai_cfg_path(),d)
        except Exception as exc: messagebox.showerror("IA WhatsApp",f"No se pudo guardar: {exc}",parent=self)

    # ------------------------------------------------ tipos de negocio y extensiones (IA)
    def L(self,t): return zyh_ext.label(getattr(self,"ext",None),t)
    def ext_cats(self): return (getattr(self,"ext",None) or {}).get("expense_cats") or zyh_ext.DEFAULT_CATS
    def _apply_type(self,name,ask_tasks=True):
        types=zyh_ext.all_types(DATA_DIR); spec=types.get(name)
        if not spec: return
        zyh_ext.set_active(DATA_DIR,name); self.ext=spec
        for k,btn in getattr(self,"_nav_btns",{}).items():
            try:btn.configure(text=self.L(k))
            except Exception:pass
        if ask_tasks and spec.get("tasks") and messagebox.askyesno("Tipo de negocio",f"Aplicado: {name}.\n\n¿Crear las {len(spec['tasks'])} tareas iniciales sugeridas?",parent=self):
            for t in spec["tasks"]:
                try:self.session.rpc("SAVE_TASK",t,"","Normal","")
                except Exception:pass
        self.show_business_type()
    def show_business_type(self):
        b=self._page("Tipo de negocio")
        box=ctk.CTkFrame(b,corner_radius=12,fg_color="#111d2e"); box.pack(fill="x",pady=(0,10))
        ctk.CTkLabel(box,text="Adapta ZYH Business a tu negocio: cambia los nombres del menú, las categorías de gastos y cómo la IA atiende a tus clientes.",text_color="#a7b5c9",wraplength=820,justify="left").pack(anchor="w",padx=16,pady=(12,4))
        ctk.CTkLabel(box,text=f"Tipo actual: {self.ext['name']}",font=ctk.CTkFont(size=16,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=16,pady=(4,6))
        names=list(zyh_ext.all_types(DATA_DIR).keys()); var=tk.StringVar(master=self,value=self.ext["name"])
        row=ctk.CTkFrame(box,fg_color="transparent"); row.pack(fill="x",padx=12,pady=(0,12))
        ctk.CTkComboBox(row,values=names,variable=var,width=300).pack(side="left",padx=4)
        self._button(row,"Aplicar",lambda:self._apply_type(var.get())).pack(side="left",padx=4)
        def import_ext():
            p=filedialog.askopenfilename(parent=self,filetypes=[("Extensión ZYH","*.zyhx"),("JSON","*.json")])
            if not p:return
            try:
                spec=zyh_ext.install(DATA_DIR,json.load(open(p,encoding="utf-8")))
                messagebox.showinfo("Extensión",f"Instalada: {spec['name']}",parent=self); self.show_business_type()
            except Exception as exc: messagebox.showerror("Extensión",str(exc),parent=self)
        self._button(row,"Importar extensión…",import_ext,color="#52647a").pack(side="left",padx=4)
        ia=ctk.CTkFrame(b,corner_radius=12,fg_color="#111d2e"); ia.pack(fill="x",pady=(0,10))
        ctk.CTkLabel(ia,text="¿Tu negocio no está en la lista?",font=ctk.CTkFont(size=16,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=16,pady=(12,2))
        ctk.CTkLabel(ia,text="Descríbelo y la IA crea una extensión que convierte el programa a ese negocio (ej.: \"veterinaria con peluquería canina y venta de alimento\"). Necesita la clave de Gemini de la sección IA WhatsApp. La extensión es solo configuración: no puede ejecutar código ni tocar tus datos.",text_color="#a7b5c9",wraplength=820,justify="left").pack(anchor="w",padx=16,pady=(0,6))
        desc=ctk.CTkTextbox(ia,height=70); desc.pack(fill="x",padx=16)
        st=ctk.CTkLabel(ia,text="",text_color="#e6f0fa",wraplength=820,justify="left"); st.pack(anchor="w",padx=16,pady=6)
        def go():
            text=desc.get("1.0","end-1c").strip()
            if not text: st.configure(text="Describe tu negocio primero."); return
            key=self._ai_load().get("gemini_key","")
            st.configure(text="La IA está creando tu extensión…"); btn.configure(state="disabled")
            def work():
                try: res=zyh_ext.generate(text,key); err=None
                except Exception as exc: res=None; err=str(exc)
                self._ui_queue.put(lambda:done(res,err))     # los hilos no tocan Tk
            def done(res,err):
                btn.configure(state="normal")
                if err: st.configure(text="No se pudo crear: "+err); return
                spec,basic=res
                prev=f"{spec['name']}\n\nMenú: "+(", ".join(f"{k} → {v}" for k,v in spec["labels"].items()) or "sin cambios")+"\nGastos: "+", ".join(spec["expense_cats"])+("\nTareas: "+"; ".join(spec["tasks"]) if spec["tasks"] else "")
                if basic: prev+="\n\n(Sin clave de Gemini se creó una plantilla básica; con la clave la IA personaliza todo.)"
                if messagebox.askyesno("Instalar extensión",prev+"\n\n¿Instalarla y aplicarla?",parent=self):
                    zyh_ext.install(DATA_DIR,spec); self._apply_type(spec["name"])
                else: st.configure(text="No se instaló.")
            threading.Thread(target=work,daemon=True).start()
        btn=self._button(ia,"Crear extensión con IA",go,color="#7c3aed"); btn.pack(anchor="w",padx=16,pady=(0,14))

    # ------------------------------------------------ lector de códigos de barras (USB o cámara)
    def _sku_find(self,code):
        c=str(code).strip().lower()
        for p in self._rows(self.session.rpc("LIST_PRODUCTS"),8):
            if str(p[1]).strip().lower()==c: return p
        return None
    def _can_register(self): return ROLE_RANK[self.role]>=ROLE_RANK["Supervisor"]
    def _register_new(self,code):
        fields=[("SKU / código de barras","sku",code),("Nombre","name",""),("Cantidad","quantity","1"),("Stock mínimo","minimum","0"),("Costo unitario","cost","0"),("Precio de venta","price","0"),("Notas","notes","")]
        def save(v):
            self.session.rpc("SAVE_PRODUCT","",v["sku"],v["name"],v["quantity"],v["minimum"],v["cost"],v["price"],v["notes"])
            if self.current_page=="Inventario": self.show_products()
        self.form("Registrar producto nuevo",fields,save)
    def _notify_new_code(self,code):
        """Avisa por chat privado a quienes pueden registrar productos (Supervisor o más)."""
        sent=getattr(self,"_notified_codes",None)
        if sent is None: sent=self._notified_codes={}
        if code in sent: return sent[code]
        targets=[r[0] for r in self._rows(self.session.rpc("LIST_PEERS"),3) if r[2]=="1" and ROLE_RANK.get(r[1],0)>=ROLE_RANK["Supervisor"]]
        ok=[]
        for t in targets:
            try:
                self.session.rpc("CHAT_SEND_PRIVATE",t,f"📦 Producto nuevo sin registrar: código {code}. Lo escaneó {self.username}. Por favor regístralo en Inventario."); ok.append(t)
            except Exception: pass
        sent[code]=ok; return ok
    def _unknown_code(self,code,dlg):
        if self._can_register():
            if messagebox.askyesno("Producto nuevo",f"El código {code} no está registrado.\n\n¿Registrarlo ahora?",parent=dlg):
                self._register_new(code); return f"Registrando el código {code}…"
            return f"Código {code} sin registrar."
        ok=self._notify_new_code(code)
        return f"⚠ Producto nuevo (código {code}). "+(f"Avisé a {', '.join(ok)} para que lo registre." if ok else "No encontré a un encargado: avisa a tu supervisor para que lo registre.")
    def scan_inventory(self):
        def on_code(code):
            p=self._sku_find(code)
            if p: return f"✔ {p[2]}\nSKU {p[1]} · existencias {p[3]} · precio {as_money(p[6])}"
            return self._unknown_code(code,dlg)
        dlg=barcode_scan.ScanDialog(self,"Escanear producto",on_code,hint="Escanea un producto: si existe verás su stock y precio; si es nuevo se avisa al encargado para que lo registre.")
    def scan_sale(self):
        cart={}
        def text():
            if not cart: return "Carrito vacío."
            tot=sum(v[1]*v[2] for v in cart.values())
            return "\n".join(f"{v[1]} × {v[0]}  =  {as_money(v[1]*v[2])}" for v in cart.values())+f"\n\nTOTAL  {as_money(tot)}"
        def on_code(code):
            p=self._sku_find(code)
            if not p: return self._unknown_code(code,dlg)+"\n\n"+text()
            v=cart.get(p[0],[p[2],0,float(p[6]),int(p[3])])
            if v[1]+1>v[3]: return f"✖ Sin stock suficiente de {p[2]} (hay {v[3]}).\n\n"+text()
            v[1]+=1; cart[p[0]]=v; return f"✔ {p[2]} agregado\n\n"+text()
        def pay(d):
            if not cart: return
            done=[]
            try:
                for pid,v in list(cart.items()):
                    self.session.rpc("CREATE_SALE","",pid,str(v[1]),"Venta escaneada"); done.append(pid)
            except Exception as exc: messagebox.showerror("Venta",str(exc),parent=d)
            for pid in done: cart.pop(pid,None)
            if cart: d.set_info("Quedaron sin cobrar:\n\n"+text())
            else: d.close(); self.show_sales()
        def clear(d): cart.clear(); d.set_info(text())
        dlg=barcode_scan.ScanDialog(self,"Vender escaneando",on_code,buttons=[("Cobrar",pay),("Vaciar",clear)],hint="Escanea cada producto para armar la venta y pulsa Cobrar.")
    # ---- motor de la IA (corre en el equipo que la enciende)
    def _ai_products(self):
        return [{"id":p[0],"name":p[2],"quantity":p[3],"price":p[6]} for p in self._rows(self.session.rpc("LIST_PRODUCTS"),8)]
    def _ai_order(self,phone,pid,qty):
        r=self.session.rpc("AI_ORDER_ADD",phone,str(pid),str(qty))       # el servidor confirma el stock
        if r[0]=="OK": return {"ok":True,"id":r[1],"name":r[2],"qty":int(r[3]),"total":r[4]}
        return {"ok":False,"available":int(r[1]),"name":r[2]}
    def _ai_pay_text(self,cfg):
        lines=[]
        if cfg.get("nequi_numero"): lines.append(f"• Nequi: {cfg['nequi_numero']}"+(f" ({cfg['nequi_nombre']})" if cfg.get("nequi_nombre") else ""))
        if cfg.get("banco_numero"): lines.append(f"• {cfg.get('banco_nombre','Banco')} {cfg.get('banco_tipo','')} N.º {cfg['banco_numero']}".replace("  "," ")+(f" — {cfg['banco_titular']}" if cfg.get("banco_titular") else ""))
        if not lines: return "Un encargado te escribe enseguida con los datos de pago."
        return "Puedes pagar por:\n"+"\n".join(lines)+(("\n"+cfg["pago_nota"]) if cfg.get("pago_nota") else "")+"\n\nEnvíame el comprobante por aquí. ¡Gracias!"
    def _ai_decision_text(self,o,cfg):
        oid,phone,name,qty,total,status,_c,_by,note=o[:9]
        if status=="aprobado": return f"✅ ¡Tu compra fue aprobada!\n{qty} × {name} = {as_money(total)}\n\n"+self._ai_pay_text(cfg)
        if status=="sin_stock": return f"Lo siento, {name} se agotó antes de confirmar tu pedido 😕 ({note}). ¿Te muestro algo parecido?"
        return f"Lo siento, no pudimos aprobar tu pedido de {qty} × {name}."+(f" Motivo: {note}" if note else "")+" Si quieres, te ayudo con otra opción."
    def _ai_send_decisions(self,cfg,wcfg):
        import whatsapp
        for o in self._rows(self.session.rpc("AI_ORDERS","porenviar"),11):
            text=self._ai_decision_text(o,cfg); ok,detail=whatsapp.send_message(wcfg,o[1],text)
            if ok and getattr(self,"_ai_brain",None): self._ai_brain._log(o[1],"assistant",text)
            self.session.rpc("AI_ORDER_SENT",o[0],"1" if ok else "2","enviado" if ok else detail)
    def _ai_loop(self,httpd,cfg,wcfg):
        """Hilo de la IA: envía decisiones de pedidos y se entrena tras 1 minuto sin mensajes."""
        while getattr(self,"_ai_httpd",None) is httpd:
            try: self._ai_send_decisions(cfg,wcfg)
            except Exception as exc: self._ai_brain.last_error=f"envío: {exc}"
            try:
                if self._ai_brain.should_train(): self._ai_brain.learn_idle()
            except Exception as exc: self._ai_brain.last_error=f"entrenamiento: {exc}"
            time.sleep(2)
    def _ai_stop(self):
        h=getattr(self,"_ai_httpd",None); self._ai_httpd=None
        if h:
            try:h.shutdown();h.server_close()
            except Exception:pass
    def _ai_start(self,cfg):
        import zyh_ai, whatsapp
        ent=_zyh_guard.require("business") if _zyh_guard else None
        if not ent: self.show_page("Planes"); return "Necesitas un plan activo."
        if ROLE_RANK[self.role]<ROLE_RANK["Supervisor"]: return "Solo un Supervisor o superior puede encender la IA."
        if not cfg.get("token") or not cfg.get("phone_number_id"): return "Falta el token o el Phone number ID de WhatsApp."
        limit=80 if ent.plan=="pro" else 100000
        self._ai_brain=zyh_ai.Brain(DATA_DIR,self._ai_products,self._ai_order,cfg["business_name"] or "mi negocio",cfg["gemini_key"],limit,
                                    context=zyh_ext.ai_context(self.ext),model=cfg.get("model") or zyh_ai.DEFAULT_MODEL)
        wcfg=whatsapp.Config(cfg["token"],cfg["phone_number_id"],cfg["verify_token"],cfg["business_name"],cfg["gemini_key"],cfg.get("app_secret",""))
        try: httpd=whatsapp.serve(wcfg,self._ai_brain.reply,port=int(cfg.get("port",8088) or 8088))
        except Exception as exc: return f"No se pudo abrir el puerto: {exc}"
        self._ai_httpd=httpd
        threading.Thread(target=httpd.serve_forever,daemon=True).start()
        threading.Thread(target=self._ai_loop,args=(httpd,dict(cfg),wcfg),daemon=True).start()
        return ""
    def show_ai(self):
        import zyh_ai
        b=self._page("IA de atención por WhatsApp")
        cfg=self._ai_load(); can=ROLE_RANK[self.role]>=ROLE_RANK["Supervisor"]
        tabs=ctk.CTkTabview(b); tabs.pack(fill="both",expand=True)
        t_con,t_pay,t_ord,t_learn=(ctk.CTkScrollableFrame(tabs.add(n),fg_color="transparent") for n in ("Conexión","Pagos","Pedidos","Aprendizaje"))
        for t in (t_con,t_pay,t_ord,t_learn): t.pack(fill="both",expand=True)
        ents={}
        def field(parent,key,label,show=None):
            ctk.CTkLabel(parent,text=label,text_color="#e6f0fa").pack(anchor="w",padx=12,pady=(6,0))
            e=ctk.CTkEntry(parent,show=show,height=32); e.pack(fill="x",padx=12); e.insert(0,str(cfg.get(key,""))); ents[key]=e
        def save():
            for k,e in ents.items(): cfg[k]=e.get().strip()
            self._ai_save(cfg); st.configure(text="Configuración guardada (cifrada en este equipo).")
        # ---- Conexión
        ctk.CTkLabel(t_con,text="La IA atiende sola por WhatsApp Business (API oficial): responde con tu stock y precio reales, entiende imágenes, anota pedidos solo si hay existencias y avisa a los encargados para que aprueben la compra.",text_color="#a7b5c9",wraplength=820,justify="left").pack(anchor="w",padx=12,pady=(8,4))
        for key,label,show in [("business_name","Nombre del negocio",None),("token","Token de WhatsApp Business (API oficial)","•"),("phone_number_id","Phone number ID",None),("verify_token","Verify token (lo inventas tú)",None),("app_secret","App secret de Meta (recomendado: comprueba que el mensaje viene de Meta)","•"),("gemini_key","Clave de Google Gemini (IA e imágenes)","•"),("model","Modelo de Gemini",None),("port","Puerto del webhook",None)]:
            field(t_con,key,label,show)
        st=ctk.CTkLabel(t_con,text="",text_color="#8bf5a2",wraplength=820,justify="left"); st.pack(anchor="w",padx=12,pady=(8,4))
        row=ctk.CTkFrame(t_con,fg_color="transparent"); row.pack(fill="x",padx=8,pady=(0,12))
        def toggle():
            if getattr(self,"_ai_httpd",None):
                self._ai_stop(); btn.configure(text="Encender IA"); st.configure(text="IA apagada"); return
            save(); err=self._ai_start(cfg)
            if err: st.configure(text=err); return
            btn.configure(text="Apagar IA")
        self._button(row,"Guardar",save).pack(side="left",padx=4)
        btn=self._button(row,"Apagar IA" if getattr(self,"_ai_httpd",None) else "Encender IA",toggle,"#16a34a"); btn.pack(side="left",padx=4)
        if not can: btn.configure(state="disabled")
        # ---- Pagos
        ctk.CTkLabel(t_pay,text="Estos datos se envían al cliente SOLO cuando un encargado aprueba su compra.",text_color="#a7b5c9",wraplength=820,justify="left").pack(anchor="w",padx=12,pady=(8,4))
        for key,label in [("nequi_numero","Nequi · número"),("nequi_nombre","Nequi · a nombre de"),("banco_nombre","Banco · nombre del banco"),("banco_tipo","Banco · tipo de cuenta (ahorros / corriente)"),("banco_numero","Banco · número de cuenta"),("banco_titular","Banco · titular"),("pago_nota","Nota para el cliente (opcional)")]:
            field(t_pay,key,label)
        prev=ctk.CTkLabel(t_pay,text="",justify="left",anchor="w",wraplength=820,text_color="#e6f0fa",fg_color="#111d2e",corner_radius=10); prev.pack(fill="x",padx=12,pady=10)
        def save_pay():
            save(); prev.configure(text="Así lo verá el cliente:\n\n✅ ¡Tu compra fue aprobada!\n2 × Producto = $0.00\n\n"+self._ai_pay_text(cfg))
        self._button(t_pay,"Guardar datos de pago",save_pay).pack(anchor="w",padx=12,pady=(0,12)); prev.configure(text="Así lo verá el cliente:\n\n"+self._ai_pay_text(cfg))
        # ---- Pedidos
        NAMES={"pendiente":"⏳ Esperando aprobación","aprobado":"✅ Aprobado","rechazado":"✖ Rechazado","sin_stock":"✖ Sin stock"}
        def decide(oid,ok):
            note=""
            if not ok:
                d=ctk.CTkInputDialog(text="Motivo del rechazo (se le dice al cliente, opcional):",title="Rechazar pedido"); note=d.get_input() or ""
            try:
                r=self.session.rpc("AI_ORDER_DECIDE",oid,"1" if ok else "0",note)
                if r[0]=="SIN_STOCK": messagebox.showwarning("Pedido",f"No se aprobó: ya no hay stock suficiente (quedan {r[1]}). Se le avisará al cliente.",parent=self)
            except Exception as exc: messagebox.showerror("Pedido",str(exc),parent=self)
            load_orders()
        def load_orders():
            for w in t_ord.winfo_children(): w.destroy()
            top=ctk.CTkFrame(t_ord,fg_color="transparent"); top.pack(fill="x")
            self._button(top,"↻ Actualizar",load_orders).pack(side="left",padx=8,pady=6)
            ctk.CTkLabel(top,text="Al aprobar se vuelve a confirmar el stock, se registra la venta «Por cobrar» y la IA envía los datos de pago.",text_color="#a7b5c9",wraplength=640,justify="left").pack(side="left",padx=8)
            if not can: ctk.CTkLabel(t_ord,text="Solo los encargados (Supervisor o superior) ven y aprueban pedidos.",text_color="#a7b5c9").pack(anchor="w",padx=12,pady=12); return
            try: rows=self._rows(self.session.rpc("AI_ORDERS"),11)
            except Exception as exc: ctk.CTkLabel(t_ord,text=str(exc)).pack(anchor="w",padx=12); return
            if not rows: ctk.CTkLabel(t_ord,text="Aún no hay pedidos.",text_color="#a7b5c9").pack(anchor="w",padx=12,pady=12)
            for o in rows:
                card=ctk.CTkFrame(t_ord,fg_color="#111d2e",corner_radius=10); card.pack(fill="x",padx=8,pady=4)
                sent={"0":"" if o[5]=="pendiente" else " · aviso al cliente en cola","1":" · cliente avisado","2":f" · NO se pudo avisar al cliente ({o[10]}): escríbele tú"}.get(o[9],"")
                ctk.CTkLabel(card,text=f"Pedido #{o[0]} · +{o[1]} · {o[6]}\n{o[3]} × {o[2]} = {as_money(o[4])}\n{NAMES.get(o[5],o[5])}"+(f" por {o[7]}" if o[7] else "")+(f" · {o[8]}" if o[8] else "")+sent,justify="left",anchor="w",wraplength=600).pack(side="left",padx=12,pady=8)
                if o[5]=="pendiente":
                    self._button(card,"Rechazar",lambda i=o[0]:decide(i,False),color="#8f2d2d").pack(side="right",padx=6,pady=8)
                    self._button(card,"Aprobar compra",lambda i=o[0]:decide(i,True),color="#16a34a").pack(side="right",padx=6,pady=8)
        load_orders()
        # ---- Aprendizaje
        brain=getattr(self,"_ai_brain",None) or zyh_ai.Brain(DATA_DIR,self._ai_products)
        lst=ctk.CTkLabel(t_learn,text="",text_color="#8bf5a2",wraplength=820,justify="left"); lst.pack(anchor="w",padx=12,pady=(8,2))
        ctk.CTkLabel(t_learn,text="Se entrena sola cuando pasa más de 1 minuto sin mensajes. Si llega un mensaje, deja de entrenar y atiende con lo aprendido.",text_color="#a7b5c9",wraplength=820,justify="left").pack(anchor="w",padx=12)
        learned=ctk.CTkLabel(t_learn,text="",justify="left",anchor="w",wraplength=820,fg_color="#111d2e",corner_radius=10); learned.pack(fill="x",padx=12,pady=8)
        def refresh_learn():
            if not lst.winfo_exists(): return
            on=bool(getattr(self,"_ai_httpd",None))
            lst.configure(text=("IA encendida · " if on else "IA apagada · ")+brain.status()+(f"\nÚltimo aviso: {brain.last_error}" if brain.last_error else ""))
            learned.configure(text="Lo aprendido:\n"+(brain.knowledge() or "Todavía nada. Aparecerá aquí después de las primeras conversaciones."))
            st.configure(text=(f"IA encendida · {'con Gemini ('+brain.model+')' if brain.api_key else 'modo básico (sin clave de Gemini)'} · webhook en el puerto {cfg.get('port',8088)}") if on else st.cget("text"))
            self.after(3000,refresh_learn)
        def train_now():
            threading.Thread(target=brain.learn_idle,daemon=True).start()
        self._button(t_learn,"Entrenar ahora",train_now).pack(anchor="w",padx=12,pady=(0,8))
        ctk.CTkLabel(t_learn,text="Confianza de tus clientes",font=ctk.CTkFont(size=16,weight="bold"),text_color="#8bf5a2").pack(anchor="w",padx=12,pady=(8,4))
        rows=brain.customers()
        if not rows: ctk.CTkLabel(t_learn,text="Aún no hay conversaciones.",text_color="#a7b5c9").pack(anchor="w",padx=12,pady=(0,12))
        for c in rows[:15]:
            r=ctk.CTkFrame(t_learn,fg_color="transparent"); r.pack(fill="x",padx=12,pady=2)
            ctk.CTkLabel(r,text=(c.get("name") or "")[:18]+" +"+c["phone"],width=230,anchor="w").pack(side="left")
            pb=ctk.CTkProgressBar(r,width=220,progress_color="#8bf5a2" if c["trust"]>=50 else "#ef4444"); pb.set(c["trust"]/100); pb.pack(side="left",padx=8)
            ctk.CTkLabel(r,text=f"{c['trust']:.0f}  {c.get('notes','')[:60]}",text_color="#a7b5c9").pack(side="left")
        refresh_learn()

    def show_appearance(self):
        b=self._page("Apariencia y fondo")
        card=ctk.CTkFrame(b,fg_color="#111d2e",corner_radius=12);card.pack(fill="x",pady=6)
        ctk.CTkLabel(card,text="Tema",font=ctk.CTkFont(size=17,weight="bold")).pack(anchor="w",padx=16,pady=(13,4))
        row=ctk.CTkFrame(card,fg_color="transparent");row.pack(fill="x",padx=12,pady=6)
        ctk.CTkButton(row,text="Oscuro",command=lambda:self.set_theme("dark")).pack(side="left",padx=4)
        ctk.CTkButton(row,text="Claro",fg_color="#62748b",command=lambda:self.set_theme("light")).pack(side="left",padx=4)
        ctk.CTkButton(row,text="Azul",fg_color="#1f6aa5",command=lambda:self.set_accent("#1f6aa5")).pack(side="left",padx=4)
        ctk.CTkButton(row,text="Verde",fg_color="#26734d",command=lambda:self.set_accent("#26734d")).pack(side="left",padx=4)
        ctk.CTkButton(row,text="Elegir color",fg_color="#62748b",command=self.choose_accent).pack(side="left",padx=4)
        ctk.CTkLabel(card,text="Fondo de pantalla",font=ctk.CTkFont(size=17,weight="bold")).pack(anchor="w",padx=16,pady=(15,4))
        ctk.CTkLabel(card,text="Se guarda la ruta local en apariencia.zyhcfg; imágenes grandes se reducen para consumir menos RAM.",wraplength=900,text_color="#a7b5c9").pack(anchor="w",padx=16,pady=3)
        row2=ctk.CTkFrame(card,fg_color="transparent");row2.pack(fill="x",padx=12,pady=(7,14))
        ctk.CTkButton(row2,text="Seleccionar imagen",command=self.choose_wallpaper).pack(side="left",padx=4)
        ctk.CTkButton(row2,text="Quitar fondo",fg_color="#62748b",command=self.remove_wallpaper).pack(side="left",padx=4)
        ctk.CTkLabel(b,text="Ahorro de recursos: no se usa GPU, no se reproducen animaciones y el chat consulta el servidor solo mientras tienes abierta esa sección.",wraplength=950,justify="left",text_color="#a7b5c9").pack(anchor="w",pady=10)
    def set_theme(self,theme):
        self.app_config["theme"]=theme;write_config(self.app_config);ctk.set_appearance_mode(theme);messagebox.showinfo("Apariencia","Tema aplicado. Algunos colores de panel se conservan en azul oscuro.",parent=self)
    def set_accent(self,color):self.app_config["accent"]=color;write_config(self.app_config);messagebox.showinfo("Apariencia","El color se guardó; se aplicará en los controles al volver a abrir páginas.",parent=self)
    def choose_accent(self):
        color=colorchooser.askcolor(title="Elegir color de acento",parent=self)[1]
        if color:self.set_accent(color)
    def choose_wallpaper(self):
        path=filedialog.askopenfilename(parent=self,title="Seleccionar fondo",filetypes=[("Imágenes","*.png *.jpg *.jpeg *.webp *.bmp"),("Todos los archivos","*.*")])
        if path:
            self.app_config["wallpaper"]=path;write_config(self.app_config);self.wall_path=path;self._load_wallpaper();self.show_page("Apariencia");messagebox.showinfo("Fondo","Fondo guardado. Reabre la sección o la aplicación si no aparece en todas las pantallas.",parent=self)
    def remove_wallpaper(self):self.app_config["wallpaper"]="";write_config(self.app_config);self.wall_path="";self._load_wallpaper();self.show_page("Apariencia")
    def _poll(self):
        try:
            while True: self._ui_queue.get_nowait()()        # tareas que dejaron los hilos
        except queue.Empty: pass
        except Exception: pass
        if self.current_page=="Chat LAN/WLAN":
            try:
                if hasattr(self,"public_panel"):self.refresh_public()
                if hasattr(self,"private_panel") and self.peer_var.get():self.load_private()
            except Exception:pass
        self._poll_id=self.after(2200,self._poll)
    def close_app(self):
        try:self.session.close()
        except Exception:pass
        if self.server:self.server.stop()
        self.destroy()
        try:self.gate.destroy()
        except Exception:pass

def main():
    import zyh_terms; zyh_terms.require("ZYH Business")      # términos: si no se aceptan, la app se cierra
    gate=ConnectionWindow(); gate.mainloop()
if __name__=="__main__": main()
