# -*- coding: utf-8 -*-
"""Lector de códigos de barras para ZYH Business.
- Lector USB: funciona como teclado; escribe el código y pulsa Enter → se captura en el cuadro de texto.
- Cámara: OpenCV (BarcodeDetector, y QR). Es opcional: si no está instalado, el lector USB sigue funcionando.
"""
import time
import customtkinter as ctk

try:
    import cv2
except Exception:
    cv2 = None


def camera_ok():
    return cv2 is not None


def make_detector():
    """Devuelve f(frame)->lista de códigos. Prueba BarcodeDetector, pyzbar y QR."""
    fns = []
    if cv2 is not None:
        try:
            det = cv2.barcode.BarcodeDetector()
            def f_bar(fr):
                # el detector de OpenCV es sensible al tamaño: se prueban varias escalas
                for sc in (1.0, 0.7, 0.5, 0.35):
                    im = fr if sc == 1.0 else cv2.resize(fr, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
                    res = det.detectAndDecodeWithType(im)
                    info = res[1] if len(res) >= 3 else res[0]
                    out = [x for x in (info or []) if x]
                    if out:
                        return out
                return []
            fns.append(f_bar)
        except Exception:
            pass
        try:
            qr = cv2.QRCodeDetector()
            fns.append(lambda fr: [s for s in [qr.detectAndDecode(fr)[0]] if s])
        except Exception:
            pass
    try:
        from pyzbar import pyzbar
        fns.append(lambda fr: [o.data.decode("utf-8", "ignore") for o in pyzbar.decode(fr)])
    except Exception:
        pass

    def detect(frame):
        for f in fns:
            try:
                out = f(frame)
                if out:
                    return out
            except Exception:
                continue
        return []
    return detect


class ScanDialog(ctk.CTkToplevel):
    """Ventana de escaneo. on_code(code) -> texto (o None) que se muestra al usuario."""

    def __init__(self, parent, title, on_code, buttons=(), hint="Pasa el lector USB o usa la cámara."):
        super().__init__(parent)
        self.title(title); self.geometry("560x640"); self.transient(parent)
        self.on_code = on_code; self.cap = None; self._job = None; self._last = ("", 0.0); self._frame_n = 0
        self.detect = None
        ctk.CTkLabel(self, text=hint, wraplength=500, text_color="#a7b5c9").pack(padx=16, pady=(14, 6))
        self.entry = ctk.CTkEntry(self, placeholder_text="Código de barras (el lector USB escribe aquí)", height=42,
                                  font=ctk.CTkFont(size=18))
        self.entry.pack(fill="x", padx=16); self.entry.bind("<Return>", lambda _e: self.submit())
        row = ctk.CTkFrame(self, fg_color="transparent"); row.pack(fill="x", padx=16, pady=8)
        ctk.CTkButton(row, text="Aceptar código", width=130, command=self.submit).pack(side="left")
        self.cam_btn = ctk.CTkButton(row, text="Usar cámara", width=130, fg_color="#0f766e", command=self.toggle_camera)
        self.cam_btn.pack(side="left", padx=8)
        for text, cb in buttons:
            ctk.CTkButton(row, text=text, width=110, fg_color="#16a34a", command=lambda c=cb: c(self)).pack(side="right")
        self.preview = ctk.CTkLabel(self, text="", height=240, fg_color="#0b1220", corner_radius=10)
        self.preview.pack(fill="x", padx=16, pady=4)
        self.info = ctk.CTkLabel(self, text="Esperando código…", justify="left", anchor="nw", wraplength=500, text_color="#e6f0fa")
        self.info.pack(fill="both", expand=True, padx=16, pady=8)
        self.protocol("WM_DELETE_WINDOW", self.close)
        self.after(150, self.entry.focus_force)

    def set_info(self, text):
        self.info.configure(text=text)

    def submit(self, code=None):
        code = (code if code is not None else self.entry.get()).strip()
        self.entry.delete(0, "end")
        if not code:
            return
        now = time.time()
        if code == self._last[0] and now - self._last[1] < 1.5:   # evita lecturas dobles de la cámara
            return
        self._last = (code, now)
        try:
            self.bell()
        except Exception:
            pass
        try:
            msg = self.on_code(code)
        except Exception as exc:
            msg = f"Error: {exc}"
        if msg:
            self.set_info(msg)
        self.entry.focus_force()

    # ------------------------------------------------ cámara
    def toggle_camera(self):
        if self.cap is not None:
            return self.stop_camera()
        if cv2 is None:
            self.set_info("Para usar la cámara instala OpenCV:  pip install opencv-python\nEl lector USB funciona igual.")
            return
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.set_info("No encontré una cámara disponible. Revisa que no la use otra app.")
            return
        self.cap = cap; self.detect = make_detector(); self.cam_btn.configure(text="Apagar cámara")
        self._tick()

    def _tick(self):
        if self.cap is None:
            return
        ok, frame = self.cap.read()
        if ok:
            self._frame_n += 1
            if self._frame_n % 3 == 0:
                for code in self.detect(frame)[:1]:
                    self.submit(code)
            try:
                from PIL import Image
                h, w = frame.shape[:2]; k = 240 / h
                rgb = cv2.cvtColor(cv2.resize(frame, (int(w * k), 240)), cv2.COLOR_BGR2RGB)
                img = ctk.CTkImage(Image.fromarray(rgb), size=(int(w * k), 240))
                self.preview.configure(image=img, text=""); self.preview.image = img
            except Exception:
                pass
        self._job = self.after(40, self._tick)

    def stop_camera(self):
        if self._job:
            try: self.after_cancel(self._job)
            except Exception: pass
            self._job = None
        if self.cap is not None:
            self.cap.release(); self.cap = None
        self.cam_btn.configure(text="Usar cámara")
        self.preview.configure(image=None, text="")

    def close(self):
        self.stop_camera(); self.destroy()
