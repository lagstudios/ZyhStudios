# -*- coding: utf-8 -*-
"""ZYH Business — tipos de negocio y EXTENSIONES creadas por la IA.

Una extensión es un archivo JSON declarativo (nombres del menú, categorías de gastos, contexto para
la IA de WhatsApp y tareas iniciales). La IA nunca genera código que se ejecute: el JSON se valida
y solo puede tocar estas cosas, así una extensión mala no puede dañar el programa ni tus datos.
"""
import os, re, json, urllib.request

LABEL_KEYS = ["Resumen", "Clientes", "Inventario", "Ventas", "Gastos", "Cotizaciones", "Tareas",
              "Chat LAN/WLAN", "IA WhatsApp"]          # menús que se pueden renombrar
DEFAULT_CATS = ["Operación", "Servicios", "Nómina", "Inventario", "Otros"]
GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent"

BUILTIN = {
    "Tienda / minimercado": {"labels": {}, "expense_cats": DEFAULT_CATS, "ai_hint": "", "tasks": []},
    "Restaurante": {
        "labels": {"Clientes": "Comensales", "Inventario": "Menú e insumos", "Ventas": "Pedidos", "Cotizaciones": "Eventos"},
        "expense_cats": ["Ingredientes", "Gas y servicios", "Nómina", "Arriendo", "Mantenimiento", "Otros"],
        "ai_hint": "Es un restaurante: los productos son platos e insumos. Atiende pedidos y reservas con amabilidad; no prometas tiempos de entrega.",
        "tasks": ["Revisar neveras y fechas de vencimiento", "Cuadrar caja del día", "Pedir insumos al proveedor"]},
    "Taller mecánico": {
        "labels": {"Clientes": "Clientes y vehículos", "Inventario": "Repuestos", "Ventas": "Servicios y ventas", "Cotizaciones": "Presupuestos"},
        "expense_cats": ["Repuestos", "Herramientas", "Nómina", "Arriendo", "Servicios", "Otros"],
        "ai_hint": "Es un taller mecánico: los productos son repuestos. Pregunta marca, modelo y año del vehículo antes de cotizar.",
        "tasks": ["Revisar repuestos con stock bajo", "Llamar a clientes con vehículo listo"]},
    "Farmacia / droguería": {
        "labels": {"Inventario": "Medicamentos", "Ventas": "Despachos"},
        "expense_cats": ["Compra de medicamentos", "Arriendo", "Nómina", "Servicios", "Otros"],
        "ai_hint": "Es una droguería: da precio y disponibilidad, pero NUNCA recetes ni des dosis; sugiere consultar al médico o al farmacéutico.",
        "tasks": ["Revisar fechas de vencimiento", "Verificar stock mínimo de medicamentos de alta rotación"]},
    "Peluquería y estética": {
        "labels": {"Clientes": "Clientes y citas", "Inventario": "Productos e insumos", "Ventas": "Servicios", "Cotizaciones": "Paquetes"},
        "expense_cats": ["Insumos", "Arriendo", "Nómina y comisiones", "Servicios", "Otros"],
        "ai_hint": "Es una peluquería/centro de estética: ayuda a agendar citas y explica los servicios sin prometer resultados.",
        "tasks": ["Confirmar las citas de mañana", "Reponer tintes y productos"]},
    "Ferretería": {
        "labels": {"Inventario": "Productos y herramientas", "Cotizaciones": "Cotizaciones de obra"},
        "expense_cats": ["Compra de mercancía", "Fletes", "Nómina", "Arriendo", "Servicios", "Otros"],
        "ai_hint": "Es una ferretería: da precio, medidas y disponibilidad; sugiere productos complementarios sin presionar.",
        "tasks": ["Contar tornillería y consumibles", "Pedir mercancía faltante"]},
    "Panadería / cafetería": {
        "labels": {"Inventario": "Productos e ingredientes", "Ventas": "Ventas del día"},
        "expense_cats": ["Harinas e ingredientes", "Gas y servicios", "Nómina", "Arriendo", "Otros"],
        "ai_hint": "Es una panadería/cafetería: informa productos del día, precios y encargos con anticipación.",
        "tasks": ["Planear producción de mañana", "Revisar ingredientes por agotarse"]},
}


def ext_dir(data_dir):
    d = os.path.join(str(data_dir), "extensiones"); os.makedirs(d, exist_ok=True); return d


def _s(x, n):
    return re.sub(r"[\x00-\x1f<>]", "", str(x or "")).strip()[:n]


def validate(spec):
    """Deja solo lo permitido. Lanza ValueError si no sirve."""
    if not isinstance(spec, dict):
        raise ValueError("La extensión no es válida.")
    name = _s(spec.get("name"), 40)
    if not name:
        raise ValueError("La extensión no trae nombre.")
    labels = {}
    for k, v in (spec.get("labels") or {}).items():
        if k in LABEL_KEYS and _s(v, 28):
            labels[k] = _s(v, 28)
    cats = [_s(c, 30) for c in (spec.get("expense_cats") or []) if _s(c, 30)][:12] or list(DEFAULT_CATS)
    tasks = [_s(t, 90) for t in (spec.get("tasks") or []) if _s(t, 90)][:8]
    return {"name": name, "labels": labels, "expense_cats": cats, "ai_hint": _s(spec.get("ai_hint"), 600), "tasks": tasks}


def installed(data_dir):
    out = {}
    for f in sorted(os.listdir(ext_dir(data_dir))):
        if f.endswith(".zyhx"):
            try:
                with open(os.path.join(ext_dir(data_dir), f), encoding="utf-8") as fh:
                    s = validate(json.load(fh)); out[s["name"]] = s
            except Exception:
                continue
    return out


def all_types(data_dir):
    t = {k: dict(v, name=k) for k, v in BUILTIN.items()}
    t.update(installed(data_dir))
    return t


def install(data_dir, spec):
    spec = validate(spec)
    fn = re.sub(r"[^a-z0-9]+", "_", spec["name"].lower()).strip("_") or "extension"
    with open(os.path.join(ext_dir(data_dir), fn + ".zyhx"), "w", encoding="utf-8") as fh:
        json.dump(spec, fh, ensure_ascii=False, indent=1)
    return spec


def _active_path(data_dir): return os.path.join(str(data_dir), "tipo_negocio.json")


def set_active(data_dir, name):
    with open(_active_path(data_dir), "w", encoding="utf-8") as fh:
        json.dump({"active": name}, fh)


def load_active(data_dir):
    try:
        with open(_active_path(data_dir), encoding="utf-8") as fh:
            name = json.load(fh).get("active")
        return all_types(data_dir).get(name) or dict(BUILTIN["Tienda / minimercado"], name="Tienda / minimercado")
    except Exception:
        return dict(BUILTIN["Tienda / minimercado"], name="Tienda / minimercado")


def label(spec, key):
    return (spec or {}).get("labels", {}).get(key, key)


def ai_context(spec):
    if not spec or not spec.get("ai_hint"):
        return ""
    return f"TIPO DE NEGOCIO: {spec['name']}. {spec['ai_hint']}"


PROMPT = ("Eres un configurador de ZYH Business, un programa de gestión (clientes, inventario, ventas, gastos, "
          "cotizaciones, tareas) para pequeños negocios. El usuario describe su tipo de negocio. Devuelve SOLO un JSON "
          "con esta forma exacta: {\"name\": \"nombre corto del negocio\", \"labels\": {\"Clientes\": \"...\", "
          "\"Inventario\": \"...\", \"Ventas\": \"...\", \"Cotizaciones\": \"...\"}, \"expense_cats\": [\"6 categorías de gastos "
          "típicas\"], \"ai_hint\": \"2 frases para que la IA de WhatsApp atienda bien a este negocio\", \"tasks\": "
          "[\"3 a 5 tareas iniciales útiles\"]}. En labels usa solo claves de: " + ", ".join(LABEL_KEYS) +
          ". Los valores son el nombre que usa ese negocio para esa sección (máx. 28 letras). Todo en español. Nada de texto fuera del JSON.")


def generate(description, api_key):
    """Pide a Gemini una extensión. Sin clave → plantilla básica editable (se avisa con basic=True)."""
    description = _s(description, 400)
    if not description:
        raise ValueError("Describe tu negocio.")
    if not api_key:
        spec = {"name": description[:40], "labels": {}, "expense_cats": DEFAULT_CATS,
                "ai_hint": f"Es un negocio de este tipo: {description}. Atiende con claridad usando solo el inventario real.", "tasks": []}
        return validate(spec), True
    payload = {"systemInstruction": {"parts": [{"text": PROMPT}]},
               "contents": [{"role": "user", "parts": [{"text": description}]}],
               "generationConfig": {"temperature": 0.4, "maxOutputTokens": 700, "responseMimeType": "application/json"}}
    req = urllib.request.Request(GEMINI_URL + "?key=" + api_key, data=json.dumps(payload).encode(),
                                 headers={"Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=30) as r:
        txt = json.loads(r.read().decode())["candidates"][0]["content"]["parts"][0]["text"]
    m = re.search(r"\{.*\}", txt, re.S)
    if not m:
        raise ValueError("La IA no devolvió una extensión válida. Intenta describir el negocio con más detalle.")
    return validate(json.loads(m.group(0))), False
