# -*- coding: utf-8 -*-
"""ZYH Business — IA autónoma de atención por WhatsApp (API oficial de Meta + Google Gemini).

Qué hace:
  • Responde con el INVENTARIO REAL (nombre, existencias y precio) y cuida la confianza de cada cliente.
  • Entiende IMÁGENES que envía el cliente (con Gemini) y las relaciona con el inventario.
  • Cuando el cliente quiere comprar, ANOTA EL PEDIDO solo si el stock lo permite. El stock lo confirma
    el programa (no la IA): la función order_fn consulta el inventario en ese instante.
  • El pedido queda "esperando aprobación"; los encargados lo aprueban y entonces se envían los datos de pago.
  • Se ENTRENA SOLA: si pasa más de 1 minuto sin mensajes, repasa las conversaciones y guarda lo aprendido
    (qué busca cada cliente, preguntas frecuentes, cómo responder mejor). Si llega un mensaje, deja de
    entrenar y atiende usando lo aprendido.
  • Sin clave de Gemini funciona en modo básico (lee el inventario y anota pedidos por palabras clave).
"""
import os, re, json, time, base64, sqlite3, threading, urllib.request, urllib.error
from datetime import date

DEFAULT_MODEL = "gemini-3.6-flash"
FALLBACK_MODEL = "gemini-flash-latest"
API = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"
IDLE_SECONDS = 60          # tiempo sin mensajes para empezar a entrenarse
MAX_IMAGE = 4 * 1024 * 1024

POS = ["gracias", "excelente", "perfecto", "genial", "me encanta", "de una", "listo", "buena", "super"]
NEG = ["caro", "estafa", "malo", "pésimo", "pesimo", "tarde", "no sirve", "molesto", "reclamo", "demora"]
BUY = ["compro", "lo llevo", "me lo llevo", "quiero comprar", "apártalo", "apartalo", "lo quiero", "los quiero",
       "la quiero", "las quiero", "lo compro", "me llevo", "hacer el pedido", "quiero pedir", "pedido de", "sí, lo llevo"]
NUMS = {"un": 1, "uno": 1, "una": 1, "dos": 2, "tres": 3, "cuatro": 4, "cinco": 5, "seis": 6, "siete": 7,
        "ocho": 8, "nueve": 9, "diez": 10}


def _money(v):
    try:
        return f"{float(v):,.0f}".replace(",", ".")
    except Exception:
        return "0"


def _norm(s):
    s = str(s).lower()
    for a, b in zip("áéíóúü", "aeiouu"):
        s = s.replace(a, b)
    return s


def _stems(text):
    """Palabras clave sin plural (taladros → taladro) para comparar mensajes con nombres de productos."""
    out = set()
    for w in re.findall(r"\w+", _norm(text)):
        if len(w) > 3:
            out.add(w[:-2] if w.endswith("es") and len(w) > 5 else w[:-1] if w.endswith("s") else w)
    return out


def _mentions(text, name):
    return bool(_stems(text) & _stems(name))


class Brain:
    """products_fn() -> [{"id","name","quantity","price"}]  (inventario real, consultado cada vez)
    order_fn(phone, product_id, qty) -> {"ok":bool, "id", "name", "qty", "total", "available", "error"}"""

    def __init__(self, data_dir, products_fn, order_fn=None, business_name="mi negocio", api_key="",
                 daily_limit=100000, context="", model=DEFAULT_MODEL):
        self.products_fn = products_fn
        self.order_fn = order_fn
        self.business_name = business_name or "mi negocio"
        self.api_key = (api_key or "").strip()
        self.daily_limit = daily_limit
        self.context = context or ""
        self.model = (model or DEFAULT_MODEL).strip()
        self.lock = threading.RLock()
        self.last_activity = time.time()
        self.dirty = True                      # hay conversaciones nuevas por estudiar
        self.training = False
        self.last_error = ""
        self.db = sqlite3.connect(os.path.join(str(data_dir), "ia_whatsapp.db"), check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript("""
        CREATE TABLE IF NOT EXISTS ai_customers(phone TEXT PRIMARY KEY, trust REAL DEFAULT 50, notes TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS ai_messages(id INTEGER PRIMARY KEY, phone TEXT, role TEXT, body TEXT, ts INTEGER);
        CREATE TABLE IF NOT EXISTS ai_knowledge(key TEXT PRIMARY KEY, value TEXT NOT NULL);
        """)
        cols = [r[1] for r in self.db.execute("PRAGMA table_info(ai_customers)")]
        for col, ddl in (("last_product", "TEXT DEFAULT ''"), ("name", "TEXT DEFAULT ''")):
            if col not in cols:
                self.db.execute(f"ALTER TABLE ai_customers ADD COLUMN {col} {ddl}")
        self.db.commit()

    # ------------------------------------------------ inventario real
    def products(self):
        try:
            out = []
            for p in self.products_fn() or []:
                out.append({"id": int(p["id"]), "name": str(p["name"]), "quantity": int(float(p["quantity"])),
                            "price": float(p["price"])})
            return out
        except Exception as e:
            self.last_error = f"inventario: {e}"
            return []

    def catalog_text(self, prods=None):
        out = []
        for p in (prods if prods is not None else self.products()):
            st = "SIN STOCK" if p["quantity"] <= 0 else f"{p['quantity']} disponibles"
            out.append(f"- {p['name']}: ${_money(p['price'])} · {st}")
        return "\n".join(out) or "(inventario vacío)"

    def match_product(self, name, prods=None):
        prods = prods if prods is not None else self.products()
        n = _norm(name).strip()
        if not n:
            return None
        for p in prods:
            if _norm(p["name"]) == n:
                return p
        for p in prods:
            if n in _norm(p["name"]) or _norm(p["name"]) in n:
                return p
        words = _stems(n)
        best, score = None, 0
        for p in prods:
            s = len(words & _stems(p["name"]))
            if s > score:
                best, score = p, s
        return best

    # ------------------------------------------------ memoria / confianza
    def _cust(self, phone):
        with self.lock:
            r = self.db.execute("SELECT * FROM ai_customers WHERE phone=?", (phone,)).fetchone()
            if not r:
                self.db.execute("INSERT INTO ai_customers(phone) VALUES(?)", (phone,)); self.db.commit()
                r = self.db.execute("SELECT * FROM ai_customers WHERE phone=?", (phone,)).fetchone()
            return dict(r)

    def _set(self, phone, **kw):
        with self.lock:
            for k, v in kw.items():
                self.db.execute(f"UPDATE ai_customers SET {k}=? WHERE phone=?", (v, phone))
            self.db.commit()

    def _log(self, phone, role, body):
        with self.lock:
            self.db.execute("INSERT INTO ai_messages(phone,role,body,ts) VALUES(?,?,?,?)",
                            (phone, role, body, int(time.time()))); self.db.commit()

    def history(self, phone, n=12):
        with self.lock:
            rows = self.db.execute("SELECT role, body FROM ai_messages WHERE phone=? ORDER BY id DESC LIMIT ?",
                                   (phone, n)).fetchall()
        return [dict(r) for r in reversed(rows)]

    def customers(self):
        with self.lock:
            return [dict(r) for r in self.db.execute("SELECT * FROM ai_customers ORDER BY trust DESC")]

    def knowledge(self, key="aprendizaje"):
        with self.lock:
            r = self.db.execute("SELECT value FROM ai_knowledge WHERE key=?", (key,)).fetchone()
        return r["value"] if r else ""

    def _know(self, key, value):
        with self.lock:
            self.db.execute("INSERT OR REPLACE INTO ai_knowledge(key,value) VALUES(?,?)", (key, value)); self.db.commit()

    def update_trust(self, phone, text):
        t = self._cust(phone)["trust"]; low = text.lower()
        d = 0.5 + 3 * sum(w in low for w in POS) - 4 * sum(w in low for w in NEG)
        if any(w in low for w in BUY):
            d += 6
        t = max(0, min(100, t + d)); self._set(phone, trust=t)
        return t

    def _today_count(self):
        start = int(time.mktime(date.today().timetuple()))
        with self.lock:
            return self.db.execute("SELECT COUNT(*) FROM ai_messages WHERE role='assistant' AND ts>=?", (start,)).fetchone()[0]

    # ------------------------------------------------ Gemini
    def _call(self, model, system, contents, as_json):
        cfg = {"temperature": 0.5, "maxOutputTokens": 700}
        if as_json:
            cfg["responseMimeType"] = "application/json"
        payload = {"systemInstruction": {"parts": [{"text": system}]}, "contents": contents, "generationConfig": cfg}
        req = urllib.request.Request(API.format(model=model), data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json", "x-goog-api-key": self.api_key})
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
        return "".join(p.get("text", "") for p in data["candidates"][0]["content"]["parts"]).strip()

    def _gemini(self, system, contents, as_json=False):
        try:
            return self._call(self.model, system, contents, as_json)
        except urllib.error.HTTPError as e:
            if e.code in (400, 404) and self.model != FALLBACK_MODEL:      # modelo retirado o mal escrito
                return self._call(FALLBACK_MODEL, system, contents, as_json)
            raise

    def _system(self, phone, trust, prods):
        c = self._cust(phone); learned = self.knowledge()
        return (f'Eres el asistente de ventas por WhatsApp de "{self.business_name}". Hablas español, cálido, breve, de tú. '
                f'Tu meta: ayudar y GANARTE LA CONFIANZA del cliente (confianza actual {trust:.0f}/100; súbela siendo honesto y claro).\n'
                f'{self.context}\n'
                f'INVENTARIO REAL (no inventes productos, precios ni existencias):\n{self.catalog_text(prods)}\n'
                f'Lo que sabes de este cliente: {c.get("notes") or "nada aún"}\n'
                f'Lo que has aprendido atendiendo este negocio: {learned or "aún nada"}\n'
                'REGLAS:\n'
                '1. Si preguntan por un producto di precio y cuántas unidades hay. Si no hay stock dilo y ofrece una alternativa del inventario.\n'
                '2. Si el cliente envía una IMAGEN, describe en pocas palabras qué ves y dile si hay algo igual o parecido en el inventario.\n'
                '3. Solo cuando el cliente diga claramente que quiere comprar un producto del inventario, rellena "order" con el nombre '
                'EXACTO del inventario y la cantidad. Si no dice cantidad, usa 1. Si duda o solo pregunta, "order" es null.\n'
                '4. Nunca confirmes una venta, ni pidas pagos, ni des datos de pago: el sistema anota el pedido, verifica el stock y un '
                'encargado lo aprueba. Tampoco prometas envíos, descuentos ni fechas.\n'
                'Responde SOLO con JSON: {"reply": "tu mensaje para el cliente", "order": null o {"product": "nombre exacto", "qty": número}}')

    @staticmethod
    def _parse(txt):
        try:
            m = re.search(r"\{.*\}", txt, re.S)
            d = json.loads(m.group(0)) if m else {}
            if isinstance(d, dict) and isinstance(d.get("reply"), str):
                o = d.get("order")
                return d["reply"].strip(), (o if isinstance(o, dict) else None)
        except Exception:
            pass
        return txt.strip(), None

    # ------------------------------------------------ modo básico (sin Gemini)
    def _basic(self, phone, text, prods, has_image):
        t = _norm(text)
        if has_image and not text.strip():
            return ("Recibí tu imagen 📷. Para ayudarte más rápido, ¿me escribes el nombre del producto que buscas? "
                    "Así te confirmo precio y disponibilidad."), None
        hit = next((p for p in prods if _mentions(text, p["name"])), None)
        last = self._cust(phone).get("last_product") or ""
        if any(_norm(b) in t for b in BUY):
            p = hit or (self.match_product(last, prods) if last else None)
            if p:
                m = re.search(r"\b(\d{1,3})\b", t)
                qty = int(m.group(1)) if m else next((v for k, v in NUMS.items() if re.search(rf"\b{k}\b", t)), 1)
                return "", {"product": p["name"], "qty": max(1, qty)}
        if hit:
            if hit["quantity"] <= 0:
                return f"{hit['name']}: está en ${_money(hit['price'])}, pero ahora no tengo stock 😕 ¿Te muestro algo parecido?", None
            return f"{hit['name']}: cuesta ${_money(hit['price'])} y tengo {hit['quantity']} disponibles. ¿Te lo aparto?", None
        if any(g in t for g in ["hola", "buenas", "buen dia", "buenos"]):
            return f"¡Hola! Bienvenido a {self.business_name} 👋 ¿Qué producto buscas? Te digo precio y disponibilidad.", None
        if any(w in t for w in ["catalogo", "que tienen", "que venden", "productos"]):
            return "Esto es lo que tenemos ahora:\n" + self.catalog_text(prods), None
        return "Con gusto te ayudo. ¿Me dices el nombre del producto? Así te confirmo precio y cuántos hay.", None

    # ------------------------------------------------ pedidos (el stock lo confirma el programa)
    def _take_order(self, phone, order, prods):
        """Devuelve el texto para el cliente. Nunca anota un pedido sin stock confirmado."""
        p = self.match_product(order.get("product", ""), prods)
        try:
            qty = max(1, int(float(order.get("qty", 1))))
        except Exception:
            qty = 1
        if not p:
            return "No encontré ese producto en nuestro inventario. ¿Me confirmas el nombre?"
        if not self.order_fn:
            return f"Tengo {p['quantity']} de {p['name']}. Un encargado te confirma la compra en un momento."
        try:
            r = self.order_fn(phone, p["id"], qty)          # ← confirma stock en el inventario en este instante
        except Exception as e:
            self.last_error = f"pedido: {e}"
            return "Tuve un problema anotando tu pedido. Un encargado te escribe enseguida."
        if r.get("ok"):
            return (f"📝 Anoté tu pedido: {r['qty']} × {r['name']} = {r['total']}.\n"
                    "Un encargado confirma tu compra y enseguida te envío los datos para pagar.")
        avail = int(r.get("available", 0))
        if avail <= 0:
            return f"Lo siento, {p['name']} se agotó 😕 ¿Te muestro algo parecido?"
        return f"De {p['name']} solo me quedan {avail}. ¿Quieres que anote {avail}?"

    # ------------------------------------------------ respuesta a un mensaje
    def reply(self, phone, text="", image=None, name=""):
        """image = (bytes, mime) o None. Devuelve el texto de respuesta (o None si se alcanzó el límite diario)."""
        self.last_activity = time.time(); self.dirty = True          # llegó mensaje: se deja de entrenar y se atiende
        if self._today_count() >= self.daily_limit:
            return None
        text = (text or "").strip()
        if name:
            self._cust(phone); self._set(phone, name=str(name)[:80])
        self._log(phone, "user", ("[imagen] " + text).strip() if image else text)
        trust = self.update_trust(phone, text)
        prods = self.products()
        out, order = None, None
        if self.api_key:
            try:
                contents = [{"role": "user" if m["role"] == "user" else "model", "parts": [{"text": m["body"]}]}
                            for m in self.history(phone)]
                if image and len(image[0]) <= MAX_IMAGE:
                    contents[-1]["parts"] = [{"inline_data": {"mime_type": image[1] or "image/jpeg",
                                                               "data": base64.b64encode(image[0]).decode()}},
                                             {"text": text or "El cliente envió esta imagen."}]
                out, order = self._parse(self._gemini(self._system(phone, trust, prods), contents, as_json=True))
            except Exception as e:
                self.last_error = f"Gemini: {e}"; out = None
        if out is None:
            out, order = self._basic(phone, text, prods, bool(image))
        mentioned = self.match_product(order["product"], prods) if order else next(
            (p for p in prods if _norm(p["name"]) in _norm(text + " " + (out or ""))), None)
        if mentioned:
            self._set(phone, last_product=mentioned["name"])
        if order:
            out = self._take_order(phone, order, prods)
        out = out or "¿En qué te puedo ayudar?"
        self._log(phone, "assistant", out)
        return out

    # ------------------------------------------------ entrenamiento en tiempos libres
    def idle_for(self):
        return time.time() - self.last_activity

    def should_train(self):
        return self.dirty and not self.training and self.idle_for() >= IDLE_SECONDS

    def learn_idle(self):
        """Repasa las conversaciones y guarda lo aprendido. Se interrumpe si llega un mensaje."""
        started = self.last_activity; self.training = True
        interrupted = lambda: self.last_activity != started
        try:
            prods = self.products(); allq = []
            for c in self.customers()[:40]:
                if interrupted():
                    return False
                hist = [h["body"] for h in self.history(c["phone"], 30) if h["role"] == "user"]
                allq += hist
                if len(hist) < 2:
                    continue
                joined = " | ".join(hist)[:1500]; note = None
                if self.api_key:
                    try:
                        note = self._gemini("Resume en 1 frase qué busca o le importa a este cliente, para venderle mejor.",
                                            [{"role": "user", "parts": [{"text": joined}]}])[:300]
                    except Exception as e:
                        self.last_error = f"Gemini: {e}"
                if not note:
                    hits = [p["name"] for p in prods if _mentions(joined, p["name"])]
                    note = "Interesado en: " + (", ".join(hits[:4]) or "productos varios")
                self._set(c["phone"], notes=note)
            if interrupted():
                return False
            learned = None
            if allq and self.api_key:
                try:
                    learned = self._gemini(
                        "Eres el entrenador de un asistente de ventas. A partir de estos mensajes reales de clientes, escribe en "
                        "máximo 5 viñetas cortas: qué preguntan más, qué productos piden, qué dudas u objeciones tienen y cómo "
                        "conviene responderles. Solo hechos útiles, sin inventar.",
                        [{"role": "user", "parts": [{"text": " | ".join(allq)[-4000:]}]}])[:900]
                except Exception as e:
                    self.last_error = f"Gemini: {e}"
            if not learned:
                cnt = {}
                for q in allq:
                    for p in prods:
                        if _mentions(q, p["name"]):
                            cnt[p["name"]] = cnt.get(p["name"], 0) + 1
                top = sorted(cnt, key=cnt.get, reverse=True)[:5]
                learned = ("Lo más consultado: " + ", ".join(top)) if top else ""
            if learned:
                self._know("aprendizaje", learned)
            self._know("entrenado", time.strftime("%Y-%m-%d %H:%M"))
            self.dirty = False
            return True
        finally:
            self.training = False

    def status(self):
        if self.training:
            return "Entrenándose con las conversaciones…"
        t = self.knowledge("entrenado")
        wait = max(0, int(IDLE_SECONDS - self.idle_for()))
        if self.dirty:
            return f"Atendiendo. Se entrena sola en {wait} s sin mensajes." + (f" Último entrenamiento: {t}." if t else "")
        return f"Al día. Último entrenamiento: {t or 'aún no'}."
