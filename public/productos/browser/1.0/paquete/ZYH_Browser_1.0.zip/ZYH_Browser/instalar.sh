#!/usr/bin/env bash
# ZYH Browser — instalador (solo librerías de Python con --break-system-packages; no usa sudo)
DIR="$(cd "$(dirname "$0")" && pwd)"
PY=$(command -v python3 || command -v python)
[ -z "$PY" ] && { echo "Falta Python 3. Instálalo y repite."; exit 1; }
echo "Python: $($PY --version)"
$PY -m pip --version >/dev/null 2>&1 || $PY -m ensurepip --user >/dev/null 2>&1
$PY -m pip install --user --upgrade --break-system-packages "pywebview[qt]" \
  || $PY -m pip install --user --upgrade "pywebview[qt]"
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/zyh-browser.desktop" <<EOT
[Desktop Entry]
Type=Application
Name=ZYH Browser
Exec=$PY "$DIR/app_completa/zyh_browser.py"
Icon=$DIR/logo.png
Terminal=false
Categories=Utility;
EOT
echo "Listo. Abre \"ZYH Browser\" desde tu menú de aplicaciones."
