# -*- coding: utf-8 -*-
"""ZYH Browser · ZYH Studios — navegador gratuito.

Navegador de verdad sobre Qt WebEngine (motor Chromium, código abierto):
  • Pestañas reales (cada una con su página), barra de direcciones y búsqueda.
  • Descargas con progreso, carpeta configurable y lista de descargas.
  • Ajustes (inicio, buscador, descargas, restaurar pestañas, zoom, borrar datos) y «Acerca de» con la versión.
  • Sesiones persistentes (las webs recuerdan tu inicio de sesión), permisos de cámara/micrófono/ubicación
    con pregunta, enlaces que abren ventana nueva → pestaña nueva, pantalla completa solo cuando el video la pide.
"""
import os, sys, json, html, time

APP = "ZYH Browser"
VERSION = "3.0.0"
HERE = os.path.dirname(os.path.abspath(__file__))
for _c in (os.path.join(HERE, "..", "_core"), os.path.join(HERE, "..", "..", "_core")):
    if os.path.isdir(_c):
        sys.path.insert(0, os.path.abspath(_c)); break

CONF_DIR = os.path.join(os.path.expanduser("~"), ".config", "zyh", "browser")
DATA_DIR = os.path.join(os.path.expanduser("~"), ".local", "share", "zyh", "browser")
SETTINGS = os.path.join(CONF_DIR, "settings.json")
SESSION = os.path.join(CONF_DIR, "session.json")
HOME = "zyh://inicio"
ENGINES = {"Google": "https://www.google.com/search?q={}", "DuckDuckGo": "https://duckduckgo.com/?q={}",
           "Bing": "https://www.bing.com/search?q={}", "Brave": "https://search.brave.com/search?q={}"}
DEFAULTS = {"home": HOME, "engine": "Google", "downloads": os.path.join(os.path.expanduser("~"), "Downloads"),
            "ask_download": False, "restore": True, "zoom": 100, "geometry": [1180, 760]}
ACCENT = "#8bf5a2"
QSS = f"""
QMainWindow, QDialog {{ background:#0e0b1a; color:#eae6ff; }}
QWidget {{ color:#eae6ff; font-size:13px; }}
QToolBar {{ background:#15112a; border:0; padding:4px; spacing:4px; }}
QToolButton {{ background:transparent; border-radius:8px; padding:5px 9px; font-size:15px; }}
QToolButton:hover {{ background:#26203f; }}
QToolButton:disabled {{ color:#5a5478; }}
QLineEdit {{ background:#1c1730; border:1px solid #2e2750; border-radius:14px; padding:6px 12px; selection-background-color:{ACCENT}; selection-color:#0b0814; }}
QLineEdit:focus {{ border:1px solid {ACCENT}; }}
QTabWidget::pane {{ border:0; }}
QTabBar {{ background:#0e0b1a; }}
QTabBar::tab {{ background:#15112a; color:#9a93b8; padding:7px 12px; margin:3px 2px 0 2px; border-top-left-radius:9px; border-top-right-radius:9px; min-width:90px; max-width:220px; }}
QTabBar::tab:selected {{ background:#26203f; color:#ffffff; border-bottom:2px solid {ACCENT}; }}
QTabBar::tab:hover {{ color:#ffffff; }}
QMenu {{ background:#17122b; border:1px solid #2e2750; padding:6px; }}
QMenu::item {{ padding:6px 22px; border-radius:6px; }}
QMenu::item:selected {{ background:#26203f; }}
QPushButton {{ background:#26203f; border:0; border-radius:8px; padding:7px 14px; }}
QPushButton:hover {{ background:#342c56; }}
QPushButton#primary {{ background:{ACCENT}; color:#0b0814; font-weight:bold; }}
QPushButton#primary:disabled {{ background:#3a4a40; color:#0b0814; }}
QListWidget, QTextEdit, QComboBox, QSpinBox {{ background:#17122b; border:1px solid #2e2750; border-radius:8px; padding:4px; }}
QProgressBar {{ background:#17122b; border:0; border-radius:3px; max-height:3px; }}
QProgressBar::chunk {{ background:{ACCENT}; border-radius:3px; }}
QStatusBar {{ background:#0e0b1a; color:#9a93b8; }}
QCheckBox {{ spacing:8px; }}
"""


def load_settings():
    d = dict(DEFAULTS)
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            d.update({k: v for k, v in json.load(f).items() if k in DEFAULTS})
    except Exception:
        pass
    if d["engine"] not in ENGINES:
        d["engine"] = "Google"
    return d


def save_json(path, data):
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=1)
        os.replace(tmp, path)
    except Exception:
        pass


def looks_like_url(text):
    t = text.strip()
    if not t or " " in t:
        return False
    if "://" in t or t.startswith(("about:", "view-source:", "file:", "localhost")):
        return True
    host = t.split("/")[0].split(":")[0]
    return "." in host and not host.startswith(".") and not host.endswith(".")


def to_url(text, engine):
    """Texto de la barra → dirección. Si no parece una web, se busca."""
    from urllib.parse import quote_plus
    t = text.strip()
    if t in ("", HOME):
        return HOME
    if looks_like_url(t):
        return t if "://" in t or t.startswith(("about:", "view-source:", "file:")) else "https://" + t
    return ENGINES[engine].format(quote_plus(t))


def unique_path(folder, name):
    base, ext = os.path.splitext(name or "descarga")
    path = os.path.join(folder, base + ext); n = 1
    while os.path.exists(path):
        path = os.path.join(folder, f"{base} ({n}){ext}"); n += 1
    return path


def human(n):
    n = float(n or 0)
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024 or u == "GB":
            return f"{n:.0f} {u}" if u == "B" else f"{n:.1f} {u}"
        n /= 1024


def home_html(engine):
    action = html.escape(ENGINES[engine].split("?")[0]); q = "q"
    return f"""<!doctype html><html lang="es"><meta charset="utf-8"><title>Inicio</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
html,body{{height:100%;margin:0}}body{{background:radial-gradient(circle at 50% 30%,#1d1638,#0e0b1a 70%);color:#eae6ff;
font:16px system-ui,sans-serif;display:flex;align-items:center;justify-content:center}}
.box{{text-align:center;width:min(620px,90vw)}}.z{{font-size:92px;font-weight:900;color:{ACCENT};
text-shadow:0 0 28px #8bf5a288;line-height:1}}h1{{margin:6px 0 26px;font-size:22px;letter-spacing:6px;color:#bfb8e0}}
input{{width:100%;box-sizing:border-box;padding:15px 22px;border-radius:28px;border:1px solid #2e2750;background:#17122b;
color:#fff;font-size:17px;outline:0}}input:focus{{border-color:{ACCENT};box-shadow:0 0 0 3px #8bf5a233}}
p{{color:#7d76a0;font-size:13px;margin-top:22px}}</style>
<div class="box"><div class="z">Z</div><h1>ZYH BROWSER</h1>
<form action="{action}" method="get"><input name="{q}" autofocus autocomplete="off" placeholder="Busca con {html.escape(engine)} o escribe una dirección"></form>
<p>ZYH Studios · gratis · versión {VERSION}</p></div></html>"""


def main():
    try:
        from PyQt6.QtCore import Qt, QUrl, QTimer, QSize
        from PyQt6.QtGui import QAction, QKeySequence, QShortcut, QDesktopServices, QIcon
        from PyQt6.QtWidgets import (QApplication, QMainWindow, QTabWidget, QToolBar, QLineEdit, QToolButton, QMenu,
                                     QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QListWidget, QListWidgetItem,
                                     QTextEdit, QCheckBox, QComboBox, QSpinBox, QFileDialog, QMessageBox, QProgressBar,
                                     QFormLayout, QWidget, QStatusBar)
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        from PyQt6.QtWebEngineCore import (QWebEnginePage, QWebEngineProfile, QWebEngineSettings, QWebEngineDownloadRequest,
                                           qWebEngineChromiumVersion)
        from PyQt6.QtCore import QT_VERSION_STR
    except ImportError as e:
        print(f"Falta Qt WebEngine ({e}). Ejecuta el instalador o:  pip install PyQt6 PyQt6-WebEngine")
        return 1
    import zyh_terms

    app = QApplication(sys.argv[:1])
    app.setApplicationName(APP); app.setApplicationVersion(VERSION); app.setStyleSheet(QSS)
    logo = os.path.join(HERE, "..", "logo.png")
    if os.path.isfile(logo):
        app.setWindowIcon(QIcon(logo))

    # ---------------------------------------------------------------- términos (si no se aceptan, no abre)
    def ask_terms():
        d = QDialog(); d.setWindowTitle(f"{APP} — Términos y condiciones"); d.resize(660, 600)
        lay = QVBoxLayout(d)
        t = QLabel(APP); t.setStyleSheet(f"font-size:22px;font-weight:bold;color:{ACCENT}"); lay.addWidget(t)
        lay.addWidget(QLabel("Lee y acepta los términos para usar el programa."))
        txt = QTextEdit(); txt.setReadOnly(True); txt.setPlainText(zyh_terms.TERMS); lay.addWidget(txt, 1)
        chk = QCheckBox("He leído y acepto los términos y condiciones"); lay.addWidget(chk)
        row = QHBoxLayout(); ok = QPushButton("Aceptar y continuar"); ok.setObjectName("primary"); ok.setEnabled(False)
        no = QPushButton("No acepto (salir)"); row.addWidget(ok); row.addWidget(no); row.addStretch(1); lay.addLayout(row)
        chk.toggled.connect(ok.setEnabled); ok.clicked.connect(d.accept); no.clicked.connect(d.reject)
        return d.exec() == QDialog.DialogCode.Accepted          # cerrar la ventana = no aceptar

    if not zyh_terms.is_accepted(APP):
        if not ask_terms():
            return 0
        zyh_terms.mark_accepted(APP)

    S = load_settings()
    os.makedirs(DATA_DIR, exist_ok=True)
    profile = QWebEngineProfile("zyh", app)                       # perfil persistente: las webs recuerdan la sesión
    profile.setPersistentStoragePath(os.path.join(DATA_DIR, "perfil"))
    profile.setCachePath(os.path.join(DATA_DIR, "cache"))
    profile.setPersistentCookiesPolicy(QWebEngineProfile.PersistentCookiesPolicy.ForcePersistentCookies)
    ua = " ".join(p for p in profile.httpUserAgent().split(" ") if not p.startswith("QtWebEngine/"))
    profile.setHttpUserAgent(ua)                                  # se presenta como Chromium normal: más webs lo aceptan
    st = profile.settings(); A = QWebEngineSettings.WebAttribute
    for name in ("JavascriptEnabled", "LocalStorageEnabled", "PluginsEnabled", "PdfViewerEnabled", "FullScreenSupportEnabled",
                 "JavascriptCanOpenWindows", "JavascriptCanAccessClipboard", "ScrollAnimatorEnabled", "WebGLEnabled",
                 "Accelerated2dCanvasEnabled", "DnsPrefetchEnabled", "ScreenCaptureEnabled", "AllowWindowActivationFromJavaScript"):
        if hasattr(A, name):
            st.setAttribute(getattr(A, name), True)

    class Page(QWebEnginePage):
        def __init__(self, win, view):
            super().__init__(profile, view); self.win = win

        def acceptNavigationRequest(self, url, nav_type, is_main):
            if url.scheme() in ("mailto", "tel", "sms", "magnet"):     # los abre la app del sistema
                QDesktopServices.openUrl(url); return False
            if url.scheme() == "zyh":
                if is_main:
                    QTimer.singleShot(0, lambda: self.win.load_home(self.view_ref()))
                return False
            return True

        def view_ref(self):
            return self.parent()

        def createWindow(self, _type):                                 # target=_blank / window.open → pestaña nueva
            return self.win.new_tab(None, switch=True).page()

    class View(QWebEngineView):
        def __init__(self, win):
            super().__init__(); self.is_home = False
            self.setPage(Page(win, self))

    class Browser(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle(APP); self.downloads = []; self.full = False
            g = S.get("geometry") or [1180, 760]
            self.resize(max(640, int(g[0])), max(440, int(g[1])))       # ventana normal: nunca arranca maximizada
            self.setMinimumSize(640, 440)
            self.tabs = QTabWidget(); self.tabs.setDocumentMode(True); self.tabs.setTabsClosable(True); self.tabs.setMovable(True)
            self.tabs.tabCloseRequested.connect(self.close_tab); self.tabs.currentChanged.connect(self.tab_changed)
            plus = QToolButton(); plus.setText("+"); plus.setToolTip("Nueva pestaña (Ctrl+T)"); plus.clicked.connect(lambda: self.new_tab(HOME))
            self.tabs.setCornerWidget(plus, Qt.Corner.TopRightCorner)
            self.setCentralWidget(self.tabs)
            self.bar = QToolBar(); self.bar.setMovable(False); self.bar.setIconSize(QSize(18, 18)); self.addToolBar(self.bar)

            def btn(text, tip, fn):
                b = QToolButton(); b.setText(text); b.setToolTip(tip); b.clicked.connect(fn); self.bar.addWidget(b); return b
            self.b_back = btn("←", "Atrás (Alt+←)", lambda: self.view().back())
            self.b_fwd = btn("→", "Adelante (Alt+→)", lambda: self.view().forward())
            self.b_reload = btn("⟳", "Recargar (F5)", self.reload_or_stop)
            btn("⌂", "Inicio", lambda: self.go(S["home"]))
            self.url = QLineEdit(); self.url.setPlaceholderText("Busca o escribe una dirección"); self.url.setClearButtonEnabled(True)
            self.url.returnPressed.connect(lambda: self.go(self.url.text())); self.bar.addWidget(self.url)
            self.b_dl = btn("⬇", "Descargas (Ctrl+J)", self.show_downloads)
            menu_b = QToolButton(); menu_b.setText("☰"); menu_b.setToolTip("Menú"); menu_b.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
            m = QMenu(self)
            for text, key, fn in [("Nueva pestaña", "Ctrl+T", lambda: self.new_tab(HOME)), ("Buscar en la página", "Ctrl+F", self.find),
                                  ("Acercar", "Ctrl++", lambda: self.zoom(+10)), ("Alejar", "Ctrl+-", lambda: self.zoom(-10)),
                                  ("Tamaño normal", "Ctrl+0", lambda: self.zoom(0)), ("Guardar página como PDF…", "", self.save_pdf),
                                  ("Descargas", "Ctrl+J", self.show_downloads), ("Ajustes", "", self.show_settings),
                                  ("Acerca de ZYH Browser", "", self.show_about), ("Salir", "Ctrl+Q", self.close)]:
                a = QAction(text, self); a.triggered.connect(fn)
                if key:
                    a.setShortcut(QKeySequence(key))
                m.addAction(a); self.addAction(a)
                if text in ("Buscar en la página", "Guardar página como PDF…", "Descargas"):
                    m.addSeparator()
            menu_b.setMenu(m); self.bar.addWidget(menu_b)
            self.prog = QProgressBar(); self.prog.setTextVisible(False); self.prog.setMaximumHeight(3)
            sb = QStatusBar(); self.setStatusBar(sb); sb.addPermanentWidget(self.prog, 1); sb.setSizeGripEnabled(False)
            self.findbar = QLineEdit(); self.findbar.setPlaceholderText("Buscar en la página (Enter = siguiente, Esc = cerrar)")
            self.findbar.setMaximumWidth(360); self.findbar.hide(); sb.addWidget(self.findbar)
            self.findbar.textChanged.connect(lambda t: self.view().findText(t)); self.findbar.returnPressed.connect(lambda: self.view().findText(self.findbar.text()))
            for key, fn in [("Ctrl+W", lambda: self.close_tab(self.tabs.currentIndex())), ("Ctrl+L", self.focus_url), ("F5", self.reload_or_stop),
                            ("Ctrl+R", self.reload_or_stop), ("Alt+Left", lambda: self.view().back()), ("Alt+Right", lambda: self.view().forward()),
                            ("Ctrl+Tab", lambda: self.tabs.setCurrentIndex((self.tabs.currentIndex() + 1) % self.tabs.count())),
                            ("Ctrl+=", lambda: self.zoom(+10)), ("F11", self.toggle_window_full), ("Escape", self.escape)]:
                QShortcut(QKeySequence(key), self, activated=fn)
            profile.downloadRequested.connect(self.on_download)
            urls = []
            if S["restore"]:
                try:
                    with open(SESSION, encoding="utf-8") as f:
                        urls = [u for u in json.load(f).get("tabs", []) if isinstance(u, str)][:30]
                except Exception:
                    urls = []
            for u in urls or [S["home"]]:
                self.new_tab(u, switch=False)
            self.tabs.setCurrentIndex(0)

        # ------------------------------------------------ pestañas
        def view(self):
            return self.tabs.currentWidget()

        def new_tab(self, url=HOME, switch=True):
            v = View(self); i = self.tabs.addTab(v, "Nueva pestaña")
            v.setZoomFactor(S["zoom"] / 100)
            v.titleChanged.connect(lambda t, v=v: self.set_title(v, t))
            v.iconChanged.connect(lambda ic, v=v: self.tabs.setTabIcon(self.tabs.indexOf(v), ic))
            v.urlChanged.connect(lambda u, v=v: self.url_changed(v, u))
            v.loadStarted.connect(lambda v=v: self.loading(v, True)); v.loadFinished.connect(lambda _ok, v=v: self.loading(v, False))
            v.loadProgress.connect(lambda p, v=v: self.prog.setValue(p) if v is self.view() else None)
            p = v.page()
            p.fullScreenRequested.connect(self.fullscreen_request)
            p.linkHovered.connect(lambda u: self.statusBar().showMessage(u, 3000) if u else self.statusBar().clearMessage())
            p.windowCloseRequested.connect(lambda v=v: self.close_tab(self.tabs.indexOf(v)))
            if hasattr(p, "permissionRequested"):                    # Qt 6.8+
                p.permissionRequested.connect(self.permission_new)
            else:
                p.featurePermissionRequested.connect(lambda origin, feat, p=p: self.permission_old(p, origin, feat))
            if switch:
                self.tabs.setCurrentIndex(i)
            if url:
                self.go(url, v)
            return v

        def close_tab(self, i):
            if i < 0:
                return
            v = self.tabs.widget(i)
            if self.tabs.count() == 1:
                self.close(); return
            self.tabs.removeTab(i); v.setPage(None); v.deleteLater()

        def set_title(self, v, title):
            i = self.tabs.indexOf(v)
            if i >= 0:
                t = "Inicio" if v.is_home else (title or "Sin título")
                self.tabs.setTabText(i, t if len(t) <= 26 else t[:25] + "…"); self.tabs.setTabToolTip(i, t)
            if v is self.view():
                self.setWindowTitle(f"{'Inicio' if v.is_home else title} — {APP}")

        def tab_changed(self, _i):
            v = self.view()
            if not v:
                return
            self.url.setText("" if v.is_home else v.url().toString()); self.url.setCursorPosition(0)
            self.update_nav(); self.set_title(v, v.title()); self.prog.setValue(0)

        def update_nav(self):
            v = self.view()
            if v:
                self.b_back.setEnabled(v.history().canGoBack()); self.b_fwd.setEnabled(v.history().canGoForward())

        # ------------------------------------------------ navegación
        def load_home(self, v):
            v.is_home = True
            v.setHtml(home_html(S["engine"]), QUrl("about:blank"))

        def go(self, text, v=None):
            v = v or self.view(); url = to_url(text, S["engine"])
            if url == HOME:
                self.load_home(v)
            else:
                v.is_home = False; v.load(QUrl.fromUserInput(url))
            v.setFocus()

        def url_changed(self, v, u):
            s = u.toString()
            if s not in ("about:blank", "") and not s.startswith("data:"):
                v.is_home = False
            if v is self.view():
                self.url.setText("" if v.is_home else s); self.url.setCursorPosition(0); self.update_nav()

        def loading(self, v, on):
            v.loading_now = on
            if v is self.view():
                self.b_reload.setText("✕" if on else "⟳"); self.update_nav()
                if not on:
                    QTimer.singleShot(400, lambda: self.prog.setValue(0))

        def reload_or_stop(self):
            v = self.view()
            if getattr(v, "loading_now", False):
                v.stop()
            elif v.is_home:
                self.load_home(v)
            else:
                v.reload()

        def focus_url(self):
            self.url.setFocus(); self.url.selectAll()

        def find(self):
            self.findbar.show(); self.findbar.setFocus(); self.findbar.selectAll()

        def escape(self):
            if self.findbar.isVisible():
                self.findbar.hide(); self.view().findText("")
            elif self.full:
                self.view().triggerPageAction(QWebEnginePage.WebAction.ExitFullScreen)

        def zoom(self, delta):
            v = self.view(); z = 100 if delta == 0 else max(30, min(300, round(v.zoomFactor() * 100) + delta))
            v.setZoomFactor(z / 100); self.statusBar().showMessage(f"Zoom {z} %", 1500)

        def save_pdf(self):
            path, _ = QFileDialog.getSaveFileName(self, "Guardar como PDF", os.path.join(S["downloads"], "pagina.pdf"), "PDF (*.pdf)")
            if path:
                self.view().page().printToPdf(path); self.statusBar().showMessage(f"PDF guardado: {path}", 4000)

        # ------------------------------------------------ pantalla completa (solo cuando la página la pide)
        def set_full(self, on):
            self.full = on; self.bar.setVisible(not on); self.tabs.tabBar().setVisible(not on); self.statusBar().setVisible(not on)
            cw = self.tabs.cornerWidget(Qt.Corner.TopRightCorner)
            if cw:
                cw.setVisible(not on)
            if on:
                self._was_max = self.isMaximized(); self.showFullScreen()
            else:
                self.showMaximized() if getattr(self, "_was_max", False) else self.showNormal()

        def fullscreen_request(self, req):
            req.accept(); self.set_full(req.toggleOn())

        def toggle_window_full(self):
            if self.full:
                self.view().triggerPageAction(QWebEnginePage.WebAction.ExitFullScreen); self.set_full(False)
            else:
                self.set_full(True)

        # ------------------------------------------------ permisos (cámara, micrófono, ubicación, avisos)
        def ask(self, origin, what):
            return QMessageBox.question(self, "Permiso", f"{origin}\n\nquiere usar: {what}.\n\n¿Permitir?") == QMessageBox.StandardButton.Yes

        def permission_new(self, perm):
            names = {"MediaAudioCapture": "el micrófono", "MediaVideoCapture": "la cámara", "MediaAudioVideoCapture": "la cámara y el micrófono",
                     "Geolocation": "tu ubicación", "Notifications": "notificaciones", "DesktopVideoCapture": "compartir tu pantalla",
                     "DesktopAudioVideoCapture": "compartir tu pantalla y audio", "ClipboardReadWrite": "el portapapeles",
                     "MouseLock": "bloquear el puntero", "LocalFontsAccess": "tus fuentes"}
            key = perm.permissionType().name
            if key == "MouseLock" or self.ask(perm.origin().toString(), names.get(key, key)):
                perm.grant()
            else:
                perm.deny()

        def permission_old(self, page, origin, feat):
            names = {"MediaAudioCapture": "el micrófono", "MediaVideoCapture": "la cámara", "MediaAudioVideoCapture": "la cámara y el micrófono",
                     "Geolocation": "tu ubicación", "Notifications": "notificaciones", "DesktopVideoCapture": "compartir tu pantalla",
                     "DesktopAudioVideoCapture": "compartir tu pantalla y audio", "MouseLock": "bloquear el puntero"}
            P = QWebEnginePage.PermissionPolicy
            ok = feat.name == "MouseLock" or self.ask(origin.toString(), names.get(feat.name, feat.name))
            page.setFeaturePermission(origin, feat, P.PermissionGrantedByUser if ok else P.PermissionDeniedByUser)

        # ------------------------------------------------ descargas
        def on_download(self, item):
            folder = S["downloads"]
            try:
                os.makedirs(folder, exist_ok=True)
            except Exception:
                folder = os.path.expanduser("~")
            path = unique_path(folder, os.path.basename(item.downloadFileName()))
            if S["ask_download"]:
                path, _ = QFileDialog.getSaveFileName(self, "Guardar descarga", path)
                if not path:
                    item.cancel(); return
            item.setDownloadDirectory(os.path.dirname(path)); item.setDownloadFileName(os.path.basename(path)); item.accept()
            d = {"item": item, "path": path, "name": os.path.basename(path), "t": time.time()}
            self.downloads.insert(0, d)
            item.receivedBytesChanged.connect(self.refresh_downloads); item.stateChanged.connect(lambda _s, d=d: self.download_state(d))
            self.statusBar().showMessage(f"Descargando {d['name']}…", 4000); self.b_dl.setText("⬇•"); self.refresh_downloads()

        def download_state(self, d):
            try:
                self._download_state(d)
            except RuntimeError:
                pass            # la ventana ya se cerró: no hay nada que actualizar

        def _download_state(self, d):
            DS = QWebEngineDownloadRequest.DownloadState
            if d["item"].state() == DS.DownloadCompleted:
                self.statusBar().showMessage(f"Descarga lista: {d['name']}", 6000)
            elif d["item"].state() == DS.DownloadInterrupted:
                self.statusBar().showMessage(f"Descarga fallida: {d['name']} ({d['item'].interruptReasonString()})", 8000)
            if not any(x["item"].state() == DS.DownloadInProgress for x in self.downloads):
                self.b_dl.setText("⬇")
            self.refresh_downloads()

        def download_text(self, d):
            DS = QWebEngineDownloadRequest.DownloadState; it = d["item"]; s = it.state()
            if s == DS.DownloadCompleted:
                info = f"completa · {human(it.receivedBytes())}"
            elif s == DS.DownloadInProgress:
                tot = it.totalBytes()
                info = f"{human(it.receivedBytes())}" + (f" de {human(tot)} · {100 * it.receivedBytes() // tot} %" if tot > 0 else "")
            elif s == DS.DownloadCancelled:
                info = "cancelada"
            elif s == DS.DownloadInterrupted:
                info = "falló: " + it.interruptReasonString()
            else:
                info = "en espera"
            return f"{d['name']}\n{info}"

        def refresh_downloads(self, *_):
            lst = getattr(self, "_dl_list", None)
            if lst is None:
                return
            try:
                if not self.isVisible() and not lst.isVisible():
                    return
                if lst.count() != len(self.downloads):
                    lst.clear()
                    for d in self.downloads:
                        lst.addItem(QListWidgetItem(self.download_text(d)))
                else:
                    for i, d in enumerate(self.downloads):
                        lst.item(i).setText(self.download_text(d))
            except RuntimeError:
                self._dl_list = None

        def show_downloads(self):
            d = QDialog(self); d.setWindowTitle("Descargas"); d.resize(520, 420); lay = QVBoxLayout(d)
            lay.addWidget(QLabel(f"Carpeta: {S['downloads']}"))
            lst = QListWidget(); lay.addWidget(lst, 1); self._dl_list = lst; self.refresh_downloads()
            if not self.downloads:
                lay.addWidget(QLabel("Aún no has descargado nada en esta sesión."))
            row = QHBoxLayout(); lay.addLayout(row)

            def sel():
                i = lst.currentRow()
                return self.downloads[i] if 0 <= i < len(self.downloads) else None

            def open_file():
                x = sel()
                if x and os.path.exists(x["path"]):
                    QDesktopServices.openUrl(QUrl.fromLocalFile(x["path"]))

            def cancel():
                x = sel()
                if x:
                    x["item"].cancel()
            for text, fn in [("Abrir archivo", open_file), ("Abrir carpeta", lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(S["downloads"]))),
                             ("Cancelar descarga", cancel)]:
                b = QPushButton(text); b.clicked.connect(fn); row.addWidget(b)
            row.addStretch(1); lst.itemDoubleClicked.connect(lambda _i: open_file())
            d.finished.connect(lambda _r: setattr(self, "_dl_list", None)); d.show()

        # ------------------------------------------------ ajustes y acerca de
        def show_settings(self):
            d = QDialog(self); d.setWindowTitle("Ajustes"); d.resize(520, 380); lay = QVBoxLayout(d); form = QFormLayout(); lay.addLayout(form)
            home = QLineEdit(S["home"]); form.addRow("Página de inicio", home)
            eng = QComboBox(); eng.addItems(list(ENGINES)); eng.setCurrentText(S["engine"]); form.addRow("Buscador", eng)
            dl = QLineEdit(S["downloads"]); pick = QPushButton("Elegir…")
            pick.clicked.connect(lambda: dl.setText(QFileDialog.getExistingDirectory(d, "Carpeta de descargas", dl.text()) or dl.text()))
            r = QHBoxLayout(); r.addWidget(dl); r.addWidget(pick); w = QWidget(); w.setLayout(r); r.setContentsMargins(0, 0, 0, 0)
            form.addRow("Carpeta de descargas", w)
            ask = QCheckBox("Preguntar dónde guardar cada descarga"); ask.setChecked(S["ask_download"]); form.addRow("", ask)
            rest = QCheckBox("Al abrir, restaurar las pestañas de la última vez"); rest.setChecked(S["restore"]); form.addRow("", rest)
            zoom = QSpinBox(); zoom.setRange(30, 300); zoom.setSingleStep(10); zoom.setSuffix(" %"); zoom.setValue(int(S["zoom"])); form.addRow("Zoom por defecto", zoom)
            clear = QPushButton("Borrar datos de navegación (cookies y caché)")

            def do_clear():
                if QMessageBox.question(d, "Borrar datos", "Se cerrarán tus sesiones en las webs. ¿Continuar?") == QMessageBox.StandardButton.Yes:
                    profile.cookieStore().deleteAllCookies(); profile.clearHttpCache(); profile.clearAllVisitedLinks()
                    self.statusBar().showMessage("Datos de navegación borrados.", 4000)
            clear.clicked.connect(do_clear); lay.addWidget(clear); lay.addStretch(1)
            row = QHBoxLayout(); lay.addLayout(row); row.addStretch(1)
            ok = QPushButton("Guardar"); ok.setObjectName("primary"); cancel = QPushButton("Cancelar"); row.addWidget(cancel); row.addWidget(ok)

            def save():
                S.update(home=home.text().strip() or HOME, engine=eng.currentText(), downloads=dl.text().strip() or DEFAULTS["downloads"],
                         ask_download=ask.isChecked(), restore=rest.isChecked(), zoom=zoom.value())
                save_json(SETTINGS, S); d.accept(); self.statusBar().showMessage("Ajustes guardados.", 3000)
            ok.clicked.connect(save); cancel.clicked.connect(d.reject); d.exec()

        def show_about(self):
            d = QDialog(self); d.setWindowTitle("Acerca de ZYH Browser"); d.resize(440, 330); lay = QVBoxLayout(d)
            z = QLabel("Z"); z.setAlignment(Qt.AlignmentFlag.AlignCenter); z.setStyleSheet(f"font-size:64px;font-weight:900;color:{ACCENT}"); lay.addWidget(z)
            t = QLabel(f"<b style='font-size:18px'>{APP}</b><br>Versión {VERSION}<br><br>Navegador gratuito de ZYH Studios.<br>"
                       f"Motor: Qt WebEngine {QT_VERSION_STR} (Chromium {qWebEngineChromiumVersion()}), código abierto.<br><br>"
                       "Tus datos de navegación se guardan solo en este equipo.<br>© ZYH Studios")
            t.setAlignment(Qt.AlignmentFlag.AlignCenter); t.setWordWrap(True); lay.addWidget(t, 1)
            row = QHBoxLayout(); lay.addLayout(row); row.addStretch(1)
            terms = QPushButton("Ver términos"); close = QPushButton("Cerrar"); close.setObjectName("primary"); row.addWidget(terms); row.addWidget(close); row.addStretch(1)

            def show_terms():
                x = QDialog(d); x.setWindowTitle("Términos y condiciones"); x.resize(620, 520); l = QVBoxLayout(x)
                te = QTextEdit(); te.setReadOnly(True); te.setPlainText(zyh_terms.TERMS); l.addWidget(te); x.exec()
            terms.clicked.connect(show_terms); close.clicked.connect(d.accept); d.exec()

        def closeEvent(self, e):
            self._dl_list = None
            try:
                profile.downloadRequested.disconnect(self.on_download)
            except Exception:
                pass
            urls = [HOME if self.tabs.widget(i).is_home else self.tabs.widget(i).url().toString() for i in range(self.tabs.count())]
            save_json(SESSION, {"tabs": [u for u in urls if u and not u.startswith("data:")]})
            if not self.isMaximized() and not self.isFullScreen():
                S["geometry"] = [self.width(), self.height()]
            save_json(SETTINGS, S)
            e.accept()

    win = Browser(); win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
