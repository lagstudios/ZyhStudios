# -*- coding: utf-8 -*-
"""Prueba Lite de ZYH Compressor (núcleo protegido).

Lite = solo el nivel de compresión 1, durante 5 usos o 5 días (lo que pase primero). Es UNA por equipo y por
cuenta: el servidor la lleva por la ID del equipo (hash), y además queda una copia cifrada en las mismas
carpetas protegidas donde vive la ID del equipo, para que borrar la app o crear otra cuenta no la reinicie.
"""
import os, time

from . import deviceid, store

LITE = {"compressor": {"uses": 5, "days": 5, "level_max": 1}}
_FILE = ".zt"


def _paths():
    seen, out = set(), []
    for m in deviceid._mirrors():
        p = os.path.join(os.path.dirname(m), _FILE)
        if p not in seen:
            seen.add(p); out.append(p)
    return out


def _load(product):
    """Junta todas las copias locales: gana lo más gastado (más usos, inicio más antiguo)."""
    best = {"uses": 0, "started": 0, "last": 0, "ended": False}
    for p in _paths():
        d = (store.load(p, {}) or {}).get(product)
        if not isinstance(d, dict):
            continue
        best["uses"] = max(best["uses"], int(d.get("uses", 0)))
        st = int(d.get("started", 0))
        if st and (not best["started"] or st < best["started"]):
            best["started"] = st
        best["last"] = max(best["last"], int(d.get("last", 0)))
        best["ended"] = best["ended"] or bool(d.get("ended"))
    return best


def _save(product, d):
    for p in _paths():
        try:
            allp = store.load(p, {}) or {}
            allp[product] = d
            store.save(p, allp)
            if os.name == "nt":
                try:
                    import subprocess
                    subprocess.run(["attrib", "+h", "+s", p], capture_output=True, timeout=4)
                except Exception:
                    pass
        except Exception:
            pass


def _state(product, d):
    cfg = LITE[product]
    t = time.time()
    tampered = d["last"] and t < d["last"] - 86400          # reloj atrasado a propósito
    ended = d["ended"] or tampered or d["uses"] >= cfg["uses"] or (d["started"] and t > d["started"] + cfg["days"] * 86400)
    days_left = cfg["days"] if not d["started"] else max(0, int((d["started"] + cfg["days"] * 86400 - t) / 86400) + 1)
    return {"ok": not ended, "level_max": cfg["level_max"], "uses_left": 0 if ended else max(0, cfg["uses"] - d["uses"]),
            "days_left": 0 if ended else days_left, "reason": "prueba_terminada" if ended else ""}


def check(product):
    """Estado de la prueba SIN gastar un uso."""
    if product not in LITE:
        return {"ok": False, "reason": "sin_prueba", "level_max": 0, "uses_left": 0, "days_left": 0}
    return _state(product, _load(product))


def use(product):
    """Gasta un uso (comprimir o extraer). Devuelve el estado; ok=False = prueba terminada o no permitida."""
    if product not in LITE:
        return {"ok": False, "reason": "sin_prueba", "level_max": 0, "uses_left": 0, "days_left": 0}
    cfg = LITE[product]
    d = _load(product)
    cur = _state(product, d)
    if not cur["ok"]:
        d["ended"] = True; _save(product, d); return cur
    remote = None
    try:
        from . import account
        remote = account.trial(product, consume=True)         # None = sin cuenta/sin internet
    except Exception:
        remote = None
    if remote is not None and not remote.get("ok"):           # el servidor dice que este equipo o cuenta ya la usó
        d["ended"] = True; d["uses"] = cfg["uses"]; _save(product, d)
        return {**_state(product, d), "reason": remote.get("reason") or "prueba_terminada"}
    now = int(time.time())
    d["uses"] += 1
    if remote is not None:
        d["uses"] = max(d["uses"], cfg["uses"] - int(remote.get("uses_left", cfg["uses"])))
    d["started"] = d["started"] or now
    d["last"] = now
    _save(product, d)
    st = _state(product, d)
    # Este uso SÍ se permite (aunque sea el último); el siguiente ya no.
    return {**st, "ok": True, "reason": "", "uses_left": max(0, cfg["uses"] - d["uses"])}
