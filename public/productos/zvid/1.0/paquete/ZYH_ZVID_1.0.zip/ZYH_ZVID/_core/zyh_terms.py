# -*- coding: utf-8 -*-
"""ZYH Studios — Términos y condiciones al iniciar (distintos para cada app).

require("ZYH Compressor") muestra los términos de ESA app con el botón «Aceptar y continuar».
Si la persona cierra la ventana o pulsa «Salir», el programa se cierra. Si acepta, pasa a la
pantalla de cuenta ZYH (registrarse o iniciar sesión) y luego sigue la app. La aceptación se
recuerda por programa y se vuelve a pedir cuando cambia TERMS_VERSION.
"""
import os, sys, json, time

TERMS_VERSION = "2026-11b"
ASK_EVERY_START = False
STORE = os.path.join(os.path.expanduser("~"), ".config", "zyh", "terms.json")

# ------------------------------------------------------------------ cláusulas comunes a todas las apps
_COMMON_HEAD = """TÉRMINOS Y CONDICIONES — {app}

1. Licencia de uso. ZYH Studios te concede una licencia personal e intransferible para usar {app}, según el plan que tengas y el número de equipos que cubre.

2. Cuenta ZYH obligatoria. Para usar la app debes registrarte o iniciar sesión con tu cuenta ZYH. La cuenta es personal: no la compartas ni la vendas. Crear varias cuentas para repetir pruebas gratis o evitar pagar un plan es un incumplimiento.
"""
_COMMON_TAIL = """NO CAMBIAR EL CÓDIGO. Está prohibido modificar, descompilar, parchear, desarmar, copiar o redistribuir el programa, su código o su sistema de licencias, ni cambiar lo que la app envía o recibe de la web de ZYH.

NO OBTENER PLANES DE SITIOS NO AUTORIZADOS. Los planes de pago solo se obtienen desde la web oficial de ZyhStudios (pagos con PayPal) o los entrega el equipo de ZYH desde su administración. Cualquier plan, clave, cuenta o activación comprada o conseguida en otro sitio, grupo, vendedor o programa (cracks, generadores de claves, cuentas robadas) no es válida y se anula sin reembolso.

IDENTIFICADOR DEL EQUIPO. La app guarda un identificador cifrado del equipo en carpetas protegidas del sistema. Sirve solo para validar tu plan y tu prueba gratis en este equipo; no contiene tus datos personales y a la web solo se envía un hash. Borrar, mover, alterar o copiar esos archivos para saltarte los límites termina la licencia.

Incumplir estas reglas termina la licencia de inmediato, bloquea la cuenta y puede acarrear responsabilidad legal.

Garantía. El software se entrega "tal cual", sin garantía de estar libre de errores. ZYH Studios no responde por daños indirectos derivados del uso.

Cambios. ZYH Studios puede actualizar estos términos y las funciones de la app en futuras versiones; cuando cambien, se te pedirá aceptarlos de nuevo.

Al pulsar «Aceptar y continuar» aceptas estos términos.
© ZYH Studios."""

_APP_TERMS = {
    "ZYH Compressor": """3. Planes y prueba Lite. ZYH Compressor tiene una prueba gratis llamada Lite: solo el nivel de compresión 1 (Rápida) y dura 5 usos (cada compresión o extracción cuenta como un uso) o 5 días, lo que ocurra primero. La prueba es una sola por equipo y por cuenta: borrar la app, crear otra cuenta o limpiar archivos no la reinicia. Después hay que pagar un plan (Pro, V-Pro o V-Pro+), que se cobra por mes por adelantado a través de PayPal en la web de ZyhStudios; los precios están en dólares.

4. Archivos .zyh. Comprime y extrae solo archivos que tengas derecho a usar. Verifica tus copias: ZYH Studios no responde por archivos perdidos o dañados; conserva siempre el original hasta comprobar el resultado.

5. Equipos. Cada plan cubre un número de equipos; los equipos adicionales tienen costo extra.
""",
    "ZYH Business": """3. Planes. ZYH Business se cobra por mes por adelantado (Pro, V-Pro, V-Pro+) a través de PayPal en la web de ZyhStudios; los precios están en dólares. Cada plan cubre un número de equipos y de mensajes de IA al día.

4. WhatsApp e IA. La atención automatizada usa la API oficial de WhatsApp Business (Meta) y Google Gemini, con credenciales que tú provees. Debes cumplir las políticas de Meta y de Google; ZYH Studios no se hace responsable de suspensiones de tu cuenta por mal uso ni de lo que la IA responda a tus clientes: revisa tus precios, tu stock y tus respuestas. Las extensiones creadas por la IA son solo configuración; revisa lo que instalas.

5. Datos de tu negocio. La edición local guarda los datos en tu equipo (cifrados en formato .zyhd). Eres responsable de respaldarlos y de cumplir la ley de datos de tu país con tus clientes. El lector de códigos de barras con cámara procesa la imagen solo en tu equipo.
""",
    "ZYH Bridged": """3. Planes. ZYH Bridged se cobra por fin de semana por adelantado (Fin de semana con amigos, Bridged On, Bridged Server) a través de PayPal en la web de ZyhStudios; los precios están en dólares. El plan cubre cierto número de amigos conectados al mismo tiempo.

4. Minecraft. ZYH Bridged no es un producto de Mojang ni de Microsoft y no está afiliado a ellos. Necesitas tu propia copia legal del juego.

5. Uso de la red. El puente conecta equipos de personas que se conocen y se aceptan entre sí, con cifrado de extremo a extremo. No lo uses para atacar, espiar, saturar ni entrar a equipos o servidores sin permiso, ni para ocultar actividades ilegales. Eres responsable de lo que se haga desde tu conexión y de abrir puertos o UPnP solo si lo entiendes.
""",
    "ZYH Browser": """3. App gratuita. ZYH Browser es gratis. Lo que visitas, descargas o escribes en internet es tu responsabilidad; ZYH Studios no controla los sitios que abras ni su contenido.

4. Motor y marcas. Usa un motor de código abierto (no Chromium) con sus propias licencias. ZYH Browser no está afiliado a otros navegadores ni a las webs que abras.

5. Datos del navegador. Historial, descargas y sesiones se guardan en tu equipo; protégelo con tu clave del sistema y no uses el navegador en equipos ajenos sin cerrar sesión.
""",
    "ZYH ZVID": """3. App gratuita. ZYH ZVID es gratis y convierte videos MP4 al formato .zvid para la pantalla del ZYHT32.

4. Tus videos. Convierte solo videos que tengas derecho a usar. ZYH Studios no se hace responsable por contenido protegido por derechos de autor que conviertas o muestres en tu dispositivo.

5. Formato. El formato .zvid puede cambiar entre versiones; conserva tu video original.
""",
    "ZYHT32 IDE": """3. App gratuita. ZYHT32 IDE es gratis: edita, compila y sube código a tu ZYHT32.

4. Flashear la placa. Flashear firmware o cambiar particiones puede dejar una placa inutilizable si se interrumpe o se elige mal; lo haces bajo tu responsabilidad. Los códigos oficiales importados conservan su licencia original.

5. Tu código. El código que escribes es tuyo; no subas a la web ni compartas claves (Wi-Fi, API) dentro de proyectos que publiques.
""",
}
_ALIASES = {"ZYH Bridger": "ZYH Bridged", "ZYHT32": "ZYHT32 IDE", "ZYHT32 IDE": "ZYHT32 IDE"}


def terms_for(app):
    app = _ALIASES.get(app, app)
    return _COMMON_HEAD.format(app=app) + "\n" + _APP_TERMS.get(app, "") + "\n" + _COMMON_TAIL


TERMS = terms_for("ZYH Studios")          # texto general (compatibilidad)


# ------------------------------------------------------------------ aceptación guardada
def _load():
    try:
        with open(STORE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def is_accepted(app):
    if ASK_EVERY_START:
        return False
    d = _load()
    return d.get("version") == TERMS_VERSION and app in d.get("apps", {})


def mark_accepted(app):
    d = _load()
    if d.get("version") != TERMS_VERSION:
        d = {"version": TERMS_VERSION, "apps": {}}
    d.setdefault("apps", {})[app] = time.strftime("%Y-%m-%d %H:%M")
    try:
        os.makedirs(os.path.dirname(STORE), exist_ok=True)
        with open(STORE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass   # si no se puede guardar, se volverá a preguntar


def _tk_dialog(app, accent="#8bf5a2"):
    """True = aceptó · False = salió o cerró · None = no hay tkinter/pantalla."""
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:
        return None
    bg, panel, fg = "#0e0b1a", "#17122b", "#eae6ff"
    root.title(f"{app} — Términos y condiciones"); root.configure(bg=bg)
    w, h = 680, 640
    root.geometry(f"{w}x{h}+{max(0, (root.winfo_screenwidth() - w) // 2)}+{max(0, (root.winfo_screenheight() - h) // 3)}")
    root.minsize(520, 460)
    res = {"ok": False}

    def accept():
        res["ok"] = True; root.destroy()

    # Los botones se colocan PRIMERO abajo, así nunca quedan fuera de la ventana aunque sea pequeña.
    row = tk.Frame(root, bg=bg); row.pack(side="bottom", fill="x", padx=18, pady=(8, 16))
    tk.Button(row, text="Aceptar y continuar", bg=accent, fg="#0b0814", activebackground=accent, relief="flat",
              padx=22, pady=8, font=("Helvetica", 12, "bold"), command=accept).pack(side="left")
    tk.Button(row, text="Salir", bg="#2a2342", fg=fg, activebackground="#3a3158", activeforeground=fg, relief="flat",
              padx=22, pady=8, font=("Helvetica", 12), command=root.destroy).pack(side="left", padx=10)
    tk.Label(root, text=app, bg=bg, fg=accent, font=("Helvetica", 18, "bold")).pack(side="top", anchor="w", padx=18, pady=(14, 0))
    tk.Label(root, text="Lee los términos. Para usar el programa pulsa «Aceptar y continuar».", bg=bg, fg="#9a93b8").pack(side="top", anchor="w", padx=18, pady=(0, 8))
    box = tk.Frame(root, bg=panel); box.pack(side="top", fill="both", expand=True, padx=18)
    sb = tk.Scrollbar(box); sb.pack(side="right", fill="y")
    txt = tk.Text(box, wrap="word", bg=panel, fg=fg, relief="flat", padx=12, pady=10, yscrollcommand=sb.set,
                  font=("Helvetica", 11), spacing3=6, insertbackground=panel)
    txt.pack(fill="both", expand=True); sb.config(command=txt.yview)
    txt.insert("1.0", terms_for(app)); txt.config(state="disabled")
    root.protocol("WM_DELETE_WINDOW", root.destroy)     # cerrar la ventana = no aceptar
    root.bind("<Escape>", lambda _e: root.destroy())
    root.bind("<Return>", lambda _e: accept())
    root.lift(); root.focus_force(); root.mainloop()
    return res["ok"]


def require(app, accent="#8bf5a2", account=True):
    """Llamar al inicio de cada programa: términos de la app y luego cuenta ZYH. Si no, termina el proceso."""
    if not is_accepted(app):
        r = _tk_dialog(app, accent)
        if r is None:
            sys.stderr.write("No se pudo mostrar los términos (falta tkinter o pantalla). El programa no puede iniciar.\n")
            sys.exit(1)
        if not r:
            sys.exit(0)
        mark_accepted(app)
    if account:
        require_account(app, accent)
    return True


def require_account(app, accent="#8bf5a2"):
    """Pantalla «Regístrate o inicia sesión con tu cuenta ZYH». Sale del programa si no se entra."""
    try:
        import zyh_gate
    except Exception as exc:
        sys.stderr.write(f"No se pudo cargar la pantalla de cuenta ZYH ({exc}).\n"); sys.exit(1)
    if not zyh_gate.require(app, accent):
        sys.exit(0)
    return True
