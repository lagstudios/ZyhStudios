# -*- coding: utf-8 -*-
"""Catálogo de planes ZYH (fuente única de precios y límites).
Precios en USD. COP mostrado solo de referencia (~4000 COP/USD)."""

PRODUCTS = {
    "browser": {
        "name": "ZYH Browser",
        "free": True,
        "plans": {"free": {"label": "Gratis", "usd": 0, "devices": 9999, "features": ["navegacion"]}},
    },
    "compressor": {
        "name": "ZYH Compressor",
        "lite": {"uses": 5, "days": 5, "level_max": 1},      # prueba gratis: solo nivel 1, 5 usos o 5 días (una por equipo)
        "plans": {
            "pro":    {"label": "Pro",     "usd": 4.62,  "cycle": "mes", "devices": 1,  "extra_usd": 0,
                       "features": ["comprimir", "extraer", "modo_rapido", "modo_medio", "modo_alto"]},
            "vpro":   {"label": "V-Pro",   "usd": 7.69,  "cycle": "mes", "devices": 9,  "extra_usd": 1.23,
                       "features": ["comprimir", "extraer", "modo_rapido", "modo_medio", "modo_alto", "lote", "cli"]},
            "vpro_plus":{"label": "V-Pro+","usd": 15.38, "cycle": "mes", "devices": 999,"extra_usd": 3.08,
                       "features": ["comprimir", "extraer", "modo_rapido", "modo_medio", "modo_alto", "lote", "cli", "prioridad"]},
        },
    },
    "business": {
        "name": "ZYH Business",
        "plans": {
            "pro":     {"label": "Pro",    "usd": 4.62, "cycle": "mes", "devices": 4,  "extra_usd": 0,
                        "features": ["gestion", "ia_basica"], "ia_msgs_dia": 80},
            "vpro":    {"label": "V-Pro",  "usd": 6.15, "cycle": "mes", "devices": 9,  "extra_usd": 1.54,
                        "features": ["gestion", "ia_completa", "whatsapp"], "ia_msgs_dia": 1000},
            "vpro_plus":{"label": "V-Pro+","usd": 7.69, "cycle": "mes", "devices": 999,"extra_usd": 2.46,
                        "features": ["gestion", "ia_completa", "whatsapp", "prioridad"], "ia_msgs_dia": 100000},
        },
    },
    "bridged": {
        "name": "ZYH Bridged",
        "plans": {
            "bridged": {"label": "Fin de semana con amigos", "usd": 4.31,  "cycle": "finde", "devices": 4,  "extra_usd": 1.0,
                        "features": ["puente", "cifrado"]},
            "bridged_on":{"label": "Bridged On",  "usd": 6.15,  "cycle": "finde", "devices": 8,  "extra_usd": 1.0,
                        "features": ["puente", "cifrado", "upnp"]},
            "bridged_server":{"label": "Bridged Server","usd": 18.46,"cycle": "finde","devices": 999,"extra_usd": 1.0,
                        "features": ["puente", "cifrado", "upnp", "dedicado"], "monthly_usd": 24},
        },
    },
}

def plan(product, plan_id):
    return PRODUCTS[product]["plans"][plan_id]

def all_plan_ids(product):
    return list(PRODUCTS[product]["plans"].keys())

def top_plan(product):
    return all_plan_ids(product)[-1]
