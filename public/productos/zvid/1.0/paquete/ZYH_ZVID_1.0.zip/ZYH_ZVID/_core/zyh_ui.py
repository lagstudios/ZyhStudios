# -*- coding: utf-8 -*-
"""ZYH UI Kit — look bonito y animado compartido por todas las apps (CustomTkinter).

Da a cada app:
  • fondo animado (fondo de pantalla + partículas + brillo que se mueve)
  • cabecera con logo ZYH y badge de plan
  • botones con brillo al pasar el mouse (animados)
  • panel "Personalizar": color de acento, color de fondo, fondo de pantalla,
    iluminación on/off, y modo de bajo consumo.
Los ajustes se guardan por app en ~/.config/zyh/<slug>/ui.json

Requiere: customtkinter, pillow
"""
import os, json, math, random, colorsys
import tkinter as tk
import customtkinter as ctk
from PIL import Image, ImageDraw, ImageFilter, ImageTk

# -------------------------------------------------------------------- paleta
ACCENTS = {
    "Lima":   "#b6f500",
    "Cian":   "#38d6ff",
    "Verde":  "#8bf5a2",
    "Ámbar":  "#ffd23f",
    "Rosa":   "#ff5c8a",
    "Violeta":"#9b6cff",
}
WALLPAPERS = ["Aurora", "Neón", "Noche", "Z lima", "Sólido"]

ctk.set_appearance_mode("dark")


def _hex(c):
    c = c.lstrip("#"); return tuple(int(c[i:i+2], 16) for i in (0, 2, 4))


def _lighten(hexc, f):
    r, g, b = _hex(hexc); h, l, s = colorsys.rgb_to_hls(r/255, g/255, b/255)
    l = max(0, min(1, l + f)); r, g, b = colorsys.hls_to_rgb(h, l, s)
    return f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"


# -------------------------------------------------------------------- ajustes
def cfg_path(slug):
    d = os.path.join(os.path.expanduser("~"), ".config", "zyh", slug)
    os.makedirs(d, exist_ok=True)
    return os.path.join(d, "ui.json")


def load_ui(slug, accent="#b6f500"):
    d = {"accent": accent, "bg": "#0b0814", "wallpaper": "Aurora",
         "lighting": True, "low_cpu": False}
    try:
        d.update(json.load(open(cfg_path(slug))))
    except Exception:
        pass
    return d


def save_ui(slug, ui):
    try:
        json.dump(ui, open(cfg_path(slug), "w"), indent=2)
    except Exception:
        pass


# -------------------------------------------------------------------- wallpapers
def make_wallpaper(kind, bg, accent, size=(1200, 820)):
    w, h = size
    base = _hex(bg)
    img = Image.new("RGB", size, base)
    if kind == "Sólido":
        return img
    d = ImageDraw.Draw(img, "RGBA")
    if kind == "Aurora":
        cols = [accent, "#9b6cff", "#38d6ff"]
    elif kind == "Neón":
        cols = ["#38d6ff", "#ff5c8a", "#9b6cff"]
    elif kind == "Noche":
        cols = ["#1b2250", "#101030", accent]
    else:  # Z lima
        cols = ["#b6f500", "#2a7a00", "#38d6ff"]
    for i, c in enumerate(cols):
        cx = int(w * (0.2 + 0.3 * i)); cy = int(h * (0.15 + 0.25 * i))
        rr = int(w * 0.55)
        for r in range(rr, 0, -8):
            a = int(60 * (r / rr) ** 0.4 * 0.5)
            col = _hex(c) + (max(0, 46 - int(46 * r / rr)),)
            d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=col)
    img = img.filter(ImageFilter.GaussianBlur(60))
    # viñeta
    vg = Image.new("L", size, 0); dv = ImageDraw.Draw(vg)
    dv.ellipse((-w*0.2, -h*0.2, w*1.2, h*1.2), fill=120)
    vg = vg.filter(ImageFilter.GaussianBlur(120))
    dark = Image.new("RGB", size, base)
    img = Image.composite(img, dark, vg)
    return img


# -------------------------------------------------------------------- fondo animado
class AnimatedBG:
    def __init__(self, root, ui):
        self.root = root
        self.ui = ui
        self.canvas = tk.Canvas(root, highlightthickness=0, bd=0, bg=ui["bg"])
        self.canvas.place(x=0, y=0, relwidth=1, relheight=1)
        self._wp_img = None
        self._wp_id = None
        self._particles = []
        self._glow = None
        self._t = 0
        self._size = (0, 0)
        self.rebuild()
        self.canvas.bind("<Configure>", self._on_resize)
        self._tick()

    def _on_resize(self, e):
        if (e.width, e.height) != self._size:
            self._size = (e.width, e.height)
            self.rebuild()

    def rebuild(self):
        self.canvas.configure(bg=self.ui["bg"])
        w = max(self.canvas.winfo_width(), self.root.winfo_width(), 400)
        h = max(self.canvas.winfo_height(), self.root.winfo_height(), 400)
        wp = make_wallpaper(self.ui["wallpaper"], self.ui["bg"], self.ui["accent"], (w, h))
        self._wp_img = ImageTk.PhotoImage(wp)
        self.canvas.delete("all")
        self._wp_id = self.canvas.create_image(0, 0, anchor="nw", image=self._wp_img)
        n = 0 if self.ui["low_cpu"] else 42
        self._particles = [[random.uniform(0, w), random.uniform(0, h),
                            random.uniform(.3, 1.6), random.uniform(.2, .9)] for _ in range(n)]
        self._pdots = [self.canvas.create_oval(0, 0, 0, 0, fill=self.ui["accent"], outline="")
                       for _ in self._particles]
        if self.ui["lighting"]:
            self._glow = self.canvas.create_oval(0, 0, 0, 0, outline="", fill="")

    def _tick(self):
        w = self.canvas.winfo_width() or 400
        h = self.canvas.winfo_height() or 400
        self._t += 1
        for i, p in enumerate(self._particles):
            p[1] -= p[2] * 0.6
            p[0] += math.sin((self._t + i * 20) / 60) * 0.4
            if p[1] < -5:
                p[1] = h + 5; p[0] = random.uniform(0, w)
            r = p[2] * 1.8
            self.canvas.coords(self._pdots[i], p[0]-r, p[1]-r, p[0]+r, p[1]+r)
            self.canvas.itemconfig(self._pdots[i], fill=_lighten(self.ui["accent"], -0.1))
        delay = 55 if self.ui["low_cpu"] else 33
        self.root.after(delay, self._tick)


# -------------------------------------------------------------------- botón con brillo
class GlowButton(ctk.CTkButton):
    def __init__(self, master, accent="#b6f500", text_color="#0b0814", height=40, **kw):
        self._accent = accent
        kw.setdefault("corner_radius", 12)
        kw.setdefault("font", ctk.CTkFont("DejaVu Sans", 13, "bold"))
        super().__init__(master, fg_color=accent, hover_color=_lighten(accent, 0.12),
                         text_color=text_color, height=height, **kw)


def accent_font(size=13, bold=True):
    return ctk.CTkFont("DejaVu Sans", size, "bold" if bold else "normal")


# -------------------------------------------------------------------- shell
class ZYHShell:
    """Ventana base: fondo animado + cabecera + área de contenido transparente."""
    def __init__(self, title, slug, plan_label="", accent="#b6f500", size=(880, 620)):
        self.slug = slug
        self.ui = load_ui(slug, accent)
        self.root = ctk.CTk()
        self.root.title(title)
        self.root.geometry(f"{size[0]}x{size[1]}")
        self.root.minsize(720, 560)
        self.bg = AnimatedBG(self.root, self.ui)

        self.header = ctk.CTkFrame(self.root, fg_color="transparent")
        self.header.pack(fill="x", padx=18, pady=(14, 2))
        self.logo = ctk.CTkLabel(self.header, text="Z", text_color=self.ui["accent"],
                                 font=ctk.CTkFont("DejaVu Sans", 30, "bold"))
        self.logo.pack(side="left")
        self.title_lbl = ctk.CTkLabel(self.header, text=title.upper(),
                                      font=ctk.CTkFont("DejaVu Sans", 22, "bold"),
                                      text_color="#eae6ff")
        self.title_lbl.pack(side="left", padx=(6, 0))
        self.badge = ctk.CTkLabel(self.header, text=plan_label or "Sin plan",
                                  fg_color=self.ui["accent"] if plan_label else "#ff5468",
                                  text_color="#0b0814" if plan_label else "#fff",
                                  corner_radius=10, font=accent_font(12), padx=10)
        self.badge.pack(side="right")
        self.gear = GlowButton(self.header, accent="#1b1530", text_color="#eae6ff",
                               text="⚙ Personalizar", width=140, command=self.open_settings)
        self.gear.pack(side="right", padx=10)

        self.content = ctk.CTkFrame(self.root, fg_color="transparent")
        self.content.pack(fill="both", expand=True, padx=14, pady=10)
        self._pulse()

    # barra de acento que “respira”
    def _pulse(self):
        if not hasattr(self, "_pulse_lbl"):
            self._pulse_lbl = ctk.CTkLabel(self.root, text="", fg_color=self.ui["accent"], height=4)
            self._pulse_lbl.place(relx=0.0, rely=1.0, relwidth=1.0, anchor="sw")
        self.root.after(400, self._pulse)

    def card(self, parent=None, **kw):
        p = parent or self.content
        return ctk.CTkFrame(p, fg_color="#15112a", corner_radius=16,
                            border_width=2 if self.ui["lighting"] else 0,
                            border_color=self.ui["accent"], **kw)

    def open_settings(self):
        w = ctk.CTkToplevel(self.root); w.title("Personalizar"); w.geometry("420x560")
        w.attributes("-topmost", True)
        ctk.CTkLabel(w, text="Personalizar ZYH", font=accent_font(18),
                     text_color=self.ui["accent"]).pack(pady=(16, 10))

        ctk.CTkLabel(w, text="Color de acento").pack(anchor="w", padx=20)
        af = ctk.CTkFrame(w, fg_color="transparent"); af.pack(fill="x", padx=16)
        for name, col in ACCENTS.items():
            ctk.CTkButton(af, text="", width=38, height=28, fg_color=col, hover_color=col,
                          corner_radius=8, command=lambda c=col: self._set("accent", c)).pack(side="left", padx=3, pady=4)

        ctk.CTkLabel(w, text="Fondo de pantalla").pack(anchor="w", padx=20, pady=(10, 0))
        wf = ctk.CTkFrame(w, fg_color="transparent"); wf.pack(fill="x", padx=16)
        for name in WALLPAPERS:
            ctk.CTkButton(wf, text=name, width=70, height=28, fg_color="#1b1530",
                          hover_color="#26203f", corner_radius=8,
                          command=lambda n=name: self._set("wallpaper", n)).pack(side="left", padx=3, pady=4)

        ctk.CTkLabel(w, text="Color de fondo").pack(anchor="w", padx=20, pady=(10, 0))
        bf = ctk.CTkFrame(w, fg_color="transparent"); bf.pack(fill="x", padx=16)
        for col in ["#0b0814", "#0a0f1e", "#140a1e", "#05140f", "#101014"]:
            ctk.CTkButton(bf, text="", width=46, height=26, fg_color=col, hover_color=col,
                          border_width=1, border_color="#333", corner_radius=6,
                          command=lambda c=col: self._set("bg", c)).pack(side="left", padx=3, pady=4)

        self._light_sw = ctk.CTkSwitch(w, text="Iluminación (brillo y bordes neón)",
                                       command=lambda: self._set("lighting", bool(self._light_sw.get())))
        self._light_sw.pack(anchor="w", padx=20, pady=(14, 4))
        self._light_sw.select() if self.ui["lighting"] else self._light_sw.deselect()

        self._cpu_sw = ctk.CTkSwitch(w, text="Modo bajo consumo (menos animación)",
                                     command=lambda: self._set("low_cpu", bool(self._cpu_sw.get())))
        self._cpu_sw.pack(anchor="w", padx=20, pady=4)
        self._cpu_sw.select() if self.ui["low_cpu"] else self._cpu_sw.deselect()

        ctk.CTkLabel(w, text="Los cambios se ven al instante y se guardan.",
                     text_color="#9a93b8", font=accent_font(11, False)).pack(pady=14)

    def _set(self, key, val):
        self.ui[key] = val
        save_ui(self.slug, self.ui)
        self.apply_theme()

    def apply_theme(self):
        acc = self.ui["accent"]
        self.logo.configure(text_color=acc)
        self.badge.configure(fg_color=acc if self.badge.cget("text") != "Sin plan" else "#ff5468")
        if hasattr(self, "_pulse_lbl"):
            self._pulse_lbl.configure(fg_color=acc)
        self.bg.rebuild()
        # refrescar bordes de las tarjetas
        for fr in self.content.winfo_children():
            if isinstance(fr, ctk.CTkFrame):
                try:
                    fr.configure(border_color=acc,
                                 border_width=2 if self.ui["lighting"] else 0)
                except Exception:
                    pass

    def run(self):
        self.root.mainloop()
