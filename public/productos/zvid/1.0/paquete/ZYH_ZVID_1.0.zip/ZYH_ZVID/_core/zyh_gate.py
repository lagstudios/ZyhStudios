# -*- coding: utf-8 -*-
"""Pantalla de entrada de las apps ZYH: «Regístrate o inicia sesión con tu cuenta ZYH».

require(app) -> True si hay una cuenta ZYH válida en este equipo (o la acaba de crear/iniciar).
              False si la persona cierra la ventana o pulsa Salir.
Solo usa tkinter (viene con Python), así funciona igual en apps CustomTkinter y Qt.
La sesión ya guardada se comprueba con la web; si no hay internet se usa la guardada (modo sin conexión).
"""
import queue, threading

BG, PANEL, FG, MUTED, RED = "#0e0b1a", "#17122b", "#eae6ff", "#9a93b8", "#ff6b7a"


def _acc():
    from zyhcore import account
    return account


def has_valid_session():
    """True = sesión buena (o sin internet pero guardada) · False = no hay sesión o la web la rechazó."""
    try:
        a = _acc()
    except Exception:
        return False
    if not a.session():
        return False
    ok = a.validate()          # True / False / None (sin conexión)
    if ok is False:
        try:
            a.logout()
        except Exception:
            pass
        return False
    return True


def require(app, accent="#8bf5a2"):
    if has_valid_session():
        return True
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:
        return False
    a = _acc()
    st = {"ok": False, "mode": "login"}
    q = queue.Queue()
    root.title(f"{app} — Cuenta ZYH"); root.configure(bg=BG)
    w, h = 460, 560
    root.geometry(f"{w}x{h}+{max(0, (root.winfo_screenwidth() - w) // 2)}+{max(0, (root.winfo_screenheight() - h) // 4)}")
    root.minsize(420, 520)

    body = tk.Frame(root, bg=BG); body.pack(fill="both", expand=True, padx=26, pady=20)
    tk.Label(body, text=app, bg=BG, fg=accent, font=("Helvetica", 20, "bold")).pack(anchor="w")
    title = tk.Label(body, text="", bg=BG, fg=FG, font=("Helvetica", 13, "bold"), justify="left", wraplength=400)
    title.pack(anchor="w", pady=(6, 2))
    sub = tk.Label(body, text="", bg=BG, fg=MUTED, justify="left", wraplength=400)
    sub.pack(anchor="w", pady=(0, 12))

    def field(label, show=None):
        tk.Label(body, text=label, bg=BG, fg=FG).pack(anchor="w")
        e = tk.Entry(body, show=show or "", bg=PANEL, fg=FG, insertbackground=FG, relief="flat", font=("Helvetica", 12))
        e.pack(fill="x", ipady=7, pady=(2, 8)); return e
    e_user = field("Usuario")
    e_pass = field("Contraseña (mínimo %d caracteres)" % a.MIN_PASSWORD, show="•")
    mail_lbl = tk.Label(body, text="Correo (opcional)", bg=BG, fg=FG)
    e_mail = tk.Entry(body, bg=PANEL, fg=FG, insertbackground=FG, relief="flat", font=("Helvetica", 12))
    status = tk.Label(body, text="", bg=BG, fg=RED, wraplength=400, justify="left")

    btns = tk.Frame(body, bg=BG)
    main_btn = tk.Button(btns, text="", bg=accent, fg="#0b0814", activebackground=accent, relief="flat",
                         font=("Helvetica", 12, "bold"), padx=16, pady=8)
    swap_btn = tk.Button(btns, text="", bg=PANEL, fg=FG, activebackground="#26203f", activeforeground=FG, relief="flat", padx=16, pady=8)
    exit_btn = tk.Button(btns, text="Salir", bg="#2a2342", fg=FG, activebackground="#3a3158", activeforeground=FG, relief="flat", padx=16, pady=8,
                         command=root.destroy)

    def paint():
        reg = st["mode"] == "register"
        title.config(text="Regístrate con tu cuenta ZYH" if reg else "Inicia sesión con tu cuenta ZYH")
        sub.config(text=("Crea tu cuenta ZYH: es la misma para la web y todas las apps." if reg else
                         "Entra para usar la app y activar el plan que compraste en la web de ZyhStudios."))
        main_btn.config(text="Crear cuenta" if reg else "Iniciar sesión")
        swap_btn.config(text="Ya tengo cuenta" if reg else "Registrarme")
        if reg:
            mail_lbl.pack(anchor="w", before=status); e_mail.pack(fill="x", ipady=7, pady=(2, 8), before=status)
        else:
            mail_lbl.pack_forget(); e_mail.pack_forget()
        status.config(text="")

    status.pack(anchor="w", pady=(4, 6))
    btns.pack(fill="x", pady=(6, 0), side="bottom")
    main_btn.pack(fill="x", pady=(0, 6)); swap_btn.pack(fill="x", pady=(0, 6)); exit_btn.pack(fill="x")

    def swap():
        st["mode"] = "register" if st["mode"] == "login" else "login"; paint()

    def go():
        user, pw, mail = e_user.get().strip(), e_pass.get(), e_mail.get().strip()
        if not user:
            status.config(text="Escribe tu usuario.", fg=RED); return
        if len(pw) < a.MIN_PASSWORD:
            status.config(text="La contraseña debe tener al menos %d caracteres." % a.MIN_PASSWORD, fg=RED); return
        status.config(text="Conectando con la web de ZYH…", fg=MUTED)
        for b in (main_btn, swap_btn):
            b.config(state="disabled")
        reg = st["mode"] == "register"

        def work():
            try:
                (a.register(user, pw, mail, app) if reg else a.login(user, pw, app))
                q.put(("ok", None))
            except Exception as exc:
                q.put(("err", str(exc)))
        threading.Thread(target=work, daemon=True).start()

    def pump():
        try:
            while True:
                kind, msg = q.get_nowait()
                if kind == "ok":
                    st["ok"] = True; root.destroy(); return
                status.config(text=msg, fg=RED)
                for b in (main_btn, swap_btn):
                    b.config(state="normal")
        except queue.Empty:
            pass
        root.after(120, pump)

    main_btn.config(command=go); swap_btn.config(command=swap)
    e_pass.bind("<Return>", lambda _e: go()); e_user.bind("<Return>", lambda _e: e_pass.focus_set())
    root.protocol("WM_DELETE_WINDOW", root.destroy)
    paint(); pump(); e_user.focus_set(); root.lift(); root.focus_force(); root.mainloop()
    return st["ok"]
