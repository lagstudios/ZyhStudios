# -*- coding: utf-8 -*-
"""ZYH ZVID Converter  ·  ZYH Studios

Convierte un MP4 al formato ZVID para reproducirlo en la pantalla del ZYHT32.
Herramienta del IDE del ZYHT32 (gratis). Interfaz CustomTkinter animada. GUI + CLI.

CLI:
    python zyh_zvid.py <entrada.mp4> <salida.zvid> [--w 128 --h 160 --fps 12]
"""
import os, sys, threading, argparse

_HERE = os.path.dirname(os.path.abspath(__file__))
for cand in (os.path.join(_HERE, "..", "..", "_core"), os.path.join(_HERE, "..", "_core")):
    if os.path.isdir(cand):
        sys.path.insert(0, os.path.abspath(cand)); break
import zvid_core as Z                    # noqa
ACCENT = "#9b6cff"


def human(n):
    for u in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.1f} {u}"
        n /= 1024
    return f"{n:.1f} TB"


def run_gui():
    import customtkinter as ctk
    from tkinter import filedialog
    import zyh_ui as U

    sh = U.ZYHShell("ZYH ZVID", "zvid", plan_label="Gratis", accent=ACCENT, size=(820, 620))
    acc = sh.ui["accent"]
    st = {"src": None, "busy": False}

    c = sh.card(); c.pack(fill="x", pady=(4, 10))
    ctk.CTkLabel(c, text="Convierte MP4 → ZVID para la pantalla del ZYHT32",
                 font=U.accent_font(15)).pack(anchor="w", padx=16, pady=(12, 4))
    U.GlowButton(c, accent=acc, text="Elegir MP4", command=lambda: pick()).pack(anchor="w", padx=16, pady=4)
    src_lbl = ctk.CTkLabel(c, text="Ningún video elegido", text_color="#9a93b8",
                           font=U.accent_font(11, False), anchor="w", wraplength=740)
    src_lbl.pack(fill="x", padx=16, pady=(2, 12))

    c2 = sh.card(); c2.pack(fill="x", pady=6)
    grid = ctk.CTkFrame(c2, fg_color="transparent"); grid.pack(fill="x", padx=16, pady=12)
    ctk.CTkLabel(grid, text="Ancho").grid(row=0, column=0, padx=6)
    ctk.CTkLabel(grid, text="Alto").grid(row=0, column=1, padx=6)
    ctk.CTkLabel(grid, text="FPS").grid(row=0, column=2, padx=6)
    e_w = ctk.CTkEntry(grid, width=80); e_w.insert(0, "128"); e_w.grid(row=1, column=0, padx=6)
    e_h = ctk.CTkEntry(grid, width=80); e_h.insert(0, "160"); e_h.grid(row=1, column=1, padx=6)
    e_f = ctk.CTkEntry(grid, width=80); e_f.insert(0, "12"); e_f.grid(row=1, column=2, padx=6)
    ctk.CTkLabel(c2, text="Tamaño típico de pantalla del ZYHT32: 128 x 160 (RGB565).",
                 text_color="#9a93b8", font=U.accent_font(11, False)).pack(anchor="w", padx=16, pady=(0, 10))

    U.GlowButton(sh.content, accent=acc, text="Convertir a .zvid", height=46, width=220,
                 command=lambda: convert()).pack(anchor="w", padx=14, pady=10)
    prog = ctk.CTkProgressBar(sh.content, mode="indeterminate", progress_color=acc)
    status = ctk.CTkLabel(sh.content, text="", text_color="#9a93b8", anchor="w", font=U.accent_font(11, False))
    status.pack(fill="x", padx=16);

    def pick():
        p = filedialog.askopenfilename(filetypes=[("Video", "*.mp4 *.mov *.mkv *.avi *.webm")])
        if p:
            st["src"] = p; src_lbl.configure(text=f"{p}\n({human(os.path.getsize(p))})")

    def convert():
        if st["busy"] or not st["src"]:
            status.configure(text="Primero elige un MP4."); return
        out = filedialog.asksaveasfilename(defaultextension=".zvid",
                                           initialfile=os.path.splitext(os.path.basename(st["src"]))[0] + ".zvid")
        if not out:
            return
        try:
            w, h, fps = int(e_w.get()), int(e_h.get()), int(e_f.get())
        except ValueError:
            status.configure(text="Ancho/alto/fps inválidos."); return
        st["busy"] = True; prog.pack(fill="x", padx=14, pady=4); prog.start()
        status.configure(text="Convirtiendo con ffmpeg…")

        def work():
            try:
                r = Z.encode(st["src"], out, w, h, fps,
                             progress=lambda n: status.configure(text=f"Convirtiendo… {n} cuadros"))
                prev = out + ".preview.png"
                try: Z.to_preview_png(out, prev)
                except Exception: prev = None
                dur = r["frames"] / max(1, r["fps"])
                status.configure(text=f"✓ Listo · {r['frames']} cuadros · {r['w']}x{r['h']} · "
                                      f"{r['fps']} fps · {human(r['size'])} · ~{dur:.0f}s"
                                 + (f"  (vista previa: {os.path.basename(prev)})" if prev else ""))
            except FileNotFoundError:
                status.configure(text="Falta ffmpeg. Instálalo (el instalador de ZYH lo hace).")
            except Exception as e:
                status.configure(text="Error: " + str(e))
            finally:
                prog.stop(); prog.pack_forget(); st["busy"] = False
        threading.Thread(target=work, daemon=True).start()

    sh.run()


def run_cli(a):
    r = Z.encode(a.src, a.out, a.w, a.h, a.fps,
                 progress=lambda n: print(f"\r{n} cuadros", end=""))
    print(f"\nOK  {r['frames']} cuadros · {r['w']}x{r['h']} · {r['fps']} fps · {human(r['size'])}")
    return 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("src", nargs="?"); ap.add_argument("out", nargs="?")
    ap.add_argument("--w", type=int, default=128); ap.add_argument("--h", type=int, default=160)
    ap.add_argument("--fps", type=int, default=12)
    args = ap.parse_args()
    if args.src and args.out:
        sys.exit(run_cli(args))
    import zyh_terms; zyh_terms.require("ZYH ZVID", ACCENT)   # términos: si no se aceptan, la app se cierra
    run_gui()
