# -*- coding: utf-8 -*-
"""Formato ZVID — video para la pantalla del ZYHT32.

La pantalla del ZYHT32 es pequeña (por defecto 128x160, color RGB565). Un .mp4
normal no cabe ni se puede reproducir ahí. ZVID guarda el video ya listo para la
pantalla: tamaño pequeño, pocos cuadros por segundo, color RGB565 y cada cuadro
comprimido con RLE. El firmware lo lee desde la SD y lo dibuja directo.

Cabecera (.zvid):
    "ZVID" | ver(1) | w(2 LE) | h(2 LE) | fps(1) | nframes(4 LE) | flags(1)
      flags bit0: 1 = RLE, 0 = crudo ; bit1: 1 = bytes RGB565 en little-endian
Luego, por cuadro:  si RLE -> [ len(4 LE) | (count1, pix2)* ]   si crudo -> w*h*2 bytes
"""
import os, struct, subprocess

MAGIC = b"ZVID"
VER = 1


def rgb565(r, g, b):
    return ((r & 0xF8) << 8) | ((g & 0xFC) << 3) | (b >> 3)


def _rle_encode(pix16):
    out = bytearray()
    i = 0; n = len(pix16)
    while i < n:
        v = pix16[i]; c = 1
        while i + c < n and pix16[i + c] == v and c < 255:
            c += 1
        out += bytes([c]) + struct.pack("<H", v)
        i += c
    return bytes(out)


def _rle_decode(data, count):
    pix = []; i = 0
    while i < len(data) and len(pix) < count:
        c = data[i]; v = struct.unpack("<H", data[i+1:i+3])[0]
        pix.extend([v] * c); i += 3
    return pix


def _ffmpeg():
    import shutil
    p = shutil.which("ffmpeg")
    if p:
        return p
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return "ffmpeg"


def encode(mp4_path, out_path, w=128, h=160, fps=12, progress=None):
    """Convierte un MP4 a .zvid usando ffmpeg para redimensionar y muestrear."""
    cmd = [_ffmpeg(), "-v", "error", "-i", mp4_path,
           "-vf", f"scale={w}:{h}:flags=lanczos,fps={fps}",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE)
    frame_bytes = w * h * 3
    frames = []
    while True:
        raw = proc.stdout.read(frame_bytes)
        if len(raw) < frame_bytes:
            break
        pix16 = [rgb565(raw[j], raw[j+1], raw[j+2]) for j in range(0, frame_bytes, 3)]
        frames.append(_rle_encode(pix16))
        if progress and len(frames) % 10 == 0:
            progress(len(frames))
    proc.wait()
    with open(out_path, "wb") as f:
        f.write(MAGIC + bytes([VER]) + struct.pack("<HHB", w, h, fps)
                + struct.pack("<I", len(frames)) + bytes([0b11]))
        for fr in frames:
            f.write(struct.pack("<I", len(fr)) + fr)
    return {"frames": len(frames), "w": w, "h": h, "fps": fps, "size": os.path.getsize(out_path)}


def read_header(path):
    with open(path, "rb") as f:
        if f.read(4) != MAGIC:
            raise ValueError("No es un archivo .zvid")
        ver = f.read(1)[0]
        w, h, fps = struct.unpack("<HHB", f.read(5))
        (nf,) = struct.unpack("<I", f.read(4))
        flags = f.read(1)[0]
    return dict(ver=ver, w=w, h=h, fps=fps, nframes=nf, rle=bool(flags & 1))


def decode_frames(path):
    """Genera cuadros como listas de pixeles RGB565 (para previsualizar)."""
    hd = read_header(path)
    with open(path, "rb") as f:
        f.read(15)   # cabecera: 4+1+5+4+1
        for _ in range(hd["nframes"]):
            (ln,) = struct.unpack("<I", f.read(4))
            data = f.read(ln)
            yield _rle_decode(data, hd["w"] * hd["h"]), hd


def to_preview_png(path, out_png, scale=3):
    """Arma un PNG mosaico de los primeros cuadros para ver cómo se verá."""
    from PIL import Image
    hd = read_header(path)
    cols = min(8, hd["nframes"]); rows = (min(hd["nframes"], 24) + cols - 1) // cols
    W, H = hd["w"] * scale, hd["h"] * scale
    sheet = Image.new("RGB", (W * cols, H * rows), (10, 8, 20))
    for i, (pix, h) in enumerate(decode_frames(path)):
        if i >= cols * rows:
            break
        im = Image.new("RGB", (h["w"], h["h"]))
        px = im.load()
        for idx, v in enumerate(pix[:h["w"] * h["h"]]):
            r = (v >> 11) << 3; g = ((v >> 5) & 0x3F) << 2; b = (v & 0x1F) << 3
            px[idx % h["w"], idx // h["w"]] = (r, g, b)
        im = im.resize((W, H), Image.NEAREST)
        sheet.paste(im, ((i % cols) * W, (i // cols) * H))
    sheet.save(out_png)
    return out_png
