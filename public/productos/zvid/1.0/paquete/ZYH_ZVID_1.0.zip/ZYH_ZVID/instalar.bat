@echo off
set "DIR=%~dp0"
where python >nul 2>nul && (set PY=python) || (where py >nul 2>nul && (set PY=py) || (echo Falta Python 3: https://www.python.org/downloads/ & pause & exit /b 1))
%PY% -m pip install --upgrade customtkinter pillow imageio-ffmpeg
set "PYW=%PY%"
where pythonw >nul 2>nul && set "PYW=pythonw"
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:USERPROFILE+'\Desktop\ZYH ZVID.lnk');$s.TargetPath='%PYW%';$s.Arguments='\"%DIR%app_completa\zyh_zvid.py\"';$s.IconLocation='%DIR%logo.png';$s.WorkingDirectory='%DIR%app_completa';$s.Save()" 2>nul
echo Listo. Acceso directo "ZYH ZVID" en el Escritorio.
pause
