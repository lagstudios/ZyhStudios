# -*- coding: utf-8 -*-
"""Verificador de licencias ZYH (núcleo protegido).

La app NO ve esto por dentro: solo llama a guard.require(producto) y recibe
"activo si/no" + entitlements. Aqui vive la firma, la ID y la logica.

- Online: consulta la web de ZYH (cuando exista) para confirmar el pago.
- Offline: valida un archivo de licencia firmado localmente, con margen de
  gracia de OFFLINE_GRACE_DAYS para que funcione sin internet.

Nota: hoy la firma es HMAC con secreto embebido (suficiente para empezar y para
el modo local). Cuando montes la web de ZYH, se cambia a RSA con la clave
privada SOLO en el servidor y aqui queda unicamente la publica -> imposible de
falsificar por el usuario. Dejo el punto exacto marcado con [WEB].
"""
import os, json, time, hmac, hashlib, base64, platform, urllib.request, urllib.error

from . import deviceid, plans

# [WEB] secreto local temporal. Mover a RSA/servidor al tener api.zyhstudios.
_SECRET = b"zyh_local_hmac_7f3a9c21_CHANGE_ON_WEB"
# La verificacion online ya existe: va por la cuenta ZYH (account.py -> web de ZYH).
OFFLINE_GRACE_DAYS = 7
ONLINE_TIMEOUT = 5


# ---------------------------------------------------------------- almacen local
def _store_dir():
    s = platform.system()
    if s == "Windows":
        base = os.path.join(os.environ.get("PROGRAMDATA", r"C:\ProgramData"), "ZYH", "lic")
    elif s == "Darwin":
        base = os.path.expanduser("~/Library/Application Support/ZYH/lic")
    else:
        base = os.path.expanduser("~/.config/zyh/lic")
    os.makedirs(base, exist_ok=True)
    return base


def _lic_path(product):
    return os.path.join(_store_dir(), f"{product}.lic")


# ---------------------------------------------------------------- firma
def _sign(payload: dict) -> str:
    raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
    mac = hmac.new(_SECRET, raw, hashlib.sha256).digest()
    return base64.urlsafe_b64encode(mac).decode()


def _make_token(payload: dict) -> str:
    body = base64.urlsafe_b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode()
    return body + "." + _sign(payload)


def _read_token(token: str):
    try:
        body, sig = token.strip().split(".")
        payload = json.loads(base64.urlsafe_b64decode(body.encode()))
        if not hmac.compare_digest(sig, _sign(payload)):
            return None
        return payload
    except Exception:
        return None


# ---------------------------------------------------------------- emision local
def issue_local(product, plan_id, days=30, devices=None, extra_devices=0):
    """Emite y guarda una licencia local firmada para ESTE dispositivo.
    La usan el activador admin y (mas adelante) la respuesta del servidor."""
    p = plans.plan(product, plan_id)
    now = int(time.time())
    payload = {
        "product": product,
        "plan": plan_id,
        "device_id": deviceid.get_device_id(),
        "devices": devices if devices is not None else p["devices"],
        "extra_devices": extra_devices,
        "issued": now,
        "expires": now + days * 86400,
        "source": "local",
    }
    token = _make_token(payload)
    with open(_lic_path(product), "w") as f:
        f.write(token)
    return token


# ---------------------------------------------------------------- verificacion
def _check_online(product, device_id):
    """Pregunta a la web de ZYH con la cuenta del usuario. Devuelve el plan activo o None.
    Si no hay cuenta o no hay internet, se cae a la licencia local firmada."""
    try:
        from . import account
        r = account.check_license(product, timeout=ONLINE_TIMEOUT)
        return r if (r and r.get("active")) else None
    except Exception:
        return None


class Entitlement:
    def __init__(self, product, payload):
        self.product = product
        self.plan = payload["plan"]
        self.device_id = payload["device_id"]
        self.devices = payload.get("devices", 1) + payload.get("extra_devices", 0)
        self.expires = payload.get("expires", 0)
        self._p = plans.plan(product, self.plan)
        self.features = set(self._p.get("features", []))
        self.label = self._p["label"]

    def has(self, feature):
        return feature in self.features

    @property
    def days_left(self):
        return max(0, int((self.expires - time.time()) / 86400))


_cache = {}
_CACHE_SECONDS = 300


def verify(product, force=False):
    """Punto unico. Devuelve Entitlement si hay plan valido, o None (bloqueado).
    Orden: online (si hay web) -> licencia local firmada -> gracia offline."""
    did = deviceid.get_device_id()

    hit = _cache.get(product)
    if hit and not force and hit[0] > time.time():
        return hit[1]

    online = _check_online(product, did)
    if online:
        payload = {"product": product, "plan": online["plan"], "device_id": did,
                   "devices": online.get("devices", 1), "extra_devices": online.get("extra_devices", 0),
                   "issued": int(time.time()), "expires": int(online.get("expires", time.time() + 86400 * 30))}
        with open(_lic_path(product), "w") as f:
            f.write(_make_token(payload))
        ent = Entitlement(product, payload)
        _cache[product] = (time.time() + _CACHE_SECONDS, ent)
        return ent

    # offline: leer licencia local
    try:
        with open(_lic_path(product)) as f:
            payload = _read_token(f.read())
    except FileNotFoundError:
        payload = None
    if not payload or payload.get("product") != product or payload.get("device_id") != did \
            or payload.get("expires", 0) + OFFLINE_GRACE_DAYS * 86400 < time.time():
        _cache[product] = (time.time() + 20, None)       # sin plan: se reintenta pronto
        return None
    ent = Entitlement(product, payload)
    _cache[product] = (time.time() + _CACHE_SECONDS, ent)
    return ent


def refresh(product=None):
    """Olvida lo consultado para volver a preguntarle a la web (tras entrar o pagar)."""
    if product:
        _cache.pop(product, None)
    else:
        _cache.clear()
