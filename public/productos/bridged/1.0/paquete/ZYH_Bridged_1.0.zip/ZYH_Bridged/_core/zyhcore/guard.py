# -*- coding: utf-8 -*-
"""Lo UNICO que la app importa. La app solo pregunta; no ve la logica interna.

    from zyhcore import guard
    ent = guard.require("compressor")      # None = bloqueado
    if ent and ent.has("modo_alto"): ...

Se distribuye como .pyc (compilado). El resto del núcleo (license/deviceid)
tambien, para que el usuario no lo pueda leer/editar facil.
"""
from . import license as _lic, plans


def require(product, force=False):
    """Devuelve Entitlement activo o None. No revela por que."""
    try:
        return _lic.verify(product, force=force)
    except Exception:
        return None


def refresh(product=None):
    """Vuelve a preguntar a la web (tras entrar con la cuenta ZYH o tras pagar)."""
    try:
        _lic.refresh(product)
    except Exception:
        pass


def account():
    """Modulo de cuenta ZYH (login/registro). None si no esta disponible."""
    try:
        from . import account as _a
        return _a
    except Exception:
        return None


def product_name(product):
    return plans.PRODUCTS[product]["name"]


def plan_catalog(product):
    """Para la pantalla 'Quiero un plan' (solo etiquetas y precios, sin internals)."""
    out = []
    for pid, p in plans.PRODUCTS[product]["plans"].items():
        out.append({"id": pid, "label": p["label"], "usd": p["usd"],
                    "cycle": p.get("cycle", "mes"), "devices": p["devices"],
                    "extra_usd": p.get("extra_usd", 0)})
    return out
