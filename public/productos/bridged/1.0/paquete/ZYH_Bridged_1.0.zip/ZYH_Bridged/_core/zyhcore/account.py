# -*- coding: utf-8 -*-
"""Cuenta ZYH — enlace entre las apps y la web de ZYH Studios.

  • La contraseña NUNCA sale del equipo: se deriva con PBKDF2 (200 000 vueltas) y solo
    viaja el resultado, igual que en la web.
  • El identificador del dispositivo NUNCA se envía tal cual: se manda un hash.
  • La sesión se guarda cifrada (.zyhd, atada a este equipo).
"""
import os, json, time, hashlib, urllib.request, urllib.error

from . import deviceid, store

BASE_DEFAULT = "https://zyhstudios.lagstudiosceo.workers.dev"         # se cambia en Ajustes o con ZYH_WEB
MIN_PASSWORD = 8
TIMEOUT = 12


def _cfg_dir():
    d = os.path.join(os.path.expanduser("~"), ".config", "zyh")
    os.makedirs(d, exist_ok=True)
    return d


_SESSION = lambda: os.path.join(_cfg_dir(), "cuenta.zyhd")
_SERVER = lambda: os.path.join(_cfg_dir(), "servidor.json")


def base_url():
    """Dirección de la web de ZYH. Orden: variable ZYH_WEB → lo guardado → la de fábrica."""
    env = os.environ.get("ZYH_WEB", "").strip()
    if env:
        return env.rstrip("/")
    try:
        with open(_SERVER(), encoding="utf-8") as f:
            u = str(json.load(f).get("url", "")).strip().rstrip("/")
        if u.startswith(("https://", "http://")):
            return u
    except Exception:
        pass
    return BASE_DEFAULT


def set_base_url(url):
    url = str(url or "").strip().rstrip("/")
    if url and not url.startswith(("https://", "http://")):
        url = "https://" + url
    with open(_SERVER(), "w", encoding="utf-8") as f:
        json.dump({"url": url or BASE_DEFAULT}, f)


def device_hash():
    """Lo único que se envía del equipo: un hash, no la identificación."""
    return hashlib.sha256(("zyh-device:" + deviceid.get_device_id()).encode()).hexdigest()


def derive(username, password):
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"),
                               ("zyh-account:" + username.lower()).encode(), 200_000, 32).hex()


class AccountError(Exception):
    pass


def _request(path, data=None, token=None, method=None, timeout=TIMEOUT):
    url = base_url() + "/api/" + path.lstrip("/")
    headers = {"User-Agent": "ZYH-App"}
    body = None
    if data is not None:
        body = json.dumps(data).encode(); headers["Content-Type"] = "application/json"
    if token:
        headers["Authorization"] = "Bearer " + token
    req = urllib.request.Request(url, data=body, headers=headers, method=method or ("POST" if data is not None else "GET"))
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode() or "{}")
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode()).get("error")
        except Exception:
            msg = None
        raise AccountError(msg or f"El servidor respondió {e.code}.")
    except urllib.error.URLError as e:
        raise AccountError(f"No se pudo conectar con la web de ZYH ({e.reason}). Revisa tu internet o la dirección del servidor.")
    except Exception as e:
        raise AccountError(str(e))


# ---------------------------------------------------------------- sesión guardada
def session():
    return store.load(_SESSION(), None) or None


def username():
    s = session()
    return s.get("username") if s else None


def _save(username_, token, role="user"):
    store.save(_SESSION(), {"username": username_, "token": token, "role": role, "since": int(time.time())})


def logout():
    s = session()
    if s:
        try:
            _request("logout", data={}, token=s.get("token"), timeout=6)
        except Exception:
            pass
    try:
        os.remove(_SESSION())
    except OSError:
        pass


def check_password(password):
    if len(password or "") < MIN_PASSWORD:
        raise AccountError(f"La contraseña debe tener al menos {MIN_PASSWORD} caracteres.")


def login(username_, password, label=""):
    username_ = (username_ or "").strip().lower()
    check_password(password)
    r = _request("login", data={"username": username_, "dk": derive(username_, password), "client": "app",
                                "label": label or "App de ZYH"})
    if not r.get("token"):
        raise AccountError("El servidor no devolvió la sesión. Intenta de nuevo.")
    _save(username_, r["token"], (r.get("user") or {}).get("role", "user"))
    return r.get("user") or {"username": username_}


def register(username_, password, email="", label=""):
    username_ = (username_ or "").strip().lower()
    check_password(password)
    r = _request("register", data={"username": username_, "dk": derive(username_, password), "email": (email or "").strip(),
                                   "client": "app", "label": label or "App de ZYH"})
    if not r.get("token"):
        raise AccountError("La cuenta se creó, pero no se inició sesión. Entra manualmente.")
    _save(username_, r["token"], (r.get("user") or {}).get("role", "user"))
    return r.get("user") or {"username": username_}


def licenses():
    s = session()
    if not s:
        raise AccountError("Primero entra con tu cuenta ZYH.")
    return _request("licenses", token=s.get("token")).get("licenses", [])


def check_license(product, timeout=TIMEOUT):
    """Pregunta a la web si esta cuenta tiene plan para este producto en ESTE equipo.
    Devuelve el dict del servidor, o None si no hay sesión o no se pudo consultar."""
    s = session()
    if not s or not s.get("token"):
        return None
    try:
        r = _request(f"license?product={product}&device={device_hash()}", token=s["token"], timeout=timeout)
    except AccountError:
        return None
    if r.get("active"):
        return r
    if r.get("reason") == "sin_plan":
        return {"active": False, "reason": "sin_plan"}
    return {"active": False, "reason": r.get("reason", "desconocido"), "devices": r.get("devices")}
