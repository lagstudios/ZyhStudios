# -*- coding: utf-8 -*-
"""ID de dispositivo ZYH.

La ID se DERIVA del hardware (huella estable), no se inventa al azar, así que
aunque el usuario borre el archivo, al regenerarla sale la MISMA ID. Se guarda
además en varias ubicaciones "sensibles" segun el OS. La app nunca la muestra;
solo el núcleo la usa para validar la licencia.
"""
import os, sys, hashlib, uuid, platform, subprocess, pathlib

_SALT = b"ZYH-STUDIOS-DEVICE-v1"


def _run(cmd):
    try:
        return subprocess.check_output(cmd, shell=True, stderr=subprocess.DEVNULL,
                                       timeout=4).decode("utf-8", "ignore").strip()
    except Exception:
        return ""


def _hw_tokens():
    """Piezas estables del hardware. Se combinan y hashean."""
    t = [platform.machine(), platform.system()]
    # MAC de la placa (nodo) -- solo si es real, no la aleatoria de respaldo
    node = uuid.getnode()
    if not (node & 0x010000000000):   # bit multicast = getnode() invento una MAC
        t.append(format(node, "x"))
    s = platform.system()
    if s == "Linux":
        for p in ("/etc/machine-id", "/var/lib/dbus/machine-id"):
            try:
                t.append(pathlib.Path(p).read_text().strip())
            except Exception:
                pass
        t.append(_run("cat /sys/class/dmi/id/product_uuid 2>/dev/null"))
        t.append(_run("lsblk -ndo serial 2>/dev/null | head -1"))
    elif s == "Windows":
        t.append(_run("wmic csproduct get uuid"))
        t.append(_run("wmic diskdrive get serialnumber"))
        t.append(os.environ.get("PROCESSOR_IDENTIFIER", ""))
    elif s == "Darwin":
        t.append(_run("ioreg -rd1 -c IOPlatformExpertDevice | awk -F'\"' '/IOPlatformUUID/{print $4}'"))
    return [x for x in t if x]


def _mirrors():
    """Rutas (segun OS) donde se guarda la ID. Las que requieren permisos se
    intentan en silencio; siempre hay un fallback en el perfil del usuario."""
    s = platform.system()
    out = []
    if s == "Linux":
        out += ["/var/lib/zyh/.zid", "/etc/zyh/.zid",
                os.path.expanduser("~/.config/zyh/.zid"),
                os.path.expanduser("~/.cache/.zyh_sys")]
    elif s == "Windows":
        pd = os.environ.get("PROGRAMDATA", r"C:\ProgramData")
        la = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
        out += [os.path.join(pd, "ZYH", "sys.dat"),
                os.path.join(la, "ZYH", ".zid")]
    else:
        out += [os.path.expanduser("~/Library/Application Support/ZYH/.zid"),
                os.path.expanduser("~/.zyh/.zid")]
    return out


def _compute():
    raw = "|".join(_hw_tokens()).encode("utf-8", "ignore")
    h = hashlib.sha256(_SALT + raw).hexdigest()
    # ID numerica legible de 12 digitos (como pediste: 434234...)
    num = int(h[:16], 16) % (10 ** 12)
    return f"{num:012d}"


def _write_mirror(path, value):
    try:
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        with open(path, "w") as f:
            f.write(value)
        if platform.system() == "Windows":
            _run(f'attrib +h +s "{path}"')
        return True
    except Exception:
        return False


def _read_mirror():
    for m in _mirrors():
        try:
            v = open(m).read().strip()
            if v.isdigit() and len(v) == 12:
                return v
        except Exception:
            pass
    return None


def get_device_id():
    """Devuelve la ID del dispositivo. Primero busca una ID ya registrada en las
    ubicaciones del sistema (estable aunque el hardware reporte algo distinto);
    si no hay ninguna, la deriva del hardware y la siembra en todas. Si borran
    una copia, se reescribe desde las otras o se vuelve a derivar."""
    did = _read_mirror() or _compute()
    for m in _mirrors():
        if not os.path.exists(m):
            _write_mirror(m, did)
    return did


def short_id():
    return get_device_id()[:8]


if __name__ == "__main__":
    print(get_device_id())
