# -*- coding: utf-8 -*-
"""ZYH Studios — Términos y condiciones al iniciar.

require("ZYH Business") muestra los términos. Si la persona cierra la ventana o pulsa «No acepto»,
el programa se cierra por completo. Si acepta, sigue. La aceptación se recuerda por programa y se
vuelve a pedir cuando cambia TERMS_VERSION. (Pon ASK_EVERY_START = True para pedirla en cada inicio.)
"""
import os, sys, json, time, html as _html

TERMS_VERSION = "2026-11"
ASK_EVERY_START = False
STORE = os.path.join(os.path.expanduser("~"), ".config", "zyh", "terms.json")

TERMS = """TÉRMINOS Y CONDICIONES — ZYH STUDIOS

1. Licencia de uso. ZYH Studios te concede una licencia personal e intransferible para usar ZYH Browser, ZYH Compressor, ZYH Business, ZYH Bridged, ZYH ZVID y ZYHT32 IDE según el plan contratado y el número de dispositivos permitido.

2. Pagos. Los planes de pago se cobran por adelantado (mensual, o por fin de semana en ZYH Bridged) a través de PayPal, desde la web de ZyhStudios. Los precios se expresan en dólares. ZYH Browser, ZYH ZVID y ZYHT32 IDE son gratuitos.

3. Dispositivos. Cada licencia cubre un número de dispositivos. Los dispositivos adicionales tienen un costo extra según el plan.

4. Prohibido modificar, descompilar, piratear o redistribuir el software o su sistema de licencias. Hacerlo termina la licencia de inmediato y puede acarrear responsabilidad legal.

5. ZYH Business — WhatsApp e IA. La atención automatizada usa la API oficial de WhatsApp Business (Meta) y Google Gemini, con credenciales que tú provees. Debes cumplir las políticas de Meta y de Google. ZYH Studios no se hace responsable de suspensiones de cuenta por mal uso. Las extensiones creadas por la IA son solo configuración; revisa lo que instalas.

6. Datos. ZYH Business (edición local) guarda los datos en tu equipo. Eres responsable de respaldarlos y de cumplir la ley de datos de tu país. El lector de códigos de barras con cámara procesa la imagen solo en tu equipo.

7. ZYHT32 IDE. Flashear firmware o cambiar particiones puede dejar una placa inutilizable si se interrumpe o se elige mal; lo haces bajo tu responsabilidad. Los códigos oficiales importados conservan su licencia original.

8. Garantía. El software se entrega "tal cual", sin garantía de que esté libre de errores. ZYH Studios no responde por daños indirectos derivados del uso.

9. Cambios. ZYH Studios puede actualizar estos términos y las funciones de las apps en futuras versiones; cuando cambien, se te pedirá aceptarlos de nuevo.

Al usar cualquier programa de ZYH Studios aceptas estos términos.
© ZYH Studios."""


def _load():
    try:
        with open(STORE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def is_accepted(app):
    if ASK_EVERY_START:
        return False
    d = _load()
    return d.get("version") == TERMS_VERSION and app in d.get("apps", {})


def mark_accepted(app):
    d = _load()
    if d.get("version") != TERMS_VERSION:
        d = {"version": TERMS_VERSION, "apps": {}}
    d.setdefault("apps", {})[app] = time.strftime("%Y-%m-%d %H:%M")
    try:
        os.makedirs(os.path.dirname(STORE), exist_ok=True)
        with open(STORE, "w", encoding="utf-8") as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass   # si no se puede guardar, se volverá a preguntar (no es un error para el usuario)


def _tk_dialog(app, accent="#8bf5a2"):
    """True = aceptó · False = rechazó o cerró · None = no hay tkinter/pantalla."""
    try:
        import tkinter as tk
        root = tk.Tk()
    except Exception:
        return None
    bg, panel, fg = "#0e0b1a", "#17122b", "#eae6ff"
    root.title(f"{app} — Términos y condiciones"); root.configure(bg=bg)
    w, h = 660, 600
    root.geometry(f"{w}x{h}+{max(0, (root.winfo_screenwidth() - w) // 2)}+{max(0, (root.winfo_screenheight() - h) // 3)}")
    root.minsize(520, 460)
    res = {"ok": False}
    tk.Label(root, text=app, bg=bg, fg=accent, font=("Helvetica", 18, "bold")).pack(anchor="w", padx=18, pady=(14, 0))
    tk.Label(root, text="Lee y acepta los términos para usar el programa.", bg=bg, fg="#9a93b8").pack(anchor="w", padx=18, pady=(0, 8))
    box = tk.Frame(root, bg=panel); box.pack(fill="both", expand=True, padx=18)
    sb = tk.Scrollbar(box); sb.pack(side="right", fill="y")
    txt = tk.Text(box, wrap="word", bg=panel, fg=fg, relief="flat", padx=12, pady=10, yscrollcommand=sb.set,
                  font=("Helvetica", 11), spacing3=6, insertbackground=panel)
    txt.pack(fill="both", expand=True); sb.config(command=txt.yview)
    txt.insert("1.0", TERMS); txt.config(state="disabled")
    var = tk.BooleanVar(value=False)
    ok_btn = tk.Button(root, text="Aceptar y continuar", state="disabled", bg=accent, fg="#0b0814", relief="flat",
                       padx=16, pady=6, font=("Helvetica", 11, "bold"), command=lambda: (res.update(ok=True), root.destroy()))
    tk.Checkbutton(root, text="He leído y acepto los términos y condiciones", variable=var, bg=bg, fg=fg, selectcolor=panel,
                   activebackground=bg, activeforeground=fg,
                   command=lambda: ok_btn.config(state="normal" if var.get() else "disabled")).pack(anchor="w", padx=18, pady=(10, 4))
    row = tk.Frame(root, bg=bg); row.pack(fill="x", padx=18, pady=(2, 14))
    ok_btn.pack(side="left", in_=row)
    tk.Button(row, text="No acepto (salir)", bg="#2a2342", fg=fg, relief="flat", padx=16, pady=6,
              font=("Helvetica", 11), command=root.destroy).pack(side="left", padx=10)
    root.protocol("WM_DELETE_WINDOW", root.destroy)     # cerrar la ventana = no aceptar
    root.bind("<Escape>", lambda _e: root.destroy())
    root.lift(); root.focus_force(); root.mainloop()
    return res["ok"]


def terms_html(app):
    body = "".join(f"<p>{_html.escape(p)}</p>" for p in TERMS.split("\n\n"))
    return f"""<!doctype html><meta charset=utf-8><body style="margin:0;background:#0e0b1a;color:#eae6ff;font:15px system-ui,sans-serif">
<div style="max-width:760px;margin:0 auto;padding:22px 18px"><h1 style="color:#8bf5a2;margin:0 0 4px">{_html.escape(app)}</h1>
<div style="color:#9a93b8;margin-bottom:12px">Lee y acepta los términos para usar el programa.</div>
<div style="background:#17122b;border-radius:12px;padding:6px 18px;max-height:62vh;overflow:auto">{body}</div>
<label style="display:block;margin:14px 0"><input id=c type=checkbox onchange="b.disabled=!this.checked"> He leído y acepto los términos y condiciones</label>
<button id=b disabled onclick="pywebview.api.terms_accept()" style="padding:10px 18px;border:0;border-radius:8px;background:#8bf5a2;font-weight:700">Aceptar y continuar</button>
<button onclick="pywebview.api.terms_decline()" style="padding:10px 18px;border:0;border-radius:8px;background:#2a2342;color:#eae6ff;margin-left:8px">No acepto (salir)</button>
</div></body>"""


def require(app, accent="#8bf5a2"):
    """Llamar al inicio de cada programa. Si no se aceptan los términos, termina el proceso."""
    if is_accepted(app):
        return True
    r = _tk_dialog(app, accent)
    if r is None:
        sys.stderr.write("No se pudo mostrar los términos (falta tkinter o pantalla). El programa no puede iniciar.\n")
        sys.exit(1)
    if not r:
        sys.exit(0)
    mark_accepted(app)
    return True
