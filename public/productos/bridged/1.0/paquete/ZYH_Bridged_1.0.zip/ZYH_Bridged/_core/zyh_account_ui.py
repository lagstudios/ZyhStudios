# -*- coding: utf-8 -*-
"""Ventana de cuenta ZYH para las apps (CustomTkinter).

    import zyh_account_ui
    zyh_account_ui.open_dialog(parent, "compressor", on_done=lambda: self.refrescar())

Entrar o crear la cuenta ZYH activa aquí el plan que compraste en la web.
"""
import queue
import threading
import tkinter as tk
import customtkinter as ctk

try:
    from zyhcore import account as _acc, guard as _guard
except Exception:
    _acc = _guard = None

BG, PANEL, FG, MUTED, LIME, RED = "#0e0b1a", "#17122b", "#eae6ff", "#9a93b8", "#8bf5a2", "#ff6b7a"


def _products():
    try:
        from zyhcore import plans
        return {k: v["name"] for k, v in plans.PRODUCTS.items()}
    except Exception:
        return {}


class AccountDialog(ctk.CTkToplevel):
    def __init__(self, parent, product=None, on_done=None, accent=LIME):
        super().__init__(parent)
        self.product, self.on_done, self.accent = product, on_done, accent
        self.title("Cuenta ZYH"); self.geometry("520x620"); self.minsize(440, 520)
        self.configure(fg_color=BG); self.transient(parent)
        self.mode = "login"
        self.q = queue.Queue()        # los hilos NO tocan Tk: dejan aquí lo que hay que hacer
        self.body = ctk.CTkFrame(self, fg_color="transparent"); self.body.pack(fill="both", expand=True, padx=20, pady=16)
        self.build()
        self.after(120, self._pump)
        self.after(200, self.lift)

    def _pump(self):
        """Corre en el hilo principal lo que pidieron los hilos de trabajo."""
        try:
            while True:
                fn = self.q.get_nowait()
                try:
                    fn()
                except Exception as exc:
                    try:
                        self.status.configure(text=str(exc), text_color=RED)
                    except Exception:
                        pass
        except queue.Empty:
            pass
        try:
            self.after(120, self._pump)
        except Exception:
            pass

    # ------------------------------------------------------------------ utilidades
    def clear(self):
        for w in self.body.winfo_children():
            w.destroy()

    def label(self, text, **kw):
        kw.setdefault("text_color", FG); kw.setdefault("justify", "left"); kw.setdefault("anchor", "w"); kw.setdefault("wraplength", 440)
        return ctk.CTkLabel(self.body, text=text, **kw)

    def busy(self, on, text=""):
        self.status.configure(text=text, text_color=MUTED if on else FG)
        for b in getattr(self, "_buttons", []):
            try:
                b.configure(state="disabled" if on else "normal")
            except Exception:
                pass

    def run(self, fn, done):
        """Ejecuta en segundo plano para no congelar la ventana."""
        def work():
            try:
                r, err = fn(), None
            except Exception as exc:
                r, err = None, str(exc)
            self.q.put(lambda: done(r, err))
        threading.Thread(target=work, daemon=True).start()

    # ------------------------------------------------------------------ pantallas
    def build(self):
        self.clear()
        if _acc is None:
            self.label("No se pudo cargar el módulo de cuentas de ZYH.", text_color=RED).pack(fill="x", pady=20)
            return
        self.sess = _acc.session()
        (self.build_account if self.sess else self.build_login)()

    def build_login(self):
        reg = self.mode == "register"
        self.label("Cuenta ZYH", font=ctk.CTkFont(size=24, weight="bold"), text_color=self.accent).pack(fill="x")
        self.label("Entra con tu cuenta ZYH para activar aquí el plan que compraste en la web."
                   if not reg else "Crea tu cuenta ZYH. Es la misma para la web y para todas las apps.",
                   text_color=MUTED).pack(fill="x", pady=(2, 12))
        self.label("Usuario").pack(fill="x")
        self.e_user = ctk.CTkEntry(self.body, height=36); self.e_user.pack(fill="x")
        self.label("3 a 32 caracteres: letras, números, punto, guion o guion bajo.", text_color=MUTED,
                   font=ctk.CTkFont(size=11)).pack(fill="x", pady=(2, 6))
        self.label("Contraseña").pack(fill="x")
        self.e_pass = ctk.CTkEntry(self.body, show="•", height=36); self.e_pass.pack(fill="x")
        self.label(f"Mínimo {_acc.MIN_PASSWORD} caracteres.", text_color=MUTED, font=ctk.CTkFont(size=11)).pack(fill="x", pady=(2, 6))
        if reg:
            self.label("Correo (opcional)").pack(fill="x")
            self.e_mail = ctk.CTkEntry(self.body, height=36); self.e_mail.pack(fill="x", pady=(0, 6))
        self.status = self.label("", text_color=RED); self.status.pack(fill="x", pady=(8, 4))
        b1 = ctk.CTkButton(self.body, text="Crear cuenta" if reg else "Entrar", height=40, fg_color=self.accent,
                           text_color="#0b0814", font=ctk.CTkFont(size=15, weight="bold"), command=self.submit)
        b1.pack(fill="x", pady=(4, 6))
        b2 = ctk.CTkButton(self.body, text="Ya tengo cuenta" if reg else "Crear una cuenta ZYH", height=34,
                           fg_color=PANEL, hover_color="#26203f", command=self.swap)
        b2.pack(fill="x")
        self._buttons = [b1, b2]
        self.e_pass.bind("<Return>", lambda _e: self.submit())
        self.e_user.focus_set()
        self.server_row()

    def swap(self):
        self.mode = "register" if self.mode == "login" else "login"
        self.build_login()

    def submit(self):
        user, pw = self.e_user.get().strip(), self.e_pass.get()
        mail = self.e_mail.get().strip() if self.mode == "register" and hasattr(self, "e_mail") else ""
        if len(pw) < _acc.MIN_PASSWORD:
            self.status.configure(text=f"La contraseña debe tener al menos {_acc.MIN_PASSWORD} caracteres."); return
        self.busy(True, "Conectando con la web de ZYH…")
        fn = (lambda: _acc.register(user, pw, mail, "App de ZYH")) if self.mode == "register" else (lambda: _acc.login(user, pw, "App de ZYH"))

        def done(r, err):
            self.busy(False)
            if err:
                self.status.configure(text=err, text_color=RED); return
            if _guard:
                _guard.refresh()
            self.build()
            if self.on_done:
                self.on_done()
        self.run(fn, done)

    def build_account(self):
        u = self.sess
        self.label("Cuenta ZYH", font=ctk.CTkFont(size=22, weight="bold"), text_color=self.accent).pack(fill="x")
        self.label(f"Conectado como {u['username']}", text_color=FG, font=ctk.CTkFont(size=16, weight="bold")).pack(fill="x", pady=(2, 10))
        self.label("Tus planes", font=ctk.CTkFont(size=15, weight="bold")).pack(fill="x", pady=(6, 2))
        self.box = ctk.CTkFrame(self.body, fg_color=PANEL, corner_radius=12); self.box.pack(fill="both", expand=True, pady=(0, 8))
        self.status = self.label("", text_color=MUTED); self.status.pack(fill="x", pady=(2, 6))
        b1 = ctk.CTkButton(self.body, text="Actualizar planes", height=36, fg_color=self.accent, text_color="#0b0814",
                           font=ctk.CTkFont(weight="bold"), command=self.load_licenses)
        b1.pack(fill="x", pady=2)
        b2 = ctk.CTkButton(self.body, text="Cerrar sesión", height=32, fg_color=PANEL, hover_color="#3a1620",
                           text_color=RED, command=self.do_logout)
        b2.pack(fill="x", pady=2)
        self._buttons = [b1, b2]
        self.server_row()
        self.load_licenses()

    def load_licenses(self):
        for w in self.box.winfo_children():
            w.destroy()
        ctk.CTkLabel(self.box, text="Consultando…", text_color=MUTED).pack(anchor="w", padx=14, pady=10)
        self.busy(True, "")

        def done(lic, err):
            self.busy(False)
            for w in self.box.winfo_children():
                w.destroy()
            if err:
                ctk.CTkLabel(self.box, text=err, text_color=RED, wraplength=420, justify="left").pack(anchor="w", padx=14, pady=10)
                return
            names = _products()
            if not lic:
                ctk.CTkLabel(self.box, text="Todavía no tienes planes en esta cuenta.\nCómpralos en la web de ZYH y vuelve a pulsar «Actualizar planes».",
                             text_color=MUTED, justify="left").pack(anchor="w", padx=14, pady=10)
            for l in lic:
                row = ctk.CTkFrame(self.box, fg_color="transparent"); row.pack(fill="x", padx=12, pady=5)
                activo = l.get("active")
                mio = (l.get("product") == self.product)
                ctk.CTkLabel(row, text=("● " if mio else "") + f"{names.get(l.get('product'), l.get('product'))} · {l.get('plan_name', l.get('plan'))}",
                             text_color=LIME if activo else MUTED, anchor="w",
                             font=ctk.CTkFont(weight="bold" if mio else "normal")).pack(fill="x")
                dev = l.get("devices", 0)
                ctk.CTkLabel(row, text=f"{l.get('used', 0)} de {'sin límite' if dev >= 999 else dev} equipos · "
                                       + ("activo" if activo else "vencido"), text_color=MUTED, anchor="w",
                             font=ctk.CTkFont(size=11)).pack(fill="x")
            if _guard:
                _guard.refresh()
                ent = _guard.require(self.product, force=True) if self.product else None
                self.status.configure(text=(f"Plan activo en este equipo: {ent.label}." if ent else
                                            "Esta app sigue sin plan en este equipo.") if self.product else "",
                                      text_color=LIME if ent else MUTED)
            if self.on_done:
                self.on_done()
        self.run(_acc.licenses, done)

    def do_logout(self):
        self.busy(True, "Cerrando sesión…")

        def done(_r, _e):
            if _guard:
                _guard.refresh()
            self.build()
            if self.on_done:
                self.on_done()
        self.run(_acc.logout, done)

    def server_row(self):
        row = ctk.CTkFrame(self.body, fg_color="transparent"); row.pack(fill="x", pady=(10, 0))
        ctk.CTkLabel(row, text="Servidor:", text_color=MUTED, font=ctk.CTkFont(size=11)).pack(side="left")
        e = ctk.CTkEntry(row, height=26, font=ctk.CTkFont(size=11)); e.pack(side="left", fill="x", expand=True, padx=6)
        e.insert(0, _acc.base_url())

        def save():
            _acc.set_base_url(e.get())
            if _guard:
                _guard.refresh()
            self.status.configure(text="Servidor guardado.", text_color=LIME)
        ctk.CTkButton(row, text="Guardar", width=70, height=26, fg_color=PANEL, hover_color="#26203f",
                      font=ctk.CTkFont(size=11), command=save).pack(side="left")


def open_dialog(parent, product=None, on_done=None, accent=LIME):
    d = AccountDialog(parent, product, on_done, accent)
    try:
        d.grab_set()
    except Exception:
        pass
    return d


def current_username():
    try:
        return _acc.username() if _acc else None
    except Exception:
        return None
