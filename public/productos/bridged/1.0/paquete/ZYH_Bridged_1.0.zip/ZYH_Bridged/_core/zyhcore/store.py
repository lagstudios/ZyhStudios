# -*- coding: utf-8 -*-
"""Almacenamiento ÚNICO de ZYH (.zyhd) — formato propio y cifrado.

Los datos de las apps no se guardan como texto plano: se guardan en un
contenedor propio ".zyhd" cifrado con AES-256-GCM, con una llave derivada de la
ID del dispositivo. Así:
  • el formato es exclusivo de ZYH (no un .json/.txt cualquiera),
  • los datos quedan atados a ESTE equipo (no se copian a otro y se leen),
  • si alguien abre el archivo, ve datos cifrados, no tu información.

API:
    store.save(path, obj)         # obj = dict/list/str -> archivo .zyhd
    store.load(path, default)     # lee y descifra
"""
import os, json, hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

from . import deviceid

MAGIC = b"ZYHD1"
_APP_SALT = b"ZYH-STORE-v1"


def _key():
    did = deviceid.get_device_id().encode()
    return hashlib.pbkdf2_hmac("sha256", did, _APP_SALT, 120_000, dklen=32)


def save(path, obj):
    data = json.dumps(obj, ensure_ascii=False).encode("utf-8")
    nonce = os.urandom(12)
    ct = AESGCM(_key()).encrypt(nonce, data, None)
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    with open(path, "wb") as f:
        f.write(MAGIC + nonce + ct)


def load(path, default=None):
    try:
        with open(path, "rb") as f:
            blob = f.read()
        if not blob.startswith(MAGIC):
            return default
        nonce = blob[len(MAGIC):len(MAGIC) + 12]
        ct = blob[len(MAGIC) + 12:]
        data = AESGCM(_key()).decrypt(nonce, ct, None)
        return json.loads(data.decode("utf-8"))
    except Exception:
        return default
