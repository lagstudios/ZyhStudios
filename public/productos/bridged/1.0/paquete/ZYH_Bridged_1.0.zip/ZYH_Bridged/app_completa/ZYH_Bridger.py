"""ZYH_Bridger 3.1.0 Bridged — Puente multijugador para Minecraft Java (Windows y Linux).

Aplicación AUTÓNOMA: no necesita Tailscale, VPN ni ningún otro programa.
Un solo código para Windows 10/11 y Linux. Solo requiere Python 3.9+ (tkinter);
psutil es opcional (muestra el tráfico de red).

Qué hace:
- Detecta automáticamente a otros jugadores con ZYH_Bridger en la misma red (UDP).
- Añade equipos por IP (amigos fuera de tu red) y los recuerda.
- Abre el puerto de Minecraft en tu router con UPnP integrado (para jugar por Internet).
- Emparejamiento cifrado con clave de 8 dígitos (10 min, hasta 16 invitados, 5 intentos).
- Monitor de latencia (ping) y pérdida, tráfico de red, copia IP:PUERTO.

Importante: ZYH_Bridger no retransmite el tráfico de Minecraft ni aloja el mundo;
el mundo corre en el PC anfitrión (Abrir a LAN) y los invitados se conectan directo.
"""
from __future__ import annotations

import ipaddress
import json
import os
import queue
import re
import secrets
import socket
import subprocess
import threading
import time
import tkinter as tk
import sys
import hashlib as _hashlib
import customtkinter as ctk
try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM as _AESGCM
except Exception:
    _AESGCM = None

# --- ZYH: núcleo de licencias (verificación oculta; la app solo pregunta) ---
for _ZC in (os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "_core"),
            os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "_core")):
    if os.path.isdir(os.path.join(_ZC, "zyhcore")):
        sys.path.insert(0, os.path.abspath(_ZC)); break
try:
    from zyhcore import guard as _zyh_guard
except Exception:
    _zyh_guard = None


def _pair_key(pin: str) -> bytes:
    """Llave AES-256 derivada de la clave Bridged de 8 dígitos (el código nunca viaja en claro)."""
    return _hashlib.pbkdf2_hmac("sha256", pin.encode(), b"ZYH-BRIDGED-PAIR-v1", 120_000, dklen=32)


def _seal(key: bytes, obj: dict) -> dict:
    nonce = os.urandom(12)
    ct = _AESGCM(key).encrypt(nonce, json.dumps(obj).encode("utf-8"), None)
    return {"v": 2, "n": nonce.hex(), "c": ct.hex()}


def _open(key: bytes, msg: dict) -> dict:
    data = _AESGCM(key).decrypt(bytes.fromhex(msg["n"]), bytes.fromhex(msg["c"]), None)
    return json.loads(data.decode("utf-8"))
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import urlparse
from datetime import datetime
from pathlib import Path
from tkinter import messagebox, ttk
from typing import Any

try:
    import psutil  # type: ignore
except ImportError:
    psutil = None

APP_NAME = "ZYH_Bridger"
APP_VERSION = "3.1.0 Bridged"
PAIR_PORT = 45832
DISCOVERY_PORT = 45833
PEER_TTL = 20
PAIR_ROOM_SECONDS = 600
PAIR_MAX_GUESTS = 16
PAIR_MAX_FAILURES_PER_IP = 5
PING_HISTORY_SIZE = 20

IS_WINDOWS = os.name == "nt"
PLATFORM_LABEL = "Windows" if IS_WINDOWS else "Linux"
# Fuentes nativas de cada sistema (Segoe UI/Consolas no existen en Linux).
UI_FONT = "Segoe UI" if IS_WINDOWS else "DejaVu Sans"
MONO_FONT = "Consolas" if IS_WINDOWS else "DejaVu Sans Mono"
FIREWALL_NAME = "el Firewall de Windows" if IS_WINDOWS else "el firewall de Linux (ufw/firewalld)"
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)


def fit_window(win, width, height, min_w=640, min_h=480, center=True):
    """Ajusta la ventana a la pantalla: nunca mas grande que ella, centrada, y F11 = pantalla completa."""
    try:
        sw, sh = win.winfo_screenwidth(), win.winfo_screenheight()
        w = max(320, min(width, int(sw * 0.94)))
        h = max(260, min(height, int(sh * 0.90)))
        win.minsize(min(min_w, w), min(min_h, h))
        x, y = max(0, (sw - w) // 2), max(0, (sh - h) // 3)
        win.geometry(f"{w}x{h}+{x}+{y}")
        if win.master is None and not getattr(win, "_fit_f11", False):
            win._fit_f11 = True
            win.bind("<F11>", lambda e: win.attributes("-fullscreen", not win.attributes("-fullscreen")))
            win.bind("<Escape>", lambda e: win.attributes("-fullscreen", False))
    except Exception:
        pass


def app_data_dir() -> Path:
    if IS_WINDOWS:
        base = os.environ.get("APPDATA")
        root = Path(base) if base else Path.home() / ".config"
    else:
        root = Path(os.environ.get("XDG_CONFIG_HOME") or (Path.home() / ".config"))
    path = root / APP_NAME
    path.mkdir(parents=True, exist_ok=True)
    return path


PAIRED_FILE = app_data_dir() / "paired_peers.json"
MANUAL_FILE = app_data_dir() / "manual_peers.json"
PLAN_FILE = app_data_dir() / "plan.json"
SETTINGS_FILE = app_data_dir() / "settings.json"

# Opciones de Bridger (se guardan en settings.json y se aplican al arrancar y al pulsar Guardar).
DEFAULT_SETTINGS = {
    "pair_port": 45832, "discovery_port": 45833, "room_minutes": 10, "max_guests": 16,
    "max_failures": 5, "ping_history": 20, "auto_refresh": 8, "ping_host": "1.1.1.1",
    "always_on_top": False,
}
SETTINGS_LIMITS = {  # clave: (minimo, maximo)
    "pair_port": (1024, 65535), "discovery_port": (1024, 65535), "room_minutes": (1, 120),
    "max_guests": (1, 64), "max_failures": (1, 50), "ping_history": (5, 200), "auto_refresh": (3, 120),
}


def load_settings() -> dict:
    data = dict(DEFAULT_SETTINGS)
    try:
        raw = json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        for key, default in DEFAULT_SETTINGS.items():
            if key in raw and isinstance(raw[key], type(default)):
                data[key] = raw[key]
    except Exception:
        pass
    for key, (lo, hi) in SETTINGS_LIMITS.items():
        data[key] = max(lo, min(hi, int(data[key])))
    return data


def apply_settings(cfg: dict) -> None:
    global PAIR_PORT, DISCOVERY_PORT, PAIR_ROOM_SECONDS, PAIR_MAX_GUESTS, PAIR_MAX_FAILURES_PER_IP, PING_HISTORY_SIZE
    PAIR_PORT, DISCOVERY_PORT = cfg["pair_port"], cfg["discovery_port"]
    PAIR_ROOM_SECONDS = cfg["room_minutes"] * 60
    PAIR_MAX_GUESTS, PAIR_MAX_FAILURES_PER_IP = cfg["max_guests"], cfg["max_failures"]
    PING_HISTORY_SIZE = cfg["ping_history"]


SETTINGS = load_settings()
apply_settings(SETTINGS)


def run_cmd(cmd: list, timeout: int = 8) -> str:
    """Ejecuta un comando del sistema sin ventana y devuelve su texto (o '' si no existe/falla)."""
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout,
                             creationflags=NO_WINDOW, errors="replace")
        return (out.stdout or "") + (out.stderr if out.returncode else "")
    except Exception:
        return ""

# ---------------- Planes (vista + cuenta regresiva) ----------------
# PRECIOS DE EJEMPLO: cambialos aqui (un solo lugar). "days" = duracion del plan al pagar.
BRIDGER_PLANS = [
    {"id": "bridged", "name": "Minecraft fin de semana", "price": "US$5 / fin de semana", "days": 3, "guests": 4,
     "features": ["De 1 a 4 dispositivos", "Emparejamiento cifrado (clave de 8 dígitos)", "Puente Minecraft Java en LAN"]},
    {"id": "bridged_on", "name": "Bridged ON", "price": "US$9 / fin de semana", "days": 3, "guests": 8,
     "features": ["Hasta 8 dispositivos", "Todo lo de Minecraft fin de semana", "Abrir a Internet (UPnP)"]},
    {"id": "bridged_server", "name": "Bridged Server", "price": "US$19 / fin de semana", "days": 3, "guests": 16,
     "features": ["10 o más dispositivos", "Para servidores de comunidad", "Dispositivo extra: US$1"]},
]


def fmt_countdown(sec: float) -> str:
    sec = int(sec)
    d, r = divmod(sec, 86400)
    h, r = divmod(r, 3600)
    m, s = divmod(r, 60)
    return f"{d} d  {h:02d}:{m:02d}:{s:02d}"


def plan_get() -> dict | None:
    """El plan lo confirma el núcleo ZYH (online/offline), no un archivo editable."""
    import math
    from datetime import timedelta
    ent = _zyh_guard.require("bridged") if _zyh_guard else None
    if not ent:
        return None
    exp = datetime.fromtimestamp(ent.expires)
    days = max(3, math.ceil((ent.expires - time.time()) / 86400))
    return {"plan": ent.plan, "days": days, "paid_at": (exp - timedelta(days=days)).isoformat(timespec="seconds")}


def plan_set(plan_id: str, days: int) -> None:
    data = {"plan": plan_id, "days": days, "paid_at": datetime.now().isoformat(timespec="seconds")}
    PLAN_FILE.write_text(json.dumps(data), encoding="utf-8")


def plan_remaining(cur: dict):
    from datetime import timedelta
    paid = datetime.fromisoformat(cur["paid_at"])
    total = timedelta(days=int(cur["days"]))
    end = paid + total
    left = max(0.0, (end - datetime.now()).total_seconds())
    return left, max(1.0, total.total_seconds()), end


def ping_command(ip: str) -> list[str]:
    """Una sola prueba ICMP con espera máxima de ~1,6 s en cada sistema."""
    if IS_WINDOWS:
        return ["ping", "-n", "1", "-w", "1600", ip]
    return ["ping", "-c", "1", "-W", "2", ip]


def enable_windows_dpi() -> None:
    if IS_WINDOWS:
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)
        except Exception:
            pass


def valid_peer_ip(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return False
    return addr.version == 4 and not (addr.is_multicast or addr.is_unspecified or addr.is_reserved)


def local_ip() -> str:
    """IP de este equipo en la red (no envía datos: solo consulta la ruta)."""
    for target in ("10.255.255.255", "8.8.8.8"):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.connect((target, 1))
            ip = sock.getsockname()[0]
            if ip and not ip.startswith("127."):
                return ip
        except OSError:
            pass
        finally:
            sock.close()
    try:
        return socket.gethostbyname(socket.gethostname())
    except OSError:
        return ""


class Discovery(threading.Thread):
    """Anuncia este equipo y escucha a otros ZYH_Bridger en la red local (UDP)."""
    def __init__(self, name: str) -> None:
        super().__init__(daemon=True)
        self.name = name
        self.seen: dict[str, tuple[str, float]] = {}
        self.lock = threading.Lock()
        self.stop_event = threading.Event()
        self.sock: socket.socket | None = None

    def run(self) -> None:
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            sock.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
            sock.bind(("", DISCOVERY_PORT))
            sock.settimeout(0.5)
        except OSError:
            return
        self.sock = sock
        next_beacon = 0.0
        me = local_ip()
        while not self.stop_event.is_set():
            now = time.monotonic()
            if now >= next_beacon:
                next_beacon = now + 3.0
                me = local_ip() or me
                msg = json.dumps({"zyhb": 1, "name": self.name}).encode("utf-8")
                for dest in ("255.255.255.255", me.rsplit(".", 1)[0] + ".255" if me else ""):
                    if dest:
                        try:
                            sock.sendto(msg, (dest, DISCOVERY_PORT))
                        except OSError:
                            pass
            try:
                data, addr = sock.recvfrom(1024)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                info = json.loads(data.decode("utf-8"))
                if info.get("zyhb") != 1 or addr[0] == me or not valid_peer_ip(addr[0]):
                    continue
                with self.lock:
                    self.seen[addr[0]] = (str(info.get("name", "Equipo"))[:60], time.monotonic())
            except (ValueError, UnicodeDecodeError, AttributeError):
                continue

    def snapshot(self) -> dict[str, tuple[str, bool]]:
        now = time.monotonic()
        with self.lock:
            return {ip: (name, now - t <= PEER_TTL) for ip, (name, t) in self.seen.items()}

    def close(self) -> None:
        self.stop_event.set()
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass


class Upnp:
    """Abre puertos en el router con UPnP (sin programas externos)."""
    SSDP = ("239.255.255.250", 1900)
    SERVICES = ("urn:schemas-upnp-org:service:WANIPConnection:1",
                "urn:schemas-upnp-org:service:WANIPConnection:2",
                "urn:schemas-upnp-org:service:WANPPPConnection:1")

    def __init__(self) -> None:
        self.control = ""
        self.service = ""
        self.mapped: list[int] = []

    def discover(self, timeout: float = 3.0) -> bool:
        for st in ("urn:schemas-upnp-org:device:InternetGatewayDevice:1", "upnp:rootdevice"):
            request = ("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\n"
                       f"MAN: \"ssdp:discover\"\r\nMX: 2\r\nST: {st}\r\n\r\n").encode()
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(timeout)
            locations: list[str] = []
            try:
                sock.sendto(request, self.SSDP)
                end = time.monotonic() + timeout
                while time.monotonic() < end:
                    try:
                        data, _ = sock.recvfrom(4096)
                    except socket.timeout:
                        break
                    m = re.search(r"(?im)^location:\s*(\S+)", data.decode("utf-8", "replace"))
                    if m and m.group(1) not in locations:
                        locations.append(m.group(1))
            except OSError:
                pass
            finally:
                sock.close()
            for loc in locations:
                if self._read_description(loc):
                    return True
        return False

    def _read_description(self, location: str) -> bool:
        try:
            with urllib.request.urlopen(location, timeout=4) as resp:
                root = ET.fromstring(resp.read(300000))
        except (OSError, ET.ParseError, ValueError):
            return False
        for svc in root.iter():
            if svc.tag.endswith("service"):
                stype = ctrl = ""
                for child in svc:
                    if child.tag.endswith("serviceType"):
                        stype = (child.text or "").strip()
                    elif child.tag.endswith("controlURL"):
                        ctrl = (child.text or "").strip()
                if stype in self.SERVICES and ctrl:
                    base = urlparse(location)
                    self.control = ctrl if ctrl.startswith("http") else f"{base.scheme}://{base.netloc}{ctrl if ctrl.startswith('/') else '/' + ctrl}"
                    self.service = stype
                    return True
        return False

    def _soap(self, action: str, args: dict[str, str]) -> str:
        body = "".join(f"<{k}>{v}</{k}>" for k, v in args.items())
        envelope = ('<?xml version="1.0"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
                    's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body>'
                    f'<u:{action} xmlns:u="{self.service}">{body}</u:{action}></s:Body></s:Envelope>')
        req = urllib.request.Request(self.control, data=envelope.encode(), headers={
            "Content-Type": 'text/xml; charset="utf-8"', "SOAPAction": f'"{self.service}#{action}"'})
        with urllib.request.urlopen(req, timeout=5) as resp:
            return resp.read(100000).decode("utf-8", "replace")

    def add(self, port: int, internal_ip: str, label: str) -> None:
        self._soap("AddPortMapping", {
            "NewRemoteHost": "", "NewExternalPort": str(port), "NewProtocol": "TCP",
            "NewInternalPort": str(port), "NewInternalClient": internal_ip, "NewEnabled": "1",
            "NewPortMappingDescription": label, "NewLeaseDuration": "0"})
        if port not in self.mapped:
            self.mapped.append(port)

    def external_ip(self) -> str:
        m = re.search(r"<NewExternalIPAddress>([^<]+)<", self._soap("GetExternalIPAddress", {}))
        return m.group(1).strip() if m else ""

    def remove_all(self) -> None:
        for port in list(self.mapped):
            try:
                self._soap("DeletePortMapping", {"NewRemoteHost": "", "NewExternalPort": str(port), "NewProtocol": "TCP"})
            except (OSError, ValueError):
                pass
        self.mapped.clear()


def load_manual_peers() -> list[dict[str, str]]:
    try:
        data = json.loads(MANUAL_FILE.read_text(encoding="utf-8"))
        return [{"name": str(i.get("name", i.get("ip")))[:60], "ip": str(i["ip"])}
                for i in data if isinstance(i, dict) and valid_peer_ip(str(i.get("ip", "")))]
    except (OSError, ValueError, TypeError, KeyError):
        return []


def save_manual_peers(peers: list[dict[str, str]]) -> None:
    tmp = MANUAL_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(peers, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, MANUAL_FILE)


def load_paired_peers() -> list[dict[str, str]]:
    try:
        data = json.loads(PAIRED_FILE.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            return []
        clean: list[dict[str, str]] = []
        for item in data:
            if not isinstance(item, dict):
                continue
            ip = str(item.get("ip", ""))
            try:
                if not valid_peer_ip(ip):
                    continue
            except ValueError:
                continue
            clean.append({
                "name": str(item.get("name", "Equipo"))[:80],
                "ip": ip,
                "paired_at": str(item.get("paired_at", ""))[:40],
            })
        return clean
    except (OSError, ValueError, TypeError):
        return []


def save_paired_peers(peers: list[dict[str, str]]) -> None:
    # The file contains labels and IPs only, never PINs/secrets.
    tmp = PAIRED_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(peers, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, PAIRED_FILE)


class PairingRoom(threading.Thread):
    """Temporary TCP PIN listener (all interfaces, PIN + lockout protected)."""
    def __init__(self, bind_ip: str, pin: str, events: queue.Queue[dict[str, Any]]) -> None:
        super().__init__(daemon=True)
        self.bind_ip = bind_ip
        self.pin = pin
        self.key = _pair_key(pin)
        self.max_guests = PAIR_MAX_GUESTS
        self.events = events
        self.stop_event = threading.Event()
        self.server: socket.socket | None = None
        self.expires_at = time.monotonic() + PAIR_ROOM_SECONDS
        self.uses = 0
        self.failures: dict[str, int] = {}
        self.lock = threading.Lock()

    def prepare(self) -> None:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            sock.bind(("0.0.0.0", PAIR_PORT))
            sock.listen(20)
            sock.settimeout(1.0)
        except Exception:
            sock.close()
            raise
        self.server = sock

    def close(self) -> None:
        self.stop_event.set()
        if self.server:
            try:
                self.server.close()
            except OSError:
                pass

    def run(self) -> None:
        try:
            while not self.stop_event.is_set():
                if time.monotonic() >= self.expires_at:
                    break
                with self.lock:
                    if self.uses >= self.max_guests:
                        break
                try:
                    assert self.server is not None
                    conn, address = self.server.accept()
                except socket.timeout:
                    continue
                except OSError:
                    break
                with conn:
                    conn.settimeout(3.0)
                    source_ip = address[0]
                    try:
                        if not valid_peer_ip(source_ip):
                            self._send(conn, {"ok": False, "error": "Dirección no permitida."})
                            continue
                        with self.lock:
                            failures = self.failures.get(source_ip, 0)
                            uses = self.uses
                        if failures >= PAIR_MAX_FAILURES_PER_IP:
                            self._send(conn, {"ok": False, "error": "Demasiados intentos. Código bloqueado para este equipo."})
                            continue
                        raw = conn.recv(8192)
                        request = json.loads(raw.decode("utf-8"))
                        try:
                            hello = _open(self.key, request) if isinstance(request, dict) and "c" in request else None
                            valid = isinstance(hello, dict) and hello.get("hello") == "ZYH-BRIDGED"
                        except Exception:
                            valid = False
                        with self.lock:
                            if not valid:
                                self.failures[source_ip] = self.failures.get(source_ip, 0) + 1
                            elif time.monotonic() < self.expires_at and self.uses < self.max_guests:
                                self.uses += 1
                        if not valid:
                            self._send(conn, {"ok": False, "error": "Código incorrecto."})
                            continue
                        if time.monotonic() >= self.expires_at or uses >= self.max_guests:
                            self._send(conn, {"ok": False, "error": "La sala ya expiró o alcanzó el límite."})
                            continue
                        response = {"ok": True, "host_ip": self.bind_ip, "pair_port": PAIR_PORT,
                                    "version": APP_VERSION, "message": "Dispositivo emparejado."}
                        self._send(conn, _seal(self.key, response))
                        self.events.put({"type": "paired_guest", "ip": source_ip})
                    except (OSError, ValueError, json.JSONDecodeError, socket.timeout) as exc:
                        try:
                            self._send(conn, {"ok": False, "error": f"Solicitud no válida: {exc}"})
                        except OSError:
                            pass
        finally:
            if self.server:
                try:
                    self.server.close()
                except OSError:
                    pass
            self.events.put({"type": "room_closed", "room_id": id(self)})

    @staticmethod
    def _send(conn: socket.socket, data: dict[str, Any]) -> None:
        conn.sendall((json.dumps(data) + "\n").encode("utf-8"))


class ScrollTab(tk.Frame):
    """Pestaña con scroll vertical automático: si la pantalla es chica, se desplaza en vez de cortarse."""
    def __init__(self, parent, bg="#0d192b", padx=17, pady=16):
        super().__init__(parent, bg=bg)
        self.canvas = tk.Canvas(self, bg=bg, highlightthickness=0, bd=0)
        bar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.canvas.configure(yscrollcommand=bar.set)
        self.canvas.pack(side="left", fill="both", expand=True)
        self._bar = bar
        self.inner = tk.Frame(self.canvas, bg=bg, padx=padx, pady=pady)
        self._win = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", self._resize)
        self.canvas.bind("<Configure>", self._resize)
        for w in (self.canvas, self.inner):
            w.bind("<Enter>", self._bind_wheel)
            w.bind("<Leave>", self._unbind_wheel)

    def _resize(self, _e=None):
        self.canvas.itemconfigure(self._win, width=self.canvas.winfo_width())
        self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        need = self.inner.winfo_reqheight() > self.canvas.winfo_height()
        if need and not self._bar.winfo_ismapped():
            self._bar.pack(side="right", fill="y")
        elif not need and self._bar.winfo_ismapped():
            self._bar.pack_forget()
            self.canvas.yview_moveto(0)

    def _wheel(self, e):
        if self.inner.winfo_reqheight() <= self.canvas.winfo_height():
            return
        step = -1 if (getattr(e, "num", 0) == 4 or getattr(e, "delta", 0) > 0) else 1
        self.canvas.yview_scroll(step * 3, "units")

    def _bind_wheel(self, _e=None):
        self.canvas.bind_all("<MouseWheel>", self._wheel)
        self.canvas.bind_all("<Button-4>", self._wheel)
        self.canvas.bind_all("<Button-5>", self._wheel)

    def _unbind_wheel(self, _e=None):
        for ev in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            self.canvas.unbind_all(ev)


class ZYHBridger(ctk.CTk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"ZYH_Bridger {APP_VERSION} | Minecraft LAN Bridge | {PLATFORM_LABEL}")
        fit_window(self, 920 if IS_WINDOWS else 980, 790 if IS_WINDOWS else 880, 760, 560)
        ctk.set_appearance_mode("dark")
        self.configure(fg_color="#09111f")

        self.events: queue.Queue[dict[str, Any]] = queue.Queue()
        self.discovery = Discovery(socket.gethostname()[:40] or "PC")
        self.discovery.start()
        self.upnp = Upnp()
        self.manual_peers = load_manual_peers()
        self.self_ip = ""
        self.self_name = "Este equipo"
        self.peers: list[dict[str, Any]] = []
        self.peer_map: dict[str, dict[str, Any]] = {}
        self.paired_peers = load_paired_peers()
        self.pair_room: PairingRoom | None = None
        self.status_busy = False
        self.ping_busy = False
        self.ping_history: list[bool] = []
        self.last_net = None
        self.last_net_time = 0.0
        self.rx_rate = 0.0
        self.tx_rate = 0.0
        self.last_selected_ip = ""
        self._peer_signature: tuple = ()

        self.port_var = tk.StringVar(value="")
        self.status_var = tk.StringVar(value="Buscando jugadores en tu red…")
        self.identity_var = tk.StringVar(value="Red: buscando…")
        self.ping_var = tk.StringVar(value="—")
        self.loss_var = tk.StringVar(value="Pérdida: —")
        self.traffic_var = tk.StringVar(value="↓ — KB/s   ↑ — KB/s")
        self.peer_var = tk.StringVar(value="Selecciona un equipo conectado")
        self.address_var = tk.StringVar(value="Aquí aparecerá la dirección IP:PUERTO")
        self.room_code_var = tk.StringVar(value="--------")
        self.room_status_var = tk.StringVar(value="No hay sala de emparejamiento activa.")
        self.join_code_var = tk.StringVar(value="")
        self.manual_ip_var = tk.StringVar(value="")
        self.peer_count_var = tk.StringVar(value="0 equipos")
        self.peer_list_var = tk.StringVar(value="Todavía no hay equipos detectados.")

        self._build_ui()
        self.after(250, self.refresh_status)
        self.after(500, self._poll_events)
        self.after(2200, self._monitor_tick)
        self.after(2000, self._network_stats_tick)
        self.after(8000, self._auto_refresh_tick)
        self.attributes("-topmost", bool(SETTINGS["always_on_top"]))
        self.after(1500, self.wifi_refresh)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ---------------------------- UI ---------------------------------
    def _build_ui(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure("TNotebook", background="#09111f", borderwidth=0)
        style.configure("TNotebook.Tab", background="#17253b", foreground="#dbe8fa",
                        padding=(17, 9), font=(UI_FONT, 9, "bold"))
        style.map("TNotebook.Tab", background=[("selected", "#245184")],
                  foreground=[("selected", "#ffffff")])
        style.configure("TCombobox", fieldbackground="#122035", background="#122035",
                        foreground="#eef4ff", arrowcolor="#8dbdff")

        header = tk.Frame(self, bg="#101e33", padx=24, pady=18)
        header.pack(fill="x")
        row = tk.Frame(header, bg="#101e33")
        row.pack(fill="x")
        tk.Label(row, text="ZYH_Bridger", bg="#101e33", fg="#f4f7ff",
                 font=(UI_FONT, 25, "bold")).pack(side="left")
        tk.Label(row, text=f"  v{APP_VERSION}", bg="#101e33", fg="#80b9ff",
                 font=(UI_FONT, 10, "bold")).pack(side="left", pady=(10, 0))
        tk.Label(header, text="MINECRAFT JAVA  •  PRIVATE MULTIPLAYER BRIDGE",
                 bg="#101e33", fg="#a9bddb", font=(UI_FONT, 9, "bold")).pack(anchor="w", pady=(3, 0))

        dashboard = tk.Frame(self, bg="#09111f", padx=20, pady=15)
        dashboard.pack(fill="both", expand=True)

        cards = tk.Frame(dashboard, bg="#09111f")
        cards.pack(fill="x", pady=(0, 12))
        self._stat_card(cards, "ESTE EQUIPO", self.identity_var, "#8dbdff").pack(side="left", fill="both", expand=True, padx=(0, 7))
        ping_card = tk.Frame(cards, bg="#142238", padx=13, pady=11)
        ping_card.pack(side="left", fill="both", expand=True, padx=7)
        tk.Label(ping_card, text="LATENCIA", bg="#142238", fg="#91a9c8",
                 font=(UI_FONT, 8, "bold")).pack(anchor="w")
        tk.Label(ping_card, textvariable=self.ping_var, bg="#142238", fg="#82e1b5",
                 font=(UI_FONT, 17, "bold")).pack(anchor="w", pady=(3, 0))
        tk.Label(ping_card, textvariable=self.loss_var, bg="#142238", fg="#b6c6dc",
                 font=(UI_FONT, 8)).pack(anchor="w")
        self._stat_card(cards, "TRÁFICO DEL PC", self.traffic_var, "#82e1b5").pack(side="left", fill="both", expand=True, padx=(7, 0))

        status_bar = tk.Frame(dashboard, bg="#102039", padx=12, pady=9)
        status_bar.pack(fill="x", pady=(0, 12))
        tk.Label(status_bar, text="●", bg="#102039", fg="#55d69e", font=(UI_FONT, 10)).pack(side="left")
        tk.Label(status_bar, textvariable=self.status_var, bg="#102039", fg="#c4d4e9",
                 font=(UI_FONT, 9), wraplength=650, justify="left", anchor="w").pack(side="left", padx=(8, 0), fill="x", expand=True)
        self._button(status_bar, "Actualizar", self.refresh_status, small=True).pack(side="right")
        self._button(status_bar, "Abrir a Internet (UPnP)", self.open_internet, secondary=True,
                     small=True).pack(side="right", padx=(0, 7))

        self.tabs = ttk.Notebook(dashboard)
        self.tabs.pack(fill="both", expand=True)
        self._play_scroll = ScrollTab(self.tabs); self.play_tab = self._play_scroll.inner
        self._pair_scroll = ScrollTab(self.tabs); self.pair_tab = self._pair_scroll.inner
        self._network_scroll = ScrollTab(self.tabs); self.network_tab = self._network_scroll.inner
        self._plans_scroll = ScrollTab(self.tabs); self.plans_tab = self._plans_scroll.inner
        self.tabs.add(self._play_scroll, text="  JUGAR  ")
        self.tabs.add(self._pair_scroll, text="  PAIRING CODE  ")
        self.tabs.add(self._network_scroll, text="  RED Y JUGADORES  ")
        self.tabs.add(self._plans_scroll, text="  PLANES  ")
        self._wifi_scroll = ScrollTab(self.tabs); self.wifi_tab = self._wifi_scroll.inner
        self._options_scroll = ScrollTab(self.tabs); self.options_tab = self._options_scroll.inner
        self.tabs.add(self._wifi_scroll, text="  WIFI / INTERNET  ")
        self.tabs.add(self._options_scroll, text="  OPCIONES  ")
        self._build_play_tab()
        self._build_pair_tab()
        self._build_network_tab()
        self._build_plans_tab()
        self._build_wifi_tab()
        self._build_options_tab()

        footer = tk.Label(dashboard,
            text="Aplicación independiente: sin VPN ni cuentas. El mundo sigue ejecutándose en el PC anfitrión; no es un servidor en la nube.",
            bg="#09111f", fg="#8298b6", font=(UI_FONT, 8), wraplength=850, justify="left")
        footer.pack(anchor="w", pady=(10, 0))

    def _stat_card(self, parent: tk.Widget, title: str, variable: tk.StringVar, color: str) -> tk.Frame:
        card = tk.Frame(parent, bg="#142238", padx=13, pady=11)
        tk.Label(card, text=title, bg="#142238", fg="#91a9c8",
                 font=(UI_FONT, 8, "bold")).pack(anchor="w")
        tk.Label(card, textvariable=variable, bg="#142238", fg=color,
                 font=(UI_FONT, 10, "bold"), wraplength=250, justify="left").pack(anchor="w", pady=(6, 0))
        return card

    def _section(self, parent: tk.Widget, title: str, description: str = "") -> tk.Frame:
        box = tk.Frame(parent, bg="#142238", padx=15, pady=13)
        box.pack(fill="x", pady=(0, 11))
        tk.Label(box, text=title, bg="#142238", fg="#8dbdff",
                 font=(UI_FONT, 11, "bold")).pack(anchor="w")
        if description:
            tk.Label(box, text=description, bg="#142238", fg="#b1c2d9",
                     font=(UI_FONT, 9), wraplength=790, justify="left").pack(anchor="w", pady=(5, 8))
        return box

    def _button(self, parent: tk.Widget, label: str, command, secondary: bool = False,
                small: bool = False) -> tk.Button:
        bg = "#284d78" if secondary else "#176b55"
        try:
            pbg = parent.cget("bg")
        except Exception:
            pbg = "#142238"
        return ctk.CTkButton(parent, text=label, command=command, fg_color=bg, bg_color=pbg,
                             hover_color="#3974a8", text_color="white", corner_radius=10,
                             width=40, height=28 if small else 34,
                             font=(UI_FONT, 11 if small else 12, "bold"))

    def _entry(self, parent: tk.Widget, variable: tk.StringVar, width: int = 15) -> tk.Entry:
        try:
            pbg = parent.cget("bg")
        except Exception:
            pbg = "#142238"
        return ctk.CTkEntry(parent, textvariable=variable, width=width * 11 + 24, fg_color="#091626", bg_color=pbg,
                            text_color="#eef4ff", border_color="#2a405d", border_width=1,
                            corner_radius=8, font=(MONO_FONT, 13))

    def _build_plans_tab(self) -> None:
        top = self._section(self.plans_tab, "Tu plan")
        self.plan_title_var = tk.StringVar()
        self.plan_cd_var = tk.StringVar()
        self.plan_info_var = tk.StringVar()
        tk.Label(top, textvariable=self.plan_title_var, bg="#142238", fg="#55d69e", font=(UI_FONT, 11, "bold")).pack(anchor="w")
        tk.Label(top, textvariable=self.plan_cd_var, bg="#142238", fg="#eef4ff", font=(MONO_FONT, 18, "bold")).pack(anchor="w", pady=(4, 2))
        self.plan_bar = ttk.Progressbar(top, maximum=1000)
        self.plan_bar.pack(fill="x", pady=(2, 5))
        tk.Label(top, textvariable=self.plan_info_var, bg="#142238", fg="#b1c2d9", font=(UI_FONT, 9)).pack(anchor="w")
        self._zyh_account_row(top)
        row = tk.Frame(self.plans_tab, bg="#0d192b")
        row.pack(fill="both", expand=True)
        for i, pl in enumerate(BRIDGER_PLANS):
            row.grid_columnconfigure(i, weight=1, uniform="plan")
            card = tk.Frame(row, bg="#142238", padx=14, pady=12)
            card.grid(row=0, column=i, sticky="nsew", padx=5)
            tk.Label(card, text=pl["name"], bg="#142238", fg="#8dbdff", font=(UI_FONT, 15, "bold")).pack(anchor="w")
            tk.Label(card, text=pl["price"], bg="#142238", fg="#eef4ff", font=(UI_FONT, 11, "bold")).pack(anchor="w", pady=(2, 0))
            tk.Label(card, text=f"Hasta {pl['guests']} invitados por sala", bg="#142238", fg="#91a9c8", font=(UI_FONT, 9)).pack(anchor="w", pady=(2, 8))
            tk.Label(card, text="\n".join("• " + f for f in pl["features"]), bg="#142238", fg="#b1c2d9", font=(UI_FONT, 9),
                     justify="left", wraplength=210).pack(anchor="w")
            if pl["days"] > 0:
                self._button(card, "Pagar con PayPal", lambda p=pl: self._plan_register(p), small=True).pack(anchor="w", pady=(12, 0))
        self._refresh_plan()
        self.after(1000, self._plan_loop)

    def _refresh_plan(self) -> None:
        cur = plan_get()
        if cur and cur.get("days"):
            try:
                left, total, end = plan_remaining(cur)
            except (KeyError, ValueError):
                cur = None
        if cur and cur.get("days"):
            name = next((x["name"] for x in BRIDGER_PLANS if x["id"] == cur["plan"]), cur["plan"])
            self.plan_title_var.set(f"Plan activo: {name}")
            self.plan_cd_var.set("Plan finalizado" if left <= 0 else "Quedan " + fmt_countdown(left))
            self.plan_bar["value"] = int(1000 * min(1.0, max(0.0, 1 - left / total)))
            self.plan_info_var.set(f"Pago registrado: {cur['paid_at'].replace('T', ' ')} · Termina: {end:%Y-%m-%d %H:%M}")
        else:
            self.plan_title_var.set("Sin plan")
            self.plan_cd_var.set("—")
            self.plan_bar["value"] = 0
            self.plan_info_var.set("Paga tu plan con PayPal en la web de ZyhStudios; se activa en tu cuenta ZYH.")

    def _plan_loop(self) -> None:
        try:
            self._refresh_plan()
            self.after(1000, self._plan_loop)
        except tk.TclError:
            return

    def _zyh_account_row(self, parent) -> None:
        """Entrar con la cuenta ZYH: así se activa aquí el plan comprado en la web."""
        try:
            import zyh_account_ui as AU
            u = AU.current_username()
        except Exception:
            return
        row = tk.Frame(parent, bg=parent["bg"])
        row.pack(anchor="w", pady=(14, 0))
        tk.Label(row, text=(f"Cuenta ZYH: {u}" if u else "Sin cuenta ZYH en este equipo"),
                 bg=parent["bg"], fg="#82e1b5" if u else "#9fb2c9", font=(UI_FONT, 9)).pack(side="left", padx=(0, 10))
        self._button(row, "Mi cuenta ZYH" if u else "Entrar con cuenta ZYH",
                     lambda: AU.open_dialog(self, "bridged", on_done=lambda: self.after(100, self._refresh_plan_tab)),
                     small=True).pack(side="left")

    def _refresh_plan_tab(self) -> None:
        try:
            for w in self.plans_tab.winfo_children():
                w.destroy()
            self._build_plans_tab()
        except Exception:
            pass

    def _plan_register(self, pl: dict) -> None:
        messagebox.showinfo("Pagar plan", f"Plan {pl['name']} ({pl['price']}).\n\nPaga con PayPal en la web de ZyhStudios (sección Productos).\nTu plan se activa en tu cuenta ZYH y en este equipo cuando se verifique el pago.", parent=self)

    def _build_play_tab(self) -> None:
        host = self._section(self.play_tab, "1. Abrir tu mundo para otros jugadores",
            "En Minecraft Java: Esc → Abrir en LAN → Iniciar. Minecraft mostrará un puerto en el chat. Escríbelo aquí.")
        port_row = tk.Frame(host, bg="#142238")
        port_row.pack(anchor="w")
        tk.Label(port_row, text="Puerto LAN:", bg="#142238", fg="#eef4ff",
                 font=(UI_FONT, 9, "bold")).pack(side="left", padx=(0, 9))
        self._entry(port_row, self.port_var, 10).pack(side="left", ipady=5)
        tk.Label(host, textvariable=self.address_var, bg="#091626", fg="#82e1b5",
                 font=(MONO_FONT, 12, "bold"), padx=11, pady=11, anchor="w").pack(fill="x", pady=(11, 9))
        self._button(host, "Copiar MI dirección", self.copy_my_address).pack(anchor="w")

        join = self._section(self.play_tab, "2. Conectarte al mundo de otra persona",
            "Selecciona al anfitrión. Usa el mismo puerto LAN que abrió el anfitrión y copia su dirección.")
        self.peer_combo = ttk.Combobox(join, textvariable=self.peer_var, state="readonly", width=75)
        self.peer_combo.pack(fill="x", pady=(0, 9))
        self.peer_combo.bind("<<ComboboxSelected>>", self._peer_selected)
        self._button(join, "Copiar dirección del anfitrión", self.copy_peer_address, secondary=True).pack(anchor="w")

        info = tk.Label(self.play_tab,
            text="MULTIJUGADOR: varios jugadores pueden usar la misma dirección del anfitrión. El anfitrión debe mantener abierto el mundo LAN. Todos necesitan la misma versión/modpack.",
            bg="#0d192b", fg="#f0d18b", font=(UI_FONT, 9), wraplength=790, justify="left")
        info.pack(anchor="w", pady=(2, 0))

    def _build_pair_tab(self) -> None:
        host = self._section(self.pair_tab, "Crear código para invitar jugadores",
            f"El anfitrión crea una sala temporal. Comparte el código y el invitado selecciona tu equipo en la pestaña JUGAR. Puerto de emparejamiento: TCP {PAIR_PORT}.")
        code_row = tk.Frame(host, bg="#142238")
        code_row.pack(fill="x", pady=(2, 7))
        tk.Label(code_row, textvariable=self.room_code_var, bg="#091626", fg="#82e1b5",
                 font=(MONO_FONT, 25, "bold"), padx=16, pady=9).pack(side="left")
        self._button(code_row, "Crear sala / código", self.create_pairing_room).pack(side="left", padx=(12, 7))
        self._button(code_row, "Copiar código", self.copy_room_code, secondary=True).pack(side="left")
        self._button(host, "Cerrar sala", self.stop_pairing_room, secondary=True).pack(anchor="w", pady=(4, 0))
        tk.Label(host, textvariable=self.room_status_var, bg="#142238", fg="#bdcde1",
                 font=(UI_FONT, 9), wraplength=790, justify="left").pack(anchor="w", pady=(9, 0))

        guest = self._section(self.pair_tab, "Unirte con un código",
            "Selecciona el PC anfitrión en la pestaña JUGAR, pega la clave de 8 dígitos y pulsa Emparejar.")
        tk.Label(guest, text="Código del anfitrión:", bg="#142238", fg="#eef4ff",
                 font=(UI_FONT, 9, "bold")).pack(anchor="w", pady=(0, 5))
        row = tk.Frame(guest, bg="#142238")
        row.pack(anchor="w")
        self._entry(row, self.join_code_var, 12).pack(side="left", ipady=6)
        self._button(row, "Emparejar dispositivo", self.join_pairing_room).pack(side="left", padx=(9, 0))

        note = tk.Label(self.pair_tab,
            text="SEGURIDAD: el código dura 10 minutos, admite hasta 16 invitados y bloquea 5 intentos fallidos por equipo. El PIN no se guarda. No compartas el código públicamente.",
            bg="#0d192b", fg="#e7c987", font=(UI_FONT, 9), wraplength=790, justify="left")
        note.pack(anchor="w", pady=(0, 7))

    def _build_network_tab(self) -> None:
        peers = self._section(self.network_tab, "Jugadores / equipos",
            "Los equipos de tu red aparecen solos; los de fuera se añaden por IP. Para Minecraft, todos los invitados usan la IP del anfitrión más el puerto LAN.")
        tk.Label(peers, textvariable=self.peer_count_var, bg="#142238", fg="#82e1b5",
                 font=(UI_FONT, 13, "bold")).pack(anchor="w")
        self.peer_list = tk.Listbox(peers, height=9, bg="#091626", fg="#e3edfa",
                                   selectbackground="#245184", relief="flat",
                                   font=(MONO_FONT, 9), highlightthickness=0)
        self.peer_list.pack(fill="both", expand=True, pady=(8, 0))
        add_row = tk.Frame(peers, bg="#142238")
        add_row.pack(fill="x", pady=(10, 0))
        tk.Label(add_row, text="Añadir equipo por IP:", bg="#142238", fg="#eef4ff",
                 font=(UI_FONT, 9, "bold")).pack(side="left")
        self._entry(add_row, self.manual_ip_var, 22).pack(side="left", padx=8, ipady=5)
        self._button(add_row, "Añadir", self.add_manual_peer, small=True).pack(side="left")

        stats = self._section(self.network_tab, "Monitor de conexión",
            "La latencia usa ping del sistema. La pérdida es un cálculo de las últimas 20 comprobaciones; algunos routers/firewalls bloquean ICMP.")
        self.monitor_text = tk.Text(stats, height=5, bg="#091626", fg="#dbe8fa",
                                    insertbackground="white", relief="flat", wrap="word",
                                    font=(MONO_FONT, 9), padx=9, pady=8)
        self.monitor_text.pack(fill="x")
        self.monitor_text.insert("1.0", "Esperando la primera medición…")
        self.monitor_text.configure(state="disabled")

        about = tk.Label(self.network_tab,
            text="NETWORK STATS mide el tráfico total del PC, no solo Minecraft. Para estadísticas detalladas por adaptador se puede añadir una vista avanzada en otra versión.",
            bg="#0d192b", fg="#9db0ca", font=(UI_FONT, 8), wraplength=790, justify="left")
        about.pack(anchor="w")

    # ------------------------- WiFi / Internet ------------------------
    def _build_wifi_tab(self) -> None:
        self.wifi_now_var = tk.StringVar(value="Leyendo la red…")
        self.net_inet_var = tk.StringVar(value="Internet: sin comprobar")
        self.pub_ip_var = tk.StringVar(value="IP pública: sin consultar")
        self.wifi_busy = False

        top = self._section(self.wifi_tab, "Conexión actual",
            "Muestra tu WiFi, tus adaptadores (WiFi / Ethernet) y si hay Internet. Todo se lee del sistema; no se envía nada fuera salvo si pulsas «Ver IP pública».")
        tk.Label(top, textvariable=self.wifi_now_var, bg="#142238", fg="#e3edfa", font=(MONO_FONT, 9),
                 justify="left", anchor="w", wraplength=790).pack(fill="x")
        tk.Label(top, textvariable=self.net_inet_var, bg="#142238", fg="#82e1b5", font=(UI_FONT, 10, "bold")).pack(anchor="w", pady=(8, 0))
        tk.Label(top, textvariable=self.pub_ip_var, bg="#142238", fg="#8dbdff", font=(UI_FONT, 9)).pack(anchor="w")
        row = tk.Frame(top, bg="#142238"); row.pack(fill="x", pady=(10, 0))
        self._button(row, "Actualizar", self.wifi_refresh, small=True).pack(side="left")
        self._button(row, "Probar Internet", self.wifi_test_internet, secondary=True, small=True).pack(side="left", padx=7)
        self._button(row, "Ver IP pública", self.wifi_public_ip, secondary=True, small=True).pack(side="left")
        if not IS_WINDOWS:
            self._button(row, "WiFi ON", lambda: self._wifi_radio("on"), secondary=True, small=True).pack(side="right")
            self._button(row, "WiFi OFF", lambda: self._wifi_radio("off"), secondary=True, small=True).pack(side="right", padx=(0, 7))

        scan = self._section(self.wifi_tab, "Redes WiFi cercanas",
            "Selecciona una red y pulsa Conectar. En Linux usa NetworkManager (nmcli); en Windows solo redes cuyo perfil ya guardó Windows.")
        self.wifi_list = tk.Listbox(scan, height=7, bg="#091626", fg="#e3edfa", selectbackground="#245184",
                                    relief="flat", font=(MONO_FONT, 9), highlightthickness=0)
        self.wifi_list.pack(fill="x")
        self.wifi_scan_items: list[dict[str, str]] = []
        row2 = tk.Frame(scan, bg="#142238"); row2.pack(fill="x", pady=(9, 0))
        self._button(row2, "Buscar redes", self.wifi_scan, small=True).pack(side="left")
        self._button(row2, "Conectar", self.wifi_connect, secondary=True, small=True).pack(side="left", padx=7)
        self.wifi_msg_var = tk.StringVar(value="")
        tk.Label(row2, textvariable=self.wifi_msg_var, bg="#142238", fg="#b1c2d9", font=(UI_FONT, 9)).pack(side="left", padx=8)

    def _wifi_info(self) -> str:
        lines: list[str] = []
        if IS_WINDOWS:
            text = run_cmd(["netsh", "wlan", "show", "interfaces"])
            ssid = re.search(r"^\s*SSID\s*:\s*(.+)$", text, re.M)
            sig = re.search(r"^\s*(?:Signal|Señal)\s*:\s*(.+)$", text, re.M)
            lines.append(f"WiFi: {ssid.group(1).strip() if ssid else 'sin conexión / sin adaptador'}"
                         + (f"   señal {sig.group(1).strip()}" if sig else ""))
        else:
            ssid = run_cmd(["iwgetid", "-r"]).strip()
            if not ssid:
                for ln in run_cmd(["nmcli", "-t", "-f", "ACTIVE,SSID,SIGNAL", "dev", "wifi"]).splitlines():
                    parts = ln.split(":")
                    if parts and parts[0] == "yes":
                        ssid = f"{parts[1]} (señal {parts[2]}%)" if len(parts) > 2 else parts[1]
                        break
            lines.append(f"WiFi: {ssid or 'sin conexión / sin adaptador / nmcli no instalado'}")
        if psutil:
            try:
                stats = psutil.net_if_stats()
                for name, addrs in psutil.net_if_addrs().items():
                    ipv4 = [a.address for a in addrs if a.family == socket.AF_INET]
                    if not ipv4 or name.lower() in ("lo",) or ipv4[0].startswith("127."):
                        continue
                    low = name.lower()
                    kind = "WiFi" if any(k in low for k in ("wl", "wi-fi", "wifi", "wireless")) else \
                           "Ethernet" if any(k in low for k in ("eth", "en", "ethernet")) else "Otro"
                    up = "activo" if stats.get(name) and stats[name].isup else "caído"
                    speed = stats[name].speed if stats.get(name) else 0
                    lines.append(f"{kind:<8} {name[:16]:<16} {ipv4[0]:<15} {up}" + (f"  {speed} Mbps" if speed else ""))
            except Exception:
                pass
        else:
            lines.append(f"IP local: {getattr(self, 'self_ip', '') or 'desconocida'}   (instala psutil para ver todos los adaptadores)")
        lines.append(f"Equipo: {socket.gethostname()}   Puerto de emparejamiento: TCP {PAIR_PORT}")
        return "\n".join(lines)

    def _wifi_run(self, work, done) -> None:
        """Ejecuta work() en un hilo y llama done(resultado) en la ventana."""
        def runner():
            try:
                res = work()
            except Exception as exc:  # noqa: BLE001
                res = exc
            try:
                self.after(0, lambda: done(res))
            except Exception:
                pass
        threading.Thread(target=runner, daemon=True).start()

    def wifi_refresh(self) -> None:
        self._wifi_run(self._wifi_info, lambda r: self.wifi_now_var.set(str(r)))
        self.wifi_test_internet()

    def wifi_test_internet(self) -> None:
        host = SETTINGS["ping_host"]
        def work():
            t0 = time.monotonic()
            with socket.create_connection((host, 53), timeout=3):
                ms = (time.monotonic() - t0) * 1000
            try:
                socket.gethostbyname("example.com"); dns = "DNS ok"
            except OSError:
                dns = "DNS falla"
            return f"Internet: CONECTADO ({ms:.0f} ms a {host}, {dns})"
        self._wifi_run(work, lambda r: self.net_inet_var.set(
            r if isinstance(r, str) else "Internet: SIN CONEXIÓN (¿WiFi/cable desconectado?)"))

    def wifi_public_ip(self) -> None:
        if not messagebox.askyesno("IP pública", "Se consultará api.ipify.org para saber tu IP pública.\n¿Continuar?"):
            return
        def work():
            with urllib.request.urlopen("https://api.ipify.org", timeout=6) as resp:
                return resp.read().decode().strip()
        self._wifi_run(work, lambda r: self.pub_ip_var.set(
            f"IP pública: {r}" if isinstance(r, str) else "IP pública: no se pudo consultar"))

    def wifi_scan(self) -> None:
        self.wifi_msg_var.set("Buscando…")
        def work():
            items = []
            if IS_WINDOWS:
                for m in re.finditer(r"^SSID \d+ : (.*)$", run_cmd(["netsh", "wlan", "show", "networks"], 12), re.M):
                    if m.group(1).strip():
                        items.append({"ssid": m.group(1).strip(), "signal": "?", "sec": ""})
            else:
                out = run_cmd(["nmcli", "-t", "-f", "SSID,SIGNAL,SECURITY", "dev", "wifi", "list", "--rescan", "yes"], 15)
                seen = set()
                for ln in out.splitlines():
                    parts = ln.replace("\\:", "\x00").split(":")
                    if len(parts) >= 2 and parts[0] and parts[0] not in seen:
                        seen.add(parts[0])
                        items.append({"ssid": parts[0].replace("\x00", ":"), "signal": parts[1],
                                      "sec": (parts[2] if len(parts) > 2 else "") or "abierta"})
            return sorted(items, key=lambda i: -int(i["signal"]) if i["signal"].isdigit() else 0)
        def done(res):
            self.wifi_list.delete(0, "end")
            self.wifi_scan_items = res if isinstance(res, list) else []
            for it in self.wifi_scan_items:
                bar = "█" * (int(it["signal"]) // 25 + 1) if it["signal"].isdigit() else ""
                self.wifi_list.insert("end", f"{it['ssid'][:30]:<30} {bar:<5} {it['signal']:>3}  {it['sec']}")
            self.wifi_msg_var.set(f"{len(self.wifi_scan_items)} redes" if self.wifi_scan_items else "No se encontraron redes (¿sin adaptador o sin nmcli/netsh?)")
        self._wifi_run(work, done)

    def wifi_connect(self) -> None:
        sel = self.wifi_list.curselection()
        if not sel:
            messagebox.showinfo("WiFi", "Primero busca redes y selecciona una.")
            return
        item = self.wifi_scan_items[sel[0]]
        ssid = item["ssid"]
        password = ""
        if not IS_WINDOWS and item["sec"] != "abierta":
            from tkinter import simpledialog
            password = simpledialog.askstring("WiFi", f"Contraseña de «{ssid}» (vacía = usar la guardada):", show="*", parent=self) or ""
        if not messagebox.askyesno("Conectar", f"¿Cambiar la conexión WiFi a «{ssid}»?"):
            return
        self.wifi_msg_var.set("Conectando…")
        def work():
            if IS_WINDOWS:
                return run_cmd(["netsh", "wlan", "connect", f"name={ssid}", f"ssid={ssid}"], 15)
            cmd = ["nmcli", "dev", "wifi", "connect", ssid] + (["password", password] if password else [])
            return run_cmd(cmd, 30) or "Conectado."
        def done(res):
            self.wifi_msg_var.set(str(res).strip().splitlines()[-1][:80] if str(res).strip() else "Listo")
            self.wifi_refresh()
        self._wifi_run(work, done)

    def _wifi_radio(self, state: str) -> None:
        self._wifi_run(lambda: run_cmd(["nmcli", "radio", "wifi", state]) or "ok",
                       lambda r: (self.wifi_msg_var.set(f"WiFi {state.upper()}"), self.after(1500, self.wifi_refresh)))

    # ------------------------------ Opciones --------------------------
    def _build_options_tab(self) -> None:
        self.opt_vars: dict[str, tk.Variable] = {}
        box = self._section(self.options_tab, "Opciones de ZYH Bridger",
            "Se guardan en tu equipo (settings.json). Los puertos se aplican al reiniciar Bridger; lo demás, al guardar.")
        labels = [
            ("pair_port", "Puerto de emparejamiento (TCP)"), ("discovery_port", "Puerto de descubrimiento (UDP)"),
            ("room_minutes", "Duración de la sala (minutos)"), ("max_guests", "Invitados máximos por sala"),
            ("max_failures", "Intentos fallidos por IP"), ("ping_history", "Muestras del monitor de latencia"),
            ("auto_refresh", "Actualizar red cada (segundos)"),
        ]
        grid = tk.Frame(box, bg="#142238"); grid.pack(fill="x")
        for i, (key, text) in enumerate(labels):
            var = tk.StringVar(value=str(SETTINGS[key])); self.opt_vars[key] = var
            tk.Label(grid, text=text, bg="#142238", fg="#eef4ff", font=(UI_FONT, 9)).grid(row=i, column=0, sticky="w", pady=4)
            self._entry(grid, var, 8).grid(row=i, column=1, padx=12, ipady=3)
            lo, hi = SETTINGS_LIMITS[key]
            tk.Label(grid, text=f"{lo}–{hi}", bg="#142238", fg="#7f93b0", font=(UI_FONT, 8)).grid(row=i, column=2, sticky="w")
        r = len(labels)
        tk.Label(grid, text="Servidor para probar Internet", bg="#142238", fg="#eef4ff", font=(UI_FONT, 9)).grid(row=r, column=0, sticky="w", pady=4)
        self.opt_vars["ping_host"] = tk.StringVar(value=SETTINGS["ping_host"])
        self._entry(grid, self.opt_vars["ping_host"], 16).grid(row=r, column=1, padx=12, ipady=3, sticky="w")
        self.opt_vars["always_on_top"] = tk.BooleanVar(value=bool(SETTINGS["always_on_top"]))
        tk.Checkbutton(grid, text="Mantener Bridger siempre encima", variable=self.opt_vars["always_on_top"],
                       bg="#142238", fg="#eef4ff", selectcolor="#091626", activebackground="#142238",
                       activeforeground="white", font=(UI_FONT, 9)).grid(row=r + 1, column=0, columnspan=2, sticky="w", pady=6)
        btns = tk.Frame(box, bg="#142238"); btns.pack(fill="x", pady=(10, 0))
        self._button(btns, "Guardar", self.options_save).pack(side="left")
        self._button(btns, "Valores por defecto", self.options_reset, secondary=True).pack(side="left", padx=8)
        self._button(btns, "Abrir carpeta de datos", self.options_open_folder, secondary=True).pack(side="left")
        self.opt_msg_var = tk.StringVar(value="")
        tk.Label(box, textvariable=self.opt_msg_var, bg="#142238", fg="#82e1b5", font=(UI_FONT, 9)).pack(anchor="w", pady=(8, 0))

        fw = self._section(self.options_tab, "Permisos y firewall",
            "Para que otros equipos se conecten, permite estos puertos en " + FIREWALL_NAME + ". Linux: ejecuta PERMISOS_LINUX.sh. Windows: ejecuta PERMISOS_WINDOWS.bat como administrador.")
        tk.Label(fw, text=f"Puertos en uso ahora: TCP {PAIR_PORT} · UDP {DISCOVERY_PORT}   |   Datos: {app_data_dir()}",
                 bg="#142238", fg="#b1c2d9", font=(MONO_FONT, 8), wraplength=790, justify="left").pack(anchor="w")

    def options_save(self) -> None:
        new = dict(SETTINGS)
        try:
            for key, (lo, hi) in SETTINGS_LIMITS.items():
                val = int(str(self.opt_vars[key].get()).strip())
                if not lo <= val <= hi:
                    raise ValueError(f"{key} debe estar entre {lo} y {hi}")
                new[key] = val
        except ValueError as exc:
            messagebox.showerror("Opciones", f"Valor no válido: {exc}")
            return
        new["ping_host"] = str(self.opt_vars["ping_host"].get()).strip() or DEFAULT_SETTINGS["ping_host"]
        new["always_on_top"] = bool(self.opt_vars["always_on_top"].get())
        ports_changed = (new["pair_port"], new["discovery_port"]) != (SETTINGS["pair_port"], SETTINGS["discovery_port"])
        try:
            SETTINGS_FILE.write_text(json.dumps(new, indent=2), encoding="utf-8")
        except OSError as exc:
            messagebox.showerror("Opciones", f"No se pudo guardar: {exc}")
            return
        keep_ports = (PAIR_PORT, DISCOVERY_PORT)
        SETTINGS.update(new)
        apply_settings(SETTINGS)
        if ports_changed:   # los sockets ya abiertos siguen en el puerto viejo hasta reiniciar
            globals().update(PAIR_PORT=keep_ports[0], DISCOVERY_PORT=keep_ports[1])
        self.attributes("-topmost", bool(new["always_on_top"]))
        self.opt_msg_var.set("Guardado. " + ("Reinicia Bridger para usar los puertos nuevos." if ports_changed else "Aplicado."))

    def options_reset(self) -> None:
        for key, val in DEFAULT_SETTINGS.items():
            var = self.opt_vars[key]
            var.set(bool(val) if isinstance(val, bool) else str(val))
        self.opt_msg_var.set("Valores por defecto cargados: pulsa Guardar para aplicarlos.")

    def options_open_folder(self) -> None:
        path = str(app_data_dir())
        try:
            if IS_WINDOWS:
                os.startfile(path)  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except Exception:
            messagebox.showinfo("Datos", path)

    # ------------------------- Red / jugadores -----------------------
    def refresh_status(self) -> None:
        if self.status_busy:
            return
        self.status_busy = True
        self.status_var.set("Buscando jugadores en tu red…")
        threading.Thread(target=self._refresh_worker, daemon=True).start()

    def _refresh_worker(self) -> None:
        try:
            ip = local_ip()
            if not ip:
                raise RuntimeError("No se detectó conexión de red. Conéctate a Wi-Fi/Ethernet y pulsa Actualizar.")
            found = self.discovery.snapshot()
            peers: dict[str, dict[str, Any]] = {}
            for ip_, (name, online) in found.items():
                peers[ip_] = {"name": name, "ip": ip_, "online": online}
            for item in self.manual_peers + self.paired_peers:
                if item["ip"] not in peers and item["ip"] != ip:
                    peers[item["ip"]] = {"name": item.get("name", item["ip"]), "ip": item["ip"], "online": True}
            ordered = sorted(peers.values(), key=lambda p: (not p["online"], str(p["name"]).lower()))
            self.events.put({"type": "status_ok", "ip": ip, "name": socket.gethostname() or "Este equipo",
                             "peers": ordered})
        except (RuntimeError, OSError) as exc:
            self.events.put({"type": "status_error", "error": str(exc)})
        finally:
            self.events.put({"type": "status_done"})

    def add_manual_peer(self) -> None:
        raw = self.manual_ip_var.get().strip()
        try:
            ip = socket.gethostbyname(raw) if raw else ""
        except OSError:
            ip = ""
        if not valid_peer_ip(ip):
            messagebox.showwarning("IP no válida", "Escribe la IP (o nombre) del equipo, por ejemplo 192.168.1.20 o la IP pública del anfitrión.")
            return
        if not any(p["ip"] == ip for p in self.manual_peers):
            self.manual_peers.append({"name": raw if raw != ip else f"Equipo {ip}", "ip": ip})
            try:
                save_manual_peers(self.manual_peers)
            except OSError as exc:
                self.status_var.set(f"No se pudo guardar la lista: {exc}")
        self.manual_ip_var.set("")
        self.refresh_status()

    def open_internet(self) -> None:
        port = self._get_port()
        if port is None:
            return
        if not self.self_ip:
            messagebox.showwarning("Sin red", "No se detectó tu red. Conéctate y pulsa Actualizar.")
            return
        self.status_var.set("Abriendo el puerto en tu router (UPnP)…")
        threading.Thread(target=self._upnp_worker, args=(port, self.self_ip), daemon=True).start()

    def _upnp_worker(self, port: int, ip: str) -> None:
        try:
            if not self.upnp.control and not self.upnp.discover():
                raise RuntimeError("Tu router no respondió a UPnP (puede estar desactivado). Activa UPnP en el router o abre el puerto "
                                   f"{port} manualmente.")
            self.upnp.add(port, ip, "ZYH_Bridger Minecraft")
            self.upnp.add(PAIR_PORT, ip, "ZYH_Bridger Pairing")
            public = self.upnp.external_ip()
            if not public:
                raise RuntimeError("El router abrió el puerto pero no informó su IP pública.")
            self.events.put({"type": "upnp_ok", "address": f"{public}:{port}"})
        except (RuntimeError, OSError, ValueError) as exc:
            self.events.put({"type": "status_text", "text": f"UPnP: {exc}"})

    def _peer_label(self, peer: dict[str, Any]) -> str:
        state = "EN LÍNEA" if peer["online"] else "sin conexión"
        return f"{peer['name']}  |  {peer['ip']}  |  {state}" + ("  |  PAIRED" if self._is_paired(peer["ip"]) else "")

    def _render_peers(self, force: bool = False) -> None:
        """Redibuja combo y lista solo si algo cambió y conserva el equipo elegido (por IP)."""
        signature = tuple((p["name"], p["ip"], p["online"], self._is_paired(p["ip"])) for p in self.peers)
        if not force and signature == self._peer_signature:
            return
        self._peer_signature = signature
        current = self.peer_map.get(self.peer_var.get())
        keep_ip = self.last_selected_ip or (current["ip"] if current else "")
        self.peer_map = {}
        labels = []
        for peer in self.peers:
            label = self._peer_label(peer)
            peer["label"] = label
            self.peer_map[label] = peer
            labels.append(label)
        self.peer_combo["values"] = labels
        same = next((p["label"] for p in self.peers if p["ip"] == keep_ip), "")
        if same:
            self.peer_var.set(same)
        elif self.peer_var.get() not in self.peer_map:
            online = next((p["label"] for p in self.peers if p["online"]), "")
            self.peer_var.set(online or (labels[0] if labels else "No hay equipos: añade uno por IP"))
        self.peer_count_var.set(f"{sum(1 for p in self.peers if p['online'])} en línea  /  {len(self.peers)} conocidos")
        self.peer_list.delete(0, "end")
        if not self.peers:
            self.peer_list.insert("end", "No hay otros equipos todavía. Añade uno por IP o abre ZYH_Bridger en otro PC de tu red.")
        for peer in self.peers:
            state = "ONLINE " if peer["online"] else "OFFLINE"
            paired = "  [PAIRED]" if self._is_paired(peer["ip"]) else ""
            self.peer_list.insert("end", f"{state:<7} {peer['name']}  {peer['ip']}{paired}")

    def _apply_status(self, event: dict[str, Any]) -> None:
        self.self_ip = event["ip"]
        self.self_name = event["name"]
        self.peers = event["peers"]
        self.identity_var.set(f"{self.self_name}\n{self.self_ip}")
        self._render_peers()
        self.status_var.set(f"Red lista. {len(self.peers)} equipo(s) conocido(s). Revisión automática activa.")

    def _is_paired(self, ip: str) -> bool:
        return any(item.get("ip") == ip for item in self.paired_peers)

    def _peer_selected(self, _event=None) -> None:
        peer = self.peer_map.get(self.peer_var.get())
        self.last_selected_ip = peer["ip"] if peer else ""
        self.ping_history.clear()
        self.ping_var.set("Midiendo…")

    # -------------------------- Pairing ------------------------------
    def create_pairing_room(self) -> None:
        if not self.self_ip:
            messagebox.showwarning("Sin conexión", "No se detectó tu red. Conéctate a una red y pulsa Actualizar.")
            return
        self.stop_pairing_room(show_message=False)
        ent = _zyh_guard.require("bridged") if _zyh_guard else None
        if not ent:
            messagebox.showinfo("Necesitas un plan", "Para crear salas compra un plan en la pestaña PLANES.")
            return
        pin = f"{secrets.randbelow(100_000_000):08d}"
        room = PairingRoom(self.self_ip, pin, self.events)
        room.max_guests = {"bridged": 4, "bridged_on": 8}.get(ent.plan, PAIR_MAX_GUESTS)
        try:
            room.prepare()
            room.start()
        except OSError as exc:
            messagebox.showerror("No se pudo crear la sala", f"No se pudo abrir el puerto TCP {PAIR_PORT}.\n\n{exc}\n\nComprueba si otra instancia está usando el puerto y permite ZYH_Bridger en {FIREWALL_NAME}.")
            return
        self.pair_room = room
        self.room_code_var.set(pin)
        self.room_status_var.set(f"Sala activa durante 10 minutos. Hasta {room.max_guests} invitados. Comparte el código y tu IP.")
        self.status_var.set("Sala de emparejamiento iniciada. Esperando invitados autorizados…")

    def stop_pairing_room(self, show_message: bool = True) -> None:
        if self.pair_room:
            self.pair_room.close()
            self.pair_room = None
        self.room_code_var.set("--------")
        self.room_status_var.set("Sala cerrada.")
        if show_message:
            self.status_var.set("Sala de emparejamiento cerrada.")

    def copy_room_code(self) -> None:
        code = self.room_code_var.get()
        if not code.isdigit():
            messagebox.showinfo("No hay código", "Primero crea una sala de emparejamiento.")
            return
        self._copy(code)
        self.status_var.set("Código de emparejamiento copiado al portapapeles.")

    def _copy(self, text: str) -> None:
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update_idletasks()  # fija el contenido de inmediato (importante en Linux/X11)

    def join_pairing_room(self) -> None:
        code = self.join_code_var.get().strip()
        if not re.fullmatch(r"\d{8}", code):
            messagebox.showwarning("Código inválido", "La clave Bridged debe tener exactamente 8 dígitos.")
            return
        peer = self.peer_map.get(self.peer_var.get())
        if not peer:
            messagebox.showwarning("Selecciona al anfitrión", "Primero selecciona el PC anfitrión en la pestaña JUGAR.")
            return
        if not peer["online"]:
            messagebox.showwarning("Equipo desconectado", "El anfitrión aparece desconectado.")
            return
        threading.Thread(target=self._pair_client_worker, args=(peer, code), daemon=True).start()
        self.room_status_var.set(f"Solicitando emparejamiento con {peer['name']}…")

    def _pair_client_worker(self, peer: dict[str, Any], code: str) -> None:
        try:
            with socket.create_connection((peer["ip"], PAIR_PORT), timeout=5) as conn:
                conn.settimeout(5)
                key = _pair_key(code)
                request = _seal(key, {"hello": "ZYH-BRIDGED", "version": APP_VERSION})
                conn.sendall(json.dumps(request).encode("utf-8"))
                raw = conn.recv(8192).decode("utf-8", errors="replace").strip()
            response = json.loads(raw)
            if isinstance(response, dict) and "c" in response:
                response = _open(key, response)
            if not response.get("ok"):
                raise RuntimeError(response.get("error", "Emparejamiento rechazado."))
            self.events.put({"type": "paired_host", "peer": peer})
        except Exception as exc:
            self.events.put({"type": "pair_error", "error": str(exc) or "Clave Bridged incorrecta."})

    def _add_paired_peer(self, ip: str, name: str) -> None:
        try:
            if not valid_peer_ip(ip):
                return
        except ValueError:
            return
        self.paired_peers = [p for p in self.paired_peers if p.get("ip") != ip]
        self.paired_peers.append({"name": name, "ip": ip,
                                  "paired_at": datetime.now().astimezone().isoformat(timespec="minutes")})
        self.paired_peers.sort(key=lambda p: p.get("name", "").lower())
        try:
            save_paired_peers(self.paired_peers)
        except OSError as exc:
            self.status_var.set(f"Emparejado, pero no se pudo guardar la lista local: {exc}")
        self._apply_peer_labels()

    def _apply_peer_labels(self) -> None:
        # Se conserva el nombre de la 2.0; ahora usa el renderizado optimizado.
        self._render_peers(force=True)

    # ----------------------- Game address ----------------------------
    def _get_port(self) -> int | None:
        raw = self.port_var.get().strip()
        try:
            port = int(raw)
        except ValueError:
            messagebox.showwarning("Puerto inválido", "Escribe el puerto numérico que Minecraft mostró al abrir el mundo en LAN.")
            return None
        if not 1 <= port <= 65535:
            messagebox.showwarning("Puerto inválido", "El puerto debe estar entre 1 y 65535.")
            return None
        return port

    def copy_my_address(self) -> None:
        port = self._get_port()
        if port is None:
            return
        if not self.self_ip:
            messagebox.showwarning("Sin conexión", "No se detectó tu red. Conéctate y pulsa Actualizar.")
            return
        address = f"{self.self_ip}:{port}"
        self.address_var.set(address)
        self._copy(address)
        self.status_var.set(f"Dirección del anfitrión copiada: {address}")

    def copy_peer_address(self) -> None:
        port = self._get_port()
        if port is None:
            return
        peer = self.peer_map.get(self.peer_var.get())
        if not peer:
            messagebox.showwarning("Sin anfitrión", "Selecciona un equipo y actualiza la conexión.")
            return
        address = f"{peer['ip']}:{port}"
        self._copy(address)
        self.status_var.set(f"Dirección de {peer['name']} copiada: {address}")
        messagebox.showinfo("Dirección lista", f"Minecraft → Multijugador → Conexión directa:\n\n{address}")

    # ---------------------- Monitor / stats --------------------------
    def _monitor_tick(self) -> None:
        peer = self.peer_map.get(self.peer_var.get())
        if peer and peer["online"] and not self.ping_busy:
            self.ping_busy = True
            threading.Thread(target=self._ping_worker, args=(peer,), daemon=True).start()
        self.after(5000, self._monitor_tick)

    def _ping_worker(self, peer: dict[str, Any]) -> None:
        try:
            result = subprocess.run(ping_command(peer["ip"]),
                                    capture_output=True, text=True, encoding="utf-8",
                                    errors="replace", timeout=4, creationflags=NO_WINDOW, check=False)
            output = result.stdout + " " + result.stderr
            match = re.search(r"(?:time|tiempo)[=<]\s*(\d+(?:[.,]\d+)?)\s*ms", output, re.IGNORECASE)
            if match and result.returncode == 0:
                latency = float(match.group(1).replace(",", "."))
                if "<" in match.group(0):
                    latency = min(latency, 1.0)
                self.events.put({"type": "ping_result", "ip": peer["ip"], "ok": True, "ms": latency})
            else:
                self.events.put({"type": "ping_result", "ip": peer["ip"], "ok": False, "ms": None})
        except (OSError, subprocess.TimeoutExpired):
            self.events.put({"type": "ping_result", "ip": peer["ip"], "ok": False, "ms": None})
        finally:
            self.events.put({"type": "ping_done"})

    def _network_stats_tick(self) -> None:
        if psutil:
            try:
                now = time.monotonic()
                current = psutil.net_io_counters()
                if self.last_net is not None:
                    elapsed = max(now - self.last_net_time, 0.001)
                    self.rx_rate = max(0, current.bytes_recv - self.last_net.bytes_recv) / elapsed
                    self.tx_rate = max(0, current.bytes_sent - self.last_net.bytes_sent) / elapsed
                    self.traffic_var.set(f"↓ {self._format_rate(self.rx_rate)}   ↑ {self._format_rate(self.tx_rate)}")
                self.last_net = current
                self.last_net_time = now
            except Exception:
                self.traffic_var.set("No disponible")
        else:
            self.traffic_var.set("Instala psutil")
        self.after(2000, self._network_stats_tick)

    @staticmethod
    def _format_rate(value: float) -> str:
        if value >= 1024 * 1024:
            return f"{value / (1024 * 1024):.2f} MB/s"
        return f"{value / 1024:.1f} KB/s"

    def _auto_refresh_tick(self) -> None:
        # Relee la red y los equipos detectados periódicamente.
        if not self.status_busy:
            self.refresh_status()
        self.after(SETTINGS["auto_refresh"] * 1000, self._auto_refresh_tick)

    # ----------------------------- Events ----------------------------
    def _poll_events(self) -> None:
        try:
            while True:
                event = self.events.get_nowait()
                kind = event.get("type")
                if kind == "status_ok":
                    self._apply_status(event)
                elif kind == "status_error":
                    self.identity_var.set("Sin red")
                    self.status_var.set(event["error"])
                    self.ping_var.set("—")
                elif kind == "status_done":
                    self.status_busy = False
                elif kind == "paired_guest":
                    ip = event["ip"]
                    peer = next((p for p in self.peers if p["ip"] == ip), None)
                    name = peer["name"] if peer else ip
                    self._add_paired_peer(ip, name)
                    self.room_status_var.set(f"Invitado emparejado: {name} ({ip}).")
                    self.status_var.set(f"Dispositivo emparejado: {name}.")
                elif kind == "paired_host":
                    peer = event["peer"]
                    self._add_paired_peer(peer["ip"], peer["name"])
                    self.room_status_var.set(f"Emparejamiento completado con {peer['name']}.")
                    self.status_var.set(f"Emparejado con {peer['name']}.")
                elif kind == "pair_error":
                    self.room_status_var.set(f"No se pudo emparejar: {event['error']}")
                    self.status_var.set(f"Emparejamiento fallido. Comprueba el código y {FIREWALL_NAME}.")
                elif kind == "upnp_ok":
                    self.address_var.set(event["address"])
                    self._copy(event["address"])
                    self.status_var.set(f"Puerto abierto. Tus amigos usan {event['address']} (copiado).")
                elif kind == "status_text":
                    self.status_var.set(event["text"])
                elif kind == "refresh":
                    self.refresh_status()
                elif kind == "room_closed":
                    if self.pair_room and id(self.pair_room) == event.get("room_id"):
                        self.pair_room = None
                        self.room_code_var.set("--------")
                        self.room_status_var.set("La sala terminó: expiró, se cerró o llegó al límite de invitados.")
                elif kind == "ping_result":
                    if event["ip"] == self.last_selected_ip or not self.last_selected_ip:
                        self.ping_history.append(bool(event["ok"]))
                        self.ping_history = self.ping_history[-PING_HISTORY_SIZE:]
                        if event["ok"]:
                            ms = event["ms"]
                            self.ping_var.set(f"{ms:.1f} ms" if ms >= 1 else f"{ms:.2f} ms")
                        else:
                            self.ping_var.set("Sin respuesta")
                        lost = self.ping_history.count(False)
                        pct = (lost / len(self.ping_history)) * 100 if self.ping_history else 0
                        self.loss_var.set(f"Pérdida: {pct:.0f}% ({lost}/{len(self.ping_history)})")
                        self._update_monitor_text()
                        if not event["ok"]:
                            self.status_var.set("El equipo no respondió al ping. Reintentando comprobación automáticamente…")
                elif kind == "ping_done":
                    self.ping_busy = False
        except queue.Empty:
            pass
        self.after(300, self._poll_events)

    def _update_monitor_text(self) -> None:
        peer = self.peer_map.get(self.peer_var.get())
        peer_name = peer["name"] if peer else "Ninguno seleccionado"
        peer_ip = peer["ip"] if peer else "—"
        success = [v for v in self.ping_history if v]
        lines = [f"Equipo: {peer_name} ({peer_ip})",
                 f"Muestras: {len(self.ping_history)}  |  Respuestas: {len(success)}  |  Sin respuesta: {len(self.ping_history) - len(success)}",
                 f"Tráfico PC: descarga {self._format_rate(self.rx_rate)}  |  subida {self._format_rate(self.tx_rate)}",
                 "Auto-revisión: activa (red y jugadores cada 8 segundos)."]
        self.monitor_text.configure(state="normal")
        self.monitor_text.delete("1.0", "end")
        self.monitor_text.insert("1.0", "\n".join(lines))
        self.monitor_text.configure(state="disabled")

    def _on_close(self) -> None:
        self.stop_pairing_room(show_message=False)
        self.discovery.close()
        try:
            self.upnp.remove_all()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    import zyh_terms; zyh_terms.require("ZYH Bridged")      # términos: si no se aceptan, la app se cierra
    enable_windows_dpi()
    app = ZYHBridger()
    app.mainloop()
